import{i as e,t}from"./react-SIfiwpqq.js";import{m as n,o as r}from"./button-DPIFiLxQ.js";import{t as i}from"./ResultsPanel-Dpid_Gah.js";import{t as a}from"./progress-CXD90Mej.js";import{a as o,i as s}from"./index-DVs82XaJ.js";import{n as c}from"./engine-DGRvFMeW.js";import{n as l,t as u}from"./TypingArena-oUvWCm4m.js";var d=e(t()),f=[{id:`python`,label:`Python`},{id:`javascript`,label:`JavaScript`},{id:`html`,label:`HTML / CSS`},{id:`cpp`,label:`C++`}],p={python:[`def two_sum(nums: list[int], target: int) -> list[int]:
    seen: dict[int, int] = {}
    for i, n in enumerate(nums):
        need = target - n
        if need in seen:
            return [seen[need], i]
        seen[n] = i
    return []`,`from pathlib import Path

def read_lines(path: str) -> list[str]:
    text = Path(path).read_text(encoding="utf-8")
    return [line.rstrip() for line in text.splitlines() if line.strip()]`,`class Stack[T]:
    def __init__(self) -> None:
        self._items: list[T] = []

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        return self._items.pop()`],javascript:[`export function debounce(fn, wait = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}`,`const sum = (nums) => nums.reduce((a, b) => a + b, 0);

export async function loadUser(id) {
  const res = await fetch(\`/api/users/\${id}\`);
  if (!res.ok) throw new Error("not found");
  return res.json();
}`,`const btn = document.querySelector("#go");
btn?.addEventListener("click", () => {
  const value = Number(input.value) || 0;
  output.textContent = String(value * 2);
});`],html:[`<section class="hero">
  <h1>Type with both hands</h1>
  <p class="lede">Accuracy first. Speed follows.</p>
  <a class="btn" href="/learn">Start lesson</a>
</section>`,`.card {
  display: flex;
  gap: 12px;
  padding: 16px 20px;
  border: 1px solid var(--border);
  border-radius: 12px;
}
.card:hover { transform: translateY(-1px); }`,`<form action="/apply" method="post">
  <label for="name">Full name</label>
  <input id="name" name="name" required />
  <button type="submit">Submit</button>
</form>`],cpp:[`#include <vector>
using namespace std;

int maxSubarray(const vector<int>& a) {
  int best = a[0], cur = a[0];
  for (size_t i = 1; i < a.size(); i++) {
    cur = max(a[i], cur + a[i]);
    best = max(best, cur);
  }
  return best;
}`,`struct Node {
  int val;
  Node* next;
  Node(int v) : val(v), next(nullptr) {}
};

void reverse(Node*& head) {
  Node* prev = nullptr;
  while (head) {
    Node* nxt = head->next;
    head->next = prev;
    prev = head;
    head = nxt;
  }
  head = prev;
}`]};function m(e){let t=p[e];return t[Math.floor(Math.random()*t.length)]}var h=n();function g(){let[e,t]=(0,d.useState)(`javascript`),[n,p]=(0,d.useState)(0),[g,_]=(0,d.useState)(null),[v,y]=(0,d.useState)(null),b=a(e=>e.applyResult),x=(0,d.useMemo)(()=>m(e),[e,n]);return(0,h.jsxs)(`div`,{children:[(0,h.jsx)(o,{kicker:`For developers`,title:`Code typing`,desc:`Build muscle memory for braces, arrows, and semicolons. Indentation counts.`}),(0,h.jsx)(`div`,{className:`mb-6 flex flex-wrap gap-2`,children:f.map(n=>(0,h.jsx)(`button`,{type:`button`,onClick:()=>{t(n.id),_(null),p(e=>e+1)},className:r(`rounded-full border px-3 py-1.5 text-xs font-medium`,e===n.id?`border-primary bg-primary/10 text-primary`:`border-border text-muted hover:text-fg`),children:n.label},n.id))}),g?(0,h.jsx)(i,{result:g,onRestart:()=>{_(null),p(e=>e+1)}}):(0,h.jsxs)(h.Fragment,{children:[v&&(0,h.jsx)(`div`,{className:`mb-4`,children:(0,h.jsx)(u,{snap:v})}),(0,h.jsx)(l,{text:x,onSnapshot:y,onFinish:t=>{_(t),b({result:t,mode:`code`,category:e,xp:c(t,`code`)}),s()}},`${e}-${n}`)]})]})}export{g as component};
//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v--QQjCN_T.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/code",
			"/exam",
			"/leaderboard",
			"/learn",
			"/login",
			"/profile",
			"/race",
			"/api/rtc",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DVs82XaJ.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/dist-xkWRGZO5.js",
			"/assets/scores-BtKu7yg6.js",
			"/assets/button-DPIFiLxQ.js",
			"/assets/lazyRouteComponent-B-tFZXf0.js",
			"/assets/preload-helper-D-nWs-yl.js",
			"/assets/settings-DRmQ2VG-.js",
			"/assets/Logo-CtOwExRc.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/progress-CXD90Mej.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DVs82XaJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BwNoPnwB.js",
			"/assets/useNavigate-CXd7XD1k.js",
			"/assets/ResultsPanel-Dpid_Gah.js",
			"/assets/engine-DGRvFMeW.js",
			"/assets/TypingArena-oUvWCm4m.js",
			"/assets/Hands-DGQ0DwS1.js",
			"/assets/KeyboardGuide-Dko6LRpQ.js",
			"/assets/input-DXbphuU2.js",
			"/assets/words-CsxMfEYX.js"
		]
	},
	"/code": {
		filePath: "/workspace/src/routes/code.tsx",
		children: void 0,
		preloads: [
			"/assets/code-CB8vWJ-I.js",
			"/assets/ResultsPanel-Dpid_Gah.js",
			"/assets/engine-DGRvFMeW.js",
			"/assets/TypingArena-oUvWCm4m.js"
		]
	},
	"/exam": {
		filePath: "/workspace/src/routes/exam.tsx",
		children: void 0,
		preloads: [
			"/assets/exam-CNTLG8G8.js",
			"/assets/ResultsPanel-Dpid_Gah.js",
			"/assets/engine-DGRvFMeW.js",
			"/assets/card-CsipDtop.js"
		]
	},
	"/leaderboard": {
		filePath: "/workspace/src/routes/leaderboard.tsx",
		children: void 0,
		preloads: ["/assets/leaderboard-B_9zUJ8b.js", "/assets/card-CsipDtop.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$lessonId"],
		preloads: [
			"/assets/learn-ChmnhugC.js",
			"/assets/badge-Tzob7blk.js",
			"/assets/card-CsipDtop.js",
			"/assets/Hands-DGQ0DwS1.js",
			"/assets/lessons-1gW8z9cK.js",
			"/assets/progress-CSJdvR9F.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-N4IvovmB.js"]
	},
	"/profile": {
		filePath: "/workspace/src/routes/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-BDy_gsP7.js",
			"/assets/Heatmap-dNdWWcTv.js",
			"/assets/card-CsipDtop.js",
			"/assets/lessons-1gW8z9cK.js",
			"/assets/label-Dz-bGP8l.js"
		]
	},
	"/race": {
		filePath: "/workspace/src/routes/race.tsx",
		children: ["/race/$roomId"],
		preloads: [
			"/assets/race-C1-spwlB.js",
			"/assets/useNavigate-CXd7XD1k.js",
			"/assets/card-CsipDtop.js",
			"/assets/input-DXbphuU2.js",
			"/assets/label-Dz-bGP8l.js"
		]
	},
	"/learn/$lessonId": {
		filePath: "/workspace/src/routes/learn.$lessonId.tsx",
		children: void 0,
		preloads: [
			"/assets/learn._lessonId-FPWb4Qfq.js",
			"/assets/useNavigate-CXd7XD1k.js",
			"/assets/keymap-mRFBBGgn.js",
			"/assets/engine-DGRvFMeW.js",
			"/assets/TypingArena-oUvWCm4m.js",
			"/assets/KeyboardGuide-Dko6LRpQ.js"
		]
	},
	"/race/$roomId": {
		filePath: "/workspace/src/routes/race.$roomId.tsx",
		children: void 0,
		preloads: [
			"/assets/race._roomId-Bll1-jIv.js",
			"/assets/TypingArena-oUvWCm4m.js",
			"/assets/words-CsxMfEYX.js",
			"/assets/progress-CSJdvR9F.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

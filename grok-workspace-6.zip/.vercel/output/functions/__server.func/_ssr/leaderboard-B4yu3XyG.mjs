import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { o as PageTitle, p as getLeaderboard } from "./router-DjO1jKnB.mjs";
import { t as Card } from "./card-Ci2beFk3.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leaderboard-B4yu3XyG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-10 items-center justify-center gap-1 rounded-lg bg-surface-2 p-1 text-muted", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-40 data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=active]:shadow-soft", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("mt-4 focus-visible:outline-none", className),
		...props
	});
}
function Board() {
	const [scope, setScope] = (0, import_react.useState)("daily");
	const [rows, setRows] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		setRows(null);
		getLeaderboard({ data: { scope } }).then((r) => {
			if (live) setRows(r);
		});
		return () => {
			live = false;
		};
	}, [scope]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "Global",
		title: "Leaderboard",
		desc: "Daily, all-time, exam, and academy scores. Sign in after a test to post yours."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		value: scope,
		onValueChange: (v) => setScope(v),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "daily",
				children: "Daily"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "all",
				children: "All-time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "exam",
				children: "Exam"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "lesson",
				children: "Academy"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
			value: scope,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[32rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border text-xs tracking-wide text-subtle uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "#"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Mode"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "WPM"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Acc"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						rows == null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-8 text-center text-muted",
							children: "Loading…"
						}) }),
						rows && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-8 text-center text-muted",
							children: "No scores yet. Finish a test and post it."
						}) }),
						rows?.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-mono tabular-nums text-subtle",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: r.display_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 text-muted",
									children: [
										r.mode,
										" · ",
										r.category
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-mono tabular-nums text-primary",
									children: r.wpm
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 font-mono tabular-nums",
									children: [Math.round(r.accuracy), "%"]
								})
							]
						}, `${r.display_name}-${r.created_at}-${i}`))
					] })]
				})
			})
		})]
	})] });
}
//#endregion
export { Board as component };

import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { a as baseKey, c as needsShift, i as KEYBOARD_ROWS, l as shiftHand, s as fingerForKeyId, t as FINGER_COLOR_CLASS } from "./keymap-V0YgG9Z2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/KeyboardGuide-DZ4kpug4.js
var import_jsx_runtime = require_jsx_runtime();
function KeyboardGuide({ nextChar, highlightKeys, className }) {
	const target = nextChar ? baseKey(nextChar) : null;
	const shift = nextChar ? shiftHand(nextChar) : null;
	const showShift = nextChar ? needsShift(nextChar) : false;
	const marked = new Set((highlightKeys ?? []).map((k) => baseKey(k)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mx-auto w-full max-w-3xl select-none", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-1 rounded-xl border border-border bg-surface p-2 sm:p-3",
			children: KEYBOARD_ROWS.map((row, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center gap-1",
				children: row.map((key) => {
					const finger = fingerForKeyId(key.id);
					const isTarget = target === key.id;
					const isShift = showShift && (shift === "left" && key.id === "shiftleft" || shift === "right" && key.id === "shiftright");
					const active = isTarget || isShift;
					const isNew = marked.has(key.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { flex: key.width },
						className: cn("relative flex h-8 items-center justify-center overflow-hidden rounded-sm border text-[10px] font-medium sm:h-10 sm:rounded-md sm:text-xs", active ? "key-pulse border-primary bg-primary text-primary-fg" : isNew ? "border-primary/50 bg-primary/10 text-fg" : "border-border bg-surface-2 text-muted"),
						children: [
							finger && !active && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("pointer-events-none absolute inset-x-0 bottom-0 h-1 rounded-b-sm sm:rounded-b-md", FINGER_COLOR_CLASS[finger]) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("pointer-events-none absolute inset-0 opacity-[0.18]", FINGER_COLOR_CLASS[finger]) })] }),
							key.home && !active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-subtle" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative",
								children: key.label
							})
						]
					}, key.id);
				})
			}, ri))
		})
	});
}
//#endregion
export { KeyboardGuide as t };

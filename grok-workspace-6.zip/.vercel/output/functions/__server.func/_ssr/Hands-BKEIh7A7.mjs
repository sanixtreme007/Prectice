import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { l as shiftHand, n as FINGER_FILL_CLASS, o as fingerFor, r as FINGER_LABEL, t as FINGER_COLOR_CLASS } from "./keymap-V0YgG9Z2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Hands-BKEIh7A7.js
var import_jsx_runtime = require_jsx_runtime();
var LEFT_FINGERS = [
	{
		id: "LP",
		x: 10,
		h: 56,
		w: 17
	},
	{
		id: "LR",
		x: 31,
		h: 70,
		w: 18
	},
	{
		id: "LM",
		x: 53,
		h: 80,
		w: 19
	},
	{
		id: "LI",
		x: 76,
		h: 68,
		w: 18
	}
];
var RIGHT_FINGERS = [
	{
		id: "RI",
		x: 16,
		h: 68,
		w: 18
	},
	{
		id: "RM",
		x: 38,
		h: 80,
		w: 19
	},
	{
		id: "RR",
		x: 61,
		h: 70,
		w: 18
	},
	{
		id: "RP",
		x: 83,
		h: 56,
		w: 17
	}
];
function FingerPath({ id, x, h, w, active }) {
	const y = 96 - h;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		className: cn(active && "finger-pulse"),
		style: { transformOrigin: `${x + w / 2}px 96px` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x,
			y,
			width: w,
			height: h + 18,
			rx: w / 2,
			className: FINGER_FILL_CLASS[id],
			opacity: active ? 1 : .38
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: x + w / 2,
			cy: y + 7,
			rx: w * .26,
			ry: 4.5,
			fill: "color-mix(in oklab, white 55%, transparent)",
			opacity: active ? .7 : .25
		})]
	});
}
function Thumb({ side, active }) {
	const rotate = side === "left" ? 42 : -42;
	const ox = side === "left" ? 104 : 16;
	const x = side === "left" ? 94 : 6;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
		className: cn(active && "finger-pulse"),
		style: { transformOrigin: `${ox}px 122px` },
		transform: `rotate(${rotate} ${ox} 122)`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x,
			y: 102,
			width: 20,
			height: 42,
			rx: 10,
			className: FINGER_FILL_CLASS.TH,
			opacity: active ? 1 : .38
		})
	});
}
function OneHand({ side, activeIds }) {
	const fingers = side === "left" ? LEFT_FINGERS : RIGHT_FINGERS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 158",
		className: "h-36 w-36 sm:h-40 sm:w-40",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "60",
				cy: "146",
				rx: "16",
				ry: "5",
				fill: "color-mix(in oklab, var(--fg) 10%, var(--surface))"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "60",
				cy: "118",
				rx: "38",
				ry: "24",
				fill: "color-mix(in oklab, var(--fg) 13%, var(--surface))"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
				side,
				active: activeIds.has("TH")
			}),
			fingers.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerPath, {
				...f,
				active: activeIds.has(f.id)
			}, f.id))
		]
	});
}
function Hands({ nextChar, caption = false }) {
	const finger = nextChar ? fingerFor(nextChar) : null;
	const shift = nextChar ? shiftHand(nextChar) : null;
	const left = /* @__PURE__ */ new Set();
	const right = /* @__PURE__ */ new Set();
	if (finger === "TH") {
		left.add("TH");
		right.add("TH");
	} else if (finger?.startsWith("L")) left.add(finger);
	else if (finger?.startsWith("R")) right.add(finger);
	if (shift === "left") left.add("LP");
	if (shift === "right") right.add("RP");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-center gap-6 sm:gap-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OneHand, {
					side: "left",
					activeIds: left
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Left"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OneHand, {
					side: "right",
					activeIds: right
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Right"
				})]
			})]
		}), caption && finger && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 flex items-center justify-center gap-2 text-sm text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-2.5 rounded-full", FINGER_COLOR_CLASS[finger]) }),
				FINGER_LABEL[finger],
				shift ? ` + ${shift === "left" ? "Left" : "Right"} Shift` : ""
			]
		})]
	});
}
function FingerLegend({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: cn("flex flex-wrap justify-center gap-x-3 gap-y-1.5 text-xs text-muted", className),
		children: [
			"LP",
			"LR",
			"LM",
			"LI",
			"TH",
			"RI",
			"RM",
			"RR",
			"RP"
		].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "inline-flex items-center gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", FINGER_COLOR_CLASS[id]) }), FINGER_LABEL[id]]
		}, id))
	});
}
var HOME_KEYS = [
	"a",
	"s",
	"d",
	"f",
	"j",
	"k",
	"l",
	";"
];
function HomeRowRest() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mr-1 text-xs font-medium tracking-widest text-subtle uppercase",
			children: "Rest on"
		}), HOME_KEYS.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "contents",
			children: [i === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-1 text-subtle",
				children: "·"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("relative grid size-8 place-items-center rounded-sm border font-mono text-sm", k === "f" || k === "j" ? "border-primary/40 bg-primary/10 text-fg" : "border-border bg-surface text-muted"),
				children: [k.toUpperCase(), (k === "f" || k === "j") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-primary" })]
			})]
		}, k))]
	});
}
//#endregion
export { Hands as n, HomeRowRest as r, FingerLegend as t };

import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { _ as useProgress, a as pushProgress, o as PageTitle } from "./router-DjO1jKnB.mjs";
import { t as ResultsPanel } from "./ResultsPanel-BInX1w13.mjs";
import { n as xpForResult } from "./engine-DSQG53Y1.mjs";
import { n as TypingArena, t as StatsBar } from "./TypingArena-BUw0XL09.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/code-CHNMGUtu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CODE_LANGS = [
	{
		id: "python",
		label: "Python"
	},
	{
		id: "javascript",
		label: "JavaScript"
	},
	{
		id: "html",
		label: "HTML / CSS"
	},
	{
		id: "cpp",
		label: "C++"
	}
];
var CODE_SNIPPETS = {
	python: [
		`def two_sum(nums: list[int], target: int) -> list[int]:
    seen: dict[int, int] = {}
    for i, n in enumerate(nums):
        need = target - n
        if need in seen:
            return [seen[need], i]
        seen[n] = i
    return []`,
		`from pathlib import Path

def read_lines(path: str) -> list[str]:
    text = Path(path).read_text(encoding="utf-8")
    return [line.rstrip() for line in text.splitlines() if line.strip()]`,
		`class Stack[T]:
    def __init__(self) -> None:
        self._items: list[T] = []

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        return self._items.pop()`
	],
	javascript: [
		`export function debounce(fn, wait = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}`,
		`const sum = (nums) => nums.reduce((a, b) => a + b, 0);

export async function loadUser(id) {
  const res = await fetch(\`/api/users/\${id}\`);
  if (!res.ok) throw new Error("not found");
  return res.json();
}`,
		`const btn = document.querySelector("#go");
btn?.addEventListener("click", () => {
  const value = Number(input.value) || 0;
  output.textContent = String(value * 2);
});`
	],
	html: [
		`<section class="hero">
  <h1>Type with both hands</h1>
  <p class="lede">Accuracy first. Speed follows.</p>
  <a class="btn" href="/learn">Start lesson</a>
</section>`,
		`.card {
  display: flex;
  gap: 12px;
  padding: 16px 20px;
  border: 1px solid var(--border);
  border-radius: 12px;
}
.card:hover { transform: translateY(-1px); }`,
		`<form action="/apply" method="post">
  <label for="name">Full name</label>
  <input id="name" name="name" required />
  <button type="submit">Submit</button>
</form>`
	],
	cpp: [`#include <vector>
using namespace std;

int maxSubarray(const vector<int>& a) {
  int best = a[0], cur = a[0];
  for (size_t i = 1; i < a.size(); i++) {
    cur = max(a[i], cur + a[i]);
    best = max(best, cur);
  }
  return best;
}`, `struct Node {
  int val;
  Node* next;
  Node(int v) : val(v), next(nullptr) {}
};

void reverse(Node*& head) {
  Node* prev = nullptr;
  while (head) {
    Node* nxt = head->next;
    head->next = prev;
    prev = head;
    head = nxt;
  }
  head = prev;
}`]
};
function pickSnippet(lang) {
	const pool = CODE_SNIPPETS[lang];
	return pool[Math.floor(Math.random() * pool.length)];
}
function CodePage() {
	const [lang, setLang] = (0, import_react.useState)("javascript");
	const [seed, setSeed] = (0, import_react.useState)(0);
	const [result, setResult] = (0, import_react.useState)(null);
	const [snap, setSnap] = (0, import_react.useState)(null);
	const applyResult = useProgress((s) => s.applyResult);
	const snippet = (0, import_react.useMemo)(() => pickSnippet(lang), [lang, seed]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "For developers",
			title: "Code typing",
			desc: "Build muscle memory for braces, arrows, and semicolons. Indentation counts."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex flex-wrap gap-2",
			children: CODE_LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setLang(l.id);
					setResult(null);
					setSeed((n) => n + 1);
				},
				className: cn("rounded-full border px-3 py-1.5 text-xs font-medium", lang === l.id ? "border-primary bg-primary/10 text-primary" : "border-border text-muted hover:text-fg"),
				children: l.label
			}, l.id))
		}),
		result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsPanel, {
			result,
			onRestart: () => {
				setResult(null);
				setSeed((n) => n + 1);
			}
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [snap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsBar, { snap })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, {
			text: snippet,
			onSnapshot: setSnap,
			onFinish: (res) => {
				setResult(res);
				applyResult({
					result: res,
					mode: "code",
					category: lang,
					xp: xpForResult(res, "code")
				});
				pushProgress();
			}
		}, `${lang}-${seed}`)] })
	] });
}
//#endregion
export { CodePage as component };

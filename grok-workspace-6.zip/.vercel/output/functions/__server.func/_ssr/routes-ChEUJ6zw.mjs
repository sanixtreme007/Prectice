import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as cn } from "./Logo-25CrJJly.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { _ as useProgress, a as pushProgress, h as useCurrentUser, i as Route$11, l as useSettings, m as saveScore } from "./router-DjO1jKnB.mjs";
import { t as ResultsPanel } from "./ResultsPanel-BInX1w13.mjs";
import { n as xpForResult } from "./engine-DSQG53Y1.mjs";
import { n as TypingArena, t as StatsBar } from "./TypingArena-BUw0XL09.mjs";
import { n as Hands } from "./Hands-BKEIh7A7.mjs";
import { t as KeyboardGuide } from "./KeyboardGuide-DZ4kpug4.mjs";
import { t as Input } from "./input-DeI5ynzg.mjs";
import { t as generateWords } from "./words-DssbXVaM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ChEUJ6zw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-fg/30 data-[state=open]:animate-in data-[state=closed]:animate-out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-surface p-5 shadow-soft focus:outline-none", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-sm p-1 text-muted hover:bg-surface-2 hover:text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 space-y-1", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-semibold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
var DURATIONS = [
	15,
	30,
	60,
	120
];
function Home() {
	const { weak } = Route$11.useSearch();
	const navigate = useNavigate();
	const punctuation = useSettings((s) => s.punctuation);
	const numbers = useSettings((s) => s.numbers);
	const setPunctuation = useSettings((s) => s.setPunctuation);
	const setNumbers = useSettings((s) => s.setNumbers);
	const showKeyboard = useSettings((s) => s.showKeyboard);
	const showHands = useSettings((s) => s.showHands);
	const weakWords = useProgress((s) => s.weakWords);
	const applyResult = useProgress((s) => s.applyResult);
	const user = useCurrentUser();
	const [duration, setDuration] = (0, import_react.useState)(30);
	const [customOpen, setCustomOpen] = (0, import_react.useState)(false);
	const [customVal, setCustomVal] = (0, import_react.useState)("90");
	const [seed, setSeed] = (0, import_react.useState)(1);
	const [result, setResult] = (0, import_react.useState)(null);
	const [snap, setSnap] = (0, import_react.useState)(null);
	const [posted, setPosted] = (0, import_react.useState)(false);
	const [posting, setPosting] = (0, import_react.useState)(false);
	const text = (0, import_react.useMemo)(() => {
		if (weak === "1" && weakWords.length) {
			const pool = weakWords.length ? weakWords : [
				"the",
				"and",
				"that"
			];
			const words = [];
			for (let i = 0; i < 80; i += 1) words.push(pool[i % pool.length]);
			return words.join(" ");
		}
		return generateWords(Math.max(80, duration * 4), {
			punctuation,
			numbers,
			seed
		});
	}, [
		duration,
		punctuation,
		numbers,
		seed,
		weak,
		weakWords
	]);
	const nextChar = snap?.text[snap.caret] ?? text[0] ?? null;
	const running = snap?.status === "running";
	const restart = () => {
		setResult(null);
		setPosted(false);
		setSeed((s) => s + 1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("transition-opacity duration-300", running && "[&_.chrome]:opacity-0"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chrome mb-8 flex flex-col items-center gap-4 transition-opacity duration-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-center gap-1 rounded-lg bg-surface-2 p-1",
					children: [DURATIONS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setDuration(d);
							restart();
						},
						className: cn("h-9 min-w-12 rounded-md px-3 text-sm font-medium tabular-nums", duration === d ? "bg-surface text-fg shadow-soft" : "text-muted hover:text-fg"),
						children: [d, "s"]
					}, d)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCustomOpen(true),
						className: cn("h-9 rounded-md px-3 text-sm font-medium", !DURATIONS.includes(duration) ? "bg-surface text-fg shadow-soft" : "text-muted hover:text-fg"),
						children: "Custom"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
							on: punctuation,
							onClick: () => setPunctuation(!punctuation),
							label: "Punctuation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
							on: numbers,
							onClick: () => setNumbers(!numbers),
							label: "Numbers"
						}),
						weakWords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
							on: weak === "1",
							onClick: () => navigate({
								to: "/",
								search: weak === "1" ? {} : { weak: "1" }
							}),
							label: "Weak words"
						})
					]
				})]
			}),
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsPanel, {
				result,
				onRestart: restart,
				posted,
				posting,
				showWeakLink: true,
				onPost: async () => {
					if (!user) return;
					setPosting(true);
					try {
						await saveScore({ data: {
							mode: "timed",
							category: `${duration}s`,
							wpm: result.wpm,
							rawWpm: result.rawWpm,
							accuracy: result.accuracy,
							durationMs: result.durationMs,
							displayName: user.displayName ?? user.primaryEmail ?? "Typist"
						} });
						setPosted(true);
					} catch {
						setPosted(false);
					} finally {
						setPosting(false);
					}
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mb-6 transition-opacity duration-300", !running && "opacity-60"),
					children: snap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsBar, { snap })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, {
					text,
					durationMs: duration * 1e3,
					onSnapshot: setSnap,
					onFinish: (res) => {
						setResult(res);
						const xp = xpForResult(res, "test");
						applyResult({
							result: res,
							mode: "timed",
							category: `${duration}s`,
							xp
						});
						pushProgress();
					}
				}, `${seed}-${duration}-${punctuation}-${numbers}-${weak ?? ""}`),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chrome mt-10 space-y-6 transition-opacity duration-300",
					children: [showHands && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hands, { nextChar }), showKeyboard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyboardGuide, { nextChar })]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: customOpen,
				onOpenChange: setCustomOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Custom duration" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Seconds. Short tests stay snappy; long tests feel like an exam." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 10,
						max: 600,
						value: customVal,
						onChange: (e) => setCustomVal(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						onClick: () => {
							const n = Math.min(600, Math.max(10, Number(customVal) || 30));
							setDuration(n);
							setCustomOpen(false);
							restart();
						},
						children: "Start"
					})
				] })
			})
		]
	});
}
function ToggleChip({ on, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("rounded-full border px-3 py-1.5 text-xs font-medium", on ? "border-primary bg-primary/10 text-primary" : "border-border text-muted hover:text-fg"),
		children: label
	});
}
//#endregion
export { Home as component };

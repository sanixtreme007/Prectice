import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-RTERXHL8.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-fg",
		secondary: "border-transparent bg-surface-2 text-fg",
		outline: "border-border text-muted",
		success: "border-transparent bg-correct/15 text-correct",
		danger: "border-transparent bg-incorrect/15 text-incorrect"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };

import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as cn } from "./Logo-25CrJJly.mjs";
import { _ as useProgress, a as pushProgress, h as useCurrentUser, m as saveScore, o as PageTitle } from "./router-DjO1jKnB.mjs";
import { t as ResultsPanel } from "./ResultsPanel-BInX1w13.mjs";
import { n as xpForResult, t as TypingEngine } from "./engine-DSQG53Y1.mjs";
import { t as Card } from "./card-Ci2beFk3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam-ClpLhUwo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INSCRIPT_BASE = {
	q: "ौ",
	w: "ै",
	e: "ा",
	r: "ी",
	t: "ू",
	y: "ब",
	u: "ह",
	i: "ग",
	o: "द",
	p: "ज",
	"[": "ड",
	"]": "़",
	"\\": "ॉ",
	a: "ो",
	s: "े",
	d: "्",
	f: "ि",
	g: "ु",
	h: "प",
	j: "र",
	k: "क",
	l: "त",
	";": "च",
	"'": "ट",
	z: "ॆ",
	x: "ं",
	c: "म",
	v: "न",
	b: "व",
	n: "ल",
	m: "स",
	",": ",",
	".": ".",
	"/": "य",
	"1": "१",
	"2": "२",
	"3": "३",
	"4": "४",
	"5": "५",
	"6": "६",
	"7": "७",
	"8": "८",
	"9": "९",
	"0": "०",
	"-": "-",
	"=": "ृ",
	" ": " "
};
var INSCRIPT_SHIFT = {
	Q: "औ",
	W: "ऐ",
	E: "आ",
	R: "ई",
	T: "ऊ",
	Y: "भ",
	U: "ङ",
	I: "घ",
	O: "ध",
	P: "झ",
	"{": "ढ",
	"}": "ञ",
	"|": "ऑ",
	A: "ओ",
	S: "ए",
	D: "अ",
	F: "इ",
	G: "उ",
	H: "फ",
	J: "ऱ",
	K: "ख",
	L: "थ",
	":": "छ",
	"\"": "ठ",
	Z: "ऎ",
	X: "ँ",
	C: "ण",
	V: "ऩ",
	B: "ऴ",
	N: "ळ",
	M: "श",
	"<": "ष",
	">": "।",
	"?": "य़",
	"!": "ऍ",
	"@": "ॅ",
	"#": "्र",
	$: "र्",
	"%": "ज्ञ",
	"^": "त्र",
	"&": "क्ष",
	"*": "श्र",
	"(": "(",
	")": ")",
	_: "ः",
	"+": "ऋ",
	" ": " "
};
var REMINGTON_BASE = {
	q: "ु",
	w: "ू",
	e: "म",
	r: "त",
	t: "ज",
	y: "ल",
	u: "न",
	i: "प",
	o: "व",
	p: "च",
	"[": "ख",
	"]": "भ",
	a: "ं",
	s: "े",
	d: "क",
	f: "ि",
	g: "ह",
	h: "ी",
	j: "र",
	k: "ा",
	l: "स",
	";": "य",
	"'": "श्",
	z: "्र",
	x: "ग",
	c: "ब",
	v: "अ",
	b: "इ",
	n: "द",
	m: "उ",
	",": "ए",
	".": "ण",
	"/": "ध",
	"1": "१",
	"2": "२",
	"3": "३",
	"4": "४",
	"5": "५",
	"6": "६",
	"7": "७",
	"8": "८",
	"9": "९",
	"0": "०",
	" ": " "
};
var REMINGTON_SHIFT = {
	Q: "फ",
	W: "ॅ",
	E: "म्",
	R: "त्",
	T: "ज्",
	Y: "ल्",
	U: "न्",
	I: "प्",
	O: "व्",
	P: "च्",
	A: "ँ",
	S: "ै",
	D: "क्",
	F: "ी",
	G: "ळ",
	H: "भ",
	J: "श्र",
	K: "ज्ञ",
	L: "स्",
	":": "रु",
	"\"": "क्ष",
	Z: "र्",
	X: "घ",
	C: "ब्",
	V: "ट",
	B: "ठ",
	N: "छ",
	M: "ड",
	"<": "ढ",
	">": "झ",
	"?": "ञ",
	" ": " "
};
function mapHindiKey(layout, key) {
	if (key.length !== 1) return null;
	if (layout === "inscript") return INSCRIPT_SHIFT[key] ?? INSCRIPT_BASE[key] ?? null;
	return REMINGTON_SHIFT[key] ?? REMINGTON_BASE[key] ?? null;
}
var HINDI_LAYOUT_META = [
	{
		id: "inscript",
		label: "Mangal Inscript",
		hint: "Official InScript. k = क, f = ि, d = ्"
	},
	{
		id: "remington",
		label: "Remington GAIL",
		hint: "Typewriter layout used in many exams. d = क, k = ा"
	},
	{
		id: "krutidev",
		label: "Kruti Dev",
		hint: "Remington-style keys, shown in Unicode Devanagari"
	}
];
var ENGLISH_PASSAGES = [
	"The Union Public Service Commission conducts examinations for appointment to the services of the Union. A candidate must be a citizen of India or a subject of Nepal or Bhutan. The Commission may, at its discretion, fix qualifying marks in any or all the subjects of the examination.",
	"Good administration depends upon the integrity of public servants and the trust of the people they serve. Orders must be clear, records must be complete, and every citizen must be treated with fairness. Delay without cause is a denial of justice in its own right.",
	"A railway is a system of transport that moves people and goods on tracks. Punctuality, safety, and courtesy are the three duties of every railway employee. Passengers are requested to stand in queue, keep the station clean, and not travel without a proper ticket.",
	"The court directs that the petitioner shall file a reply within two weeks. No adjournment shall be granted except for reasons recorded in writing. The registry shall list the matter for hearing on the next available date after the pleadings are complete.",
	"Science is the careful study of the world through observation and experiment. A hypothesis is tested, not believed. When evidence changes, the conclusion must change with it. This habit of mind is as useful in public work as it is in a laboratory.",
	"India is a union of states. The Constitution is the supreme law of the land. Fundamental rights protect the citizen; directive principles guide the state. Every officer who takes an oath of office is bound to uphold this Constitution without fear or favour.",
	"Time management is the quiet skill behind every high score. Read the passage once, type at a steady pace, and do not chase speed at the cost of accuracy. A clean script with fewer mistakes always outranks a fast script full of errors.",
	"The police station is a public office. A first information report must be registered when a cognizable offence is made out. The informant shall be given a copy free of cost. Investigation shall be fair, prompt, and confined to the facts."
];
var HINDI_PASSAGES = [
	"भारत एक संप्रभु समाजवादी पंथनिरपेक्ष लोकतंत्रात्मक गणराज्य है। संविधान देश का सर्वोच्च कानून है। प्रत्येक नागरिक को समानता, स्वतंत्रता और न्याय का अधिकार है। लोकसेवक अपना कार्य ईमानदारी और निष्पक्षता से करें।",
	"रेलवे यात्रियों से निवेदन है कि वे कतार में रहें, स्टेशन को स्वच्छ रखें तथा बिना टिकट यात्रा न करें। समय की पाबंदी, सुरक्षा और शिष्टाचार रेल कर्मचारी के तीन मुख्य कर्तव्य हैं।",
	"उच्च न्यायालय यह आदेश देता है कि याचिकाकर्ता दो सप्ताह के भीतर उत्तर दाखिल करे। लिखित कारण के बिना स्थगन नहीं दिया जाएगा। पत्रावली पूर्ण होने के पश्चात मामला शीघ्र सुनवाई के लिए सूचीबद्ध किया जाए।",
	"शिक्षा का उद्देश्य केवल परीक्षा उत्तीर्ण करना नहीं है। ज्ञान, अनुशासन और चरित्र मिलकर एक अच्छा नागरिक बनाते हैं। नियमित अभ्यास से टाइपिंग में गति और शुद्धता दोनों बढ़ती हैं।"
];
function pickPassage(pool, seed) {
	if (!pool.length) return "";
	return pool[typeof seed === "number" ? Math.abs(seed) % pool.length : Math.floor(Math.random() * pool.length)];
}
var EXAM_PRESETS = [
	{
		id: "ssc-chsl",
		label: "SSC CHSL",
		durationSec: 600,
		backspace: "full",
		lang: "en",
		blurb: "10-minute English passage. Accuracy first, then speed."
	},
	{
		id: "ssc-cgl",
		label: "SSC CGL",
		durationSec: 600,
		backspace: "full",
		lang: "en",
		blurb: "Skill-test style passage used in Combined Graduate Level."
	},
	{
		id: "high-court",
		label: "High Court",
		durationSec: 600,
		backspace: "none",
		lang: "en",
		blurb: "Legal English. Backspace off, as in many court tests."
	},
	{
		id: "railway",
		label: "Railway",
		durationSec: 600,
		backspace: "word",
		lang: "en",
		blurb: "Station-and-service English with word-level backspace."
	},
	{
		id: "police",
		label: "Police",
		durationSec: 600,
		backspace: "full",
		lang: "en",
		blurb: "Police-office English. Full backspace allowed."
	},
	{
		id: "ssc-hindi",
		label: "SSC Hindi",
		durationSec: 600,
		backspace: "full",
		lang: "hi",
		blurb: "Hindi passage. Pick Inscript, Remington, or Kruti Dev."
	}
];
function ExamPage() {
	const [presetId, setPresetId] = (0, import_react.useState)(EXAM_PRESETS[0].id);
	const preset = EXAM_PRESETS.find((p) => p.id === presetId);
	const [layout, setLayout] = (0, import_react.useState)("inscript");
	const [backspace, setBackspace] = (0, import_react.useState)(preset.backspace);
	const [seed, setSeed] = (0, import_react.useState)(0);
	const passage = (0, import_react.useMemo)(() => pickPassage(preset.lang === "hi" ? HINDI_PASSAGES : ENGLISH_PASSAGES, seed), [preset.lang, seed]);
	(0, import_react.useEffect)(() => {
		setBackspace(preset.backspace);
	}, [preset.backspace]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "Skill test",
			title: "Exam simulation",
			desc: "Reference on top, your paper below — the layout used in SSC, High Court, Railway, and Police tests."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex flex-wrap gap-2",
			children: EXAM_PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setPresetId(p.id);
					setSeed((n) => n + 1);
				},
				className: cn("rounded-full border px-3 py-1.5 text-xs font-medium", p.id === presetId ? "border-primary bg-primary/10 text-primary" : "border-border text-muted hover:text-fg"),
				children: p.label
			}, p.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: preset.blurb
		}),
		preset.lang === "hi" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: HINDI_LAYOUT_META.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setLayout(l.id),
				className: cn("rounded-md border px-3 py-1.5 text-xs", layout === l.id ? "border-primary bg-primary/10 text-primary" : "border-border text-muted"),
				title: l.hint,
				children: l.label
			}, l.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2 text-xs",
			children: [
				"full",
				"word",
				"none"
			].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setBackspace(m),
				className: cn("rounded-md border px-3 py-1.5 font-medium", backspace === m ? "border-primary text-primary" : "border-border text-muted"),
				children: ["Backspace: ", m]
			}, m))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamArena, {
			passage,
			durationMs: preset.durationSec * 1e3,
			backspace,
			hindi: preset.lang === "hi" ? layout : null,
			category: preset.id,
			onRetest: () => setSeed((n) => n + 1)
		}, `${presetId}-${seed}-${backspace}-${layout}`)
	] });
}
function ExamArena({ passage, durationMs, backspace, hindi, category, onRetest }) {
	const areaRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(new TypingEngine({
		text: passage,
		durationMs,
		backspace
	}));
	const [typed, setTyped] = (0, import_react.useState)("");
	const [left, setLeft] = (0, import_react.useState)(durationMs);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [posted, setPosted] = (0, import_react.useState)(false);
	const [posting, setPosting] = (0, import_react.useState)(false);
	const applyResult = useProgress((s) => s.applyResult);
	const user = useCurrentUser();
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const e = engineRef.current;
			if (e.status !== "running") return;
			e.tick();
			const shot = e.snapshot();
			setLeft(shot.remainingMs ?? 0);
			if (shot.status === "finished" && !result) finish();
		}, 100);
		return () => window.clearInterval(id);
	}, [result]);
	const finish = () => {
		const e = engineRef.current;
		e.finish();
		const res = e.result();
		setResult(res);
		const xp = xpForResult(res, "exam");
		applyResult({
			result: res,
			mode: "exam",
			category,
			xp
		});
		pushProgress();
	};
	const onKeyDown = (ev) => {
		if (result) return;
		if (ev.key === "Tab") {
			ev.preventDefault();
			return;
		}
		if (hindi && ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey) {
			const mapped = mapHindiKey(hindi, ev.key);
			if (mapped) {
				ev.preventDefault();
				engineRef.current.startIfNeeded();
				setRunning(true);
				const fake = {
					key: mapped,
					getModifierState: () => false
				};
				engineRef.current.handleKey(fake);
				setTyped((t) => {
					return t + mapped;
				});
				return;
			}
		}
		if (ev.key === "Backspace") {
			if (backspace === "none") {
				ev.preventDefault();
				return;
			}
			if (backspace === "word") {
				ev.preventDefault();
				engineRef.current.handleKey(ev.nativeEvent);
				setTyped((t) => t.replace(/\s*\S+$/, ""));
				return;
			}
		}
		if (ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey) {
			engineRef.current.startIfNeeded();
			setRunning(true);
			engineRef.current.handleKey(ev.nativeEvent);
		} else if (ev.key === "Backspace" && backspace === "full") engineRef.current.handleKey(ev.nativeEvent);
	};
	const onChange = (ev) => {
		if (hindi) return;
		if (result) return;
		const v = ev.target.value;
		setTyped(v);
		engineRef.current.startIfNeeded();
		setRunning(true);
	};
	const snap = engineRef.current.snapshot();
	const secs = Math.ceil(left / 1e3);
	if (result) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsPanel, {
		result,
		onRestart: onRetest,
		posted,
		posting,
		onPost: async () => {
			if (!user) return;
			setPosting(true);
			try {
				await saveScore({ data: {
					mode: "exam",
					category,
					wpm: result.wpm,
					rawWpm: result.rawWpm,
					accuracy: result.accuracy,
					durationMs: result.durationMs,
					displayName: user.displayName ?? user.primaryEmail ?? "Typist"
				} });
				setPosted(true);
			} catch {} finally {
				setPosting(false);
			}
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 font-mono text-sm tabular-nums",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-primary",
						children: [running ? snap.wpm : 0, " wpm"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [running ? Math.round(snap.accuracy) : 100, "%"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [secs, "s left"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: finish,
						children: "Submit"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-[11px] font-medium tracking-widest text-subtle uppercase",
					children: "Passage"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("max-h-40 overflow-auto text-[15px] leading-relaxed text-fg", hindi && "font-[family-name:var(--font-devanagari)]"),
					children: passage
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					ref: areaRef,
					value: typed,
					onChange,
					onKeyDown,
					placeholder: "Type the passage here…",
					className: cn("min-h-48 w-full resize-y rounded-xl bg-transparent p-4 font-mono text-[15px] leading-relaxed text-fg outline-none placeholder:text-subtle", hindi && "font-[family-name:var(--font-devanagari)]"),
					spellCheck: false,
					autoCapitalize: "off",
					autoCorrect: "off"
				})
			})
		]
	});
}
//#endregion
export { ExamPage as component };

import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as cn } from "./Logo-25CrJJly.mjs";
import { _ as useProgress, c as THEMES, d as SignedOut, f as UserButton, g as useCurrentUserState, l as useSettings, o as PageTitle, s as SWITCHES, u as SignedIn } from "./router-DjO1jKnB.mjs";
import { t as FingerHeatmap } from "./Heatmap-Cb5YHC4o.mjs";
import { n as CardDescription, r as CardTitle, t as Card } from "./card-Ci2beFk3.mjs";
import { t as LESSONS } from "./lessons-BjyAdrU4.mjs";
import { t as Label } from "./label-Cncy-_Dg.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-MRTq9PkQ.js
var import_jsx_runtime = require_jsx_runtime();
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border bg-surface shadow-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40" })]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-11 shrink-0 items-center rounded-full border border-border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 data-[state=checked]:bg-primary data-[state=unchecked]:bg-surface-2", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-surface shadow-soft transition-transform data-[state=checked]:translate-x-[22px] data-[state=checked]:bg-primary-fg" })
	});
}
function Profile() {
	const { user, isPending } = useCurrentUserState();
	const xp = useProgress((s) => s.xp);
	const streak = useProgress((s) => s.streak);
	const tests = useProgress((s) => s.testsCompleted);
	const best = useProgress((s) => s.bestWpm);
	const completed = useProgress((s) => s.completedLessons);
	const recent = useProgress((s) => s.recent);
	const letterErrors = useProgress((s) => s.letterErrors);
	const fingerErrors = useProgress((s) => s.fingerErrors);
	const weakWords = useProgress((s) => s.weakWords);
	const settings = useSettings();
	const topLetters = Object.entries(letterErrors).sort((a, b) => b[1] - a[1]).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "You",
			title: "Profile & settings",
			desc: "Local progress always. Cloud sync when you sign in."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex flex-wrap items-center gap-3",
			children: [isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 animate-pulse rounded-full bg-surface-2" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Saved to this account"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					children: "Sign in to sync"
				})
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "signed in"
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					n: xp,
					l: "XP"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					n: `${streak}d`,
					l: "Streak"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					n: best,
					l: "Best WPM"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					n: `${completed.length}/${LESSONS.length}`,
					l: "Lessons"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Settings" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
						className: "mb-4",
						children: "Applies on every test."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "mb-2 block",
								children: "Theme"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: THEMES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => settings.setTheme(t.id),
									className: `rounded-full border px-3 py-1.5 text-xs ${settings.theme === t.id ? "border-primary text-primary" : "border-border text-muted"}`,
									children: t.label
								}, t.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "mb-2 block",
								children: "Key sound"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: SWITCHES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => settings.setSound(s.id),
									className: `rounded-full border px-3 py-1.5 text-xs ${settings.sound === s.id ? "border-primary text-primary" : "border-border text-muted"}`,
									children: s.label
								}, s.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "mb-2 block",
								children: [
									"Text size · ",
									settings.fontSize,
									"px"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 20,
								max: 40,
								step: 2,
								value: [settings.fontSize],
								onValueChange: (v) => settings.setFontSize(v[0] ?? 28)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "kb",
									children: "On-screen keyboard"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									id: "kb",
									checked: settings.showKeyboard,
									onCheckedChange: settings.setShowKeyboard
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hands",
									children: "Finger guide"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									id: "hands",
									checked: settings.showHands,
									onCheckedChange: settings.setShowHands
								})]
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Recent tests" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, {
						className: "mb-4",
						children: [tests, " completed on this device."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2",
						children: [recent.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No tests yet."
						}), recent.slice(0, 8).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3 font-mono text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [
									r.mode,
									"/",
									r.category
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								r.wpm,
								" wpm · ",
								Math.round(r.accuracy),
								"%"
							] })]
						}, r.at))]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerHeatmap, { errors: fingerErrors }), topLetters.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-muted",
						children: "Problem letters"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: topLetters.map(([k, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-md bg-surface-2 px-2 py-1 font-mono text-xs",
							children: [
								k,
								" · ",
								n
							]
						}, k))
					})]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Weak words" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
						className: "mb-3",
						children: "Missed in recent sessions."
					}),
					weakWords.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Clean so far."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: weakWords.slice(0, 24).map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-incorrect/10 px-2 py-1 font-mono text-xs text-incorrect",
							children: w
						}, w))
					}),
					weakWords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: "outline",
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							search: { weak: "1" },
							children: "Practice them"
						})
					})
				] })
			]
		})
	] });
}
function Stat({ n, l }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-2xl font-medium tabular-nums text-primary",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] tracking-widest text-subtle uppercase",
			children: l
		})]
	});
}
//#endregion
export { Profile as component };

import { o as fingerFor } from "./keymap-V0YgG9Z2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-DSQG53Y1.js
function wordsOf(text) {
	const out = [];
	let i = 0;
	while (i < text.length) {
		while (i < text.length && text[i] === " ") i += 1;
		const start = i;
		while (i < text.length && text[i] !== " ") i += 1;
		if (start < i) out.push({
			start,
			end: i,
			word: text.slice(start, i)
		});
	}
	return out;
}
var TypingEngine = class {
	text;
	flags;
	caret = 0;
	status = "idle";
	startedAt = null;
	finishedAt = null;
	durationMs;
	backspace;
	errors = 0;
	extras = 0;
	samples = [];
	letterErrors = {};
	fingerErrors = {};
	capsLock = false;
	lastSampleAt = 0;
	typedLog = [];
	constructor(opts) {
		this.text = opts.text;
		this.flags = new Array(opts.text.length).fill(0);
		this.durationMs = opts.durationMs ?? null;
		this.backspace = opts.backspace ?? "full";
	}
	snapshot(now = performance.now()) {
		const elapsed = this.elapsed(now);
		const remaining = this.durationMs == null ? null : Math.max(0, this.durationMs - elapsed);
		const stats = this.liveStats(elapsed);
		return {
			text: this.text,
			flags: this.flags,
			caret: this.caret,
			status: this.status,
			startedAt: this.startedAt,
			elapsedMs: elapsed,
			remainingMs: remaining,
			...stats,
			errors: this.errors,
			capsLock: this.capsLock
		};
	}
	elapsed(now = performance.now()) {
		if (this.startedAt == null) return 0;
		const end = this.finishedAt ?? now;
		return Math.max(0, end - this.startedAt);
	}
	liveStats(elapsedMs) {
		const minutes = Math.max(elapsedMs / 6e4, 1 / 6e4);
		let correct = 0;
		let incorrect = 0;
		for (let i = 0; i < this.caret; i += 1) if (this.flags[i] === 1) correct += 1;
		else if (this.flags[i] === 2) incorrect += 1;
		const typed = correct + incorrect;
		return {
			wpm: Math.round(correct / 5 / minutes),
			rawWpm: Math.round(typed / 5 / minutes),
			cpm: Math.round(correct / minutes),
			accuracy: typed === 0 ? 100 : Math.max(0, Math.round(correct / typed * 1e3) / 10)
		};
	}
	maybeSample(now) {
		if (this.startedAt == null) return;
		if (now - this.lastSampleAt < 1e3 && this.status !== "finished") return;
		this.lastSampleAt = now;
		const elapsed = this.elapsed(now);
		const { wpm, rawWpm } = this.liveStats(elapsed);
		this.samples.push({
			t: elapsed / 1e3,
			wpm,
			rawWpm
		});
	}
	handleKey(e) {
		if (this.status === "finished") return false;
		if (e.ctrlKey || e.metaKey || e.altKey) return false;
		const key = e.key;
		if (e.getModifierState) this.capsLock = e.getModifierState("CapsLock");
		if (key === "Backspace") return this.doBackspace();
		if (key === "Tab") return false;
		if (key === "Escape") return false;
		if (key.length !== 1) return false;
		this.startIfNeeded();
		if (this.caret >= this.text.length) {
			this.finish();
			return true;
		}
		const expected = this.text[this.caret];
		const ok = key === expected;
		this.flags[this.caret] = ok ? 1 : 2;
		if (!ok) {
			this.errors += 1;
			const letter = expected === " " ? "space" : expected.toLowerCase();
			this.letterErrors[letter] = (this.letterErrors[letter] ?? 0) + 1;
			const finger = fingerFor(expected);
			if (finger) this.fingerErrors[finger] = (this.fingerErrors[finger] ?? 0) + 1;
		}
		this.typedLog.push({
			i: this.caret,
			ok,
			t: performance.now()
		});
		this.caret += 1;
		if (this.durationMs == null && this.caret >= this.text.length) this.finish();
		return true;
	}
	doBackspace() {
		if (this.backspace === "none") return true;
		if (this.caret <= 0) return true;
		this.startIfNeeded();
		if (this.backspace === "word") {
			let i = this.caret;
			if (this.text[i - 1] === " ") i -= 1;
			while (i > 0 && this.text[i - 1] !== " ") i -= 1;
			for (let k = i; k < this.caret; k += 1) this.flags[k] = 0;
			this.caret = i;
			return true;
		}
		this.caret -= 1;
		this.flags[this.caret] = 0;
		return true;
	}
	startIfNeeded() {
		if (this.status === "idle") {
			this.status = "running";
			this.startedAt = performance.now();
			this.lastSampleAt = this.startedAt;
		}
	}
	tick(now = performance.now()) {
		if (this.status !== "running") return;
		this.maybeSample(now);
		if (this.durationMs != null && now - (this.startedAt ?? now) >= this.durationMs) this.finish(now);
	}
	finish(now = performance.now()) {
		if (this.status === "finished") return;
		this.status = "finished";
		this.finishedAt = now;
		this.maybeSample(now);
	}
	result() {
		const durationMs = Math.max(this.elapsed(), 1);
		const stats = this.liveStats(durationMs);
		let missed = 0;
		for (let i = this.caret; i < this.text.length; i += 1) if (this.text[i] !== " ") missed += 1;
		const weakWords = [];
		for (const w of wordsOf(this.text)) {
			if (w.end > this.caret && w.start >= this.caret) continue;
			let bad = false;
			for (let i = w.start; i < Math.min(w.end, this.caret); i += 1) if (this.flags[i] === 2) {
				bad = true;
				break;
			}
			if (bad) weakWords.push(w.word);
		}
		let correct = 0;
		let incorrect = 0;
		for (let i = 0; i < this.caret; i += 1) if (this.flags[i] === 1) correct += 1;
		else if (this.flags[i] === 2) incorrect += 1;
		return {
			...stats,
			correctChars: correct,
			incorrectChars: incorrect,
			extraChars: this.extras,
			missedChars: missed,
			durationMs,
			samples: this.samples,
			weakWords,
			letterErrors: { ...this.letterErrors },
			fingerErrors: { ...this.fingerErrors }
		};
	}
};
function xpForResult(result, kind) {
	const base = kind === "lesson" ? 40 : kind === "exam" ? 30 : 18;
	const speedBonus = Math.min(40, Math.round(result.wpm / 3));
	const accBonus = result.accuracy >= 98 ? 25 : result.accuracy >= 95 ? 15 : result.accuracy >= 90 ? 8 : 0;
	return base + speedBonus + accBonus;
}
//#endregion
export { xpForResult as n, TypingEngine as t };

import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { l as useSettings } from "./router-DjO1jKnB.mjs";
import { t as TypingEngine } from "./engine-DSQG53Y1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TypingArena-BUw0XL09.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var lastAt = 0;
function ac() {
	if (typeof window === "undefined") return null;
	ctx ??= new AudioContext();
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function noise(acx, duration) {
	const buffer = acx.createBuffer(1, Math.floor(acx.sampleRate * duration), acx.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1;
	const src = acx.createBufferSource();
	src.buffer = buffer;
	return src;
}
function playKeySound(kind, isError = false) {
	if (kind === "off") return;
	const acx = ac();
	if (!acx) return;
	const now = acx.currentTime;
	if (now - lastAt < .012) return;
	lastAt = now;
	const master = acx.createGain();
	master.gain.value = isError ? .08 : .12;
	master.connect(acx.destination);
	const thud = acx.createOscillator();
	const thudGain = acx.createGain();
	thud.type = "sine";
	thud.frequency.value = isError ? 140 : kind === "red" ? 110 : kind === "brown" ? 150 : 190;
	thudGain.gain.setValueAtTime(.7, now);
	thudGain.gain.exponentialRampToValueAtTime(.001, now + (kind === "red" ? .05 : .07));
	thud.connect(thudGain);
	thudGain.connect(master);
	thud.start(now);
	thud.stop(now + .08);
	if (kind === "brown" || kind === "blue") {
		const bump = acx.createOscillator();
		const bumpGain = acx.createGain();
		bump.type = "triangle";
		bump.frequency.value = kind === "blue" ? 920 : 420;
		bumpGain.gain.setValueAtTime(kind === "blue" ? .28 : .18, now);
		bumpGain.gain.exponentialRampToValueAtTime(.001, now + (kind === "blue" ? .035 : .03));
		bump.connect(bumpGain);
		bumpGain.connect(master);
		bump.start(now);
		bump.stop(now + .04);
	}
	if (kind === "blue") {
		const click = noise(acx, .025);
		const clickGain = acx.createGain();
		const filter = acx.createBiquadFilter();
		filter.type = "highpass";
		filter.frequency.value = 1800;
		clickGain.gain.setValueAtTime(.35, now);
		clickGain.gain.exponentialRampToValueAtTime(.001, now + .03);
		click.connect(filter);
		filter.connect(clickGain);
		clickGain.connect(master);
		click.start(now);
	}
}
function primeAudio() {
	ac();
}
function TypingArena({ text, durationMs = null, backspace = "full", font = "mono", onFinish, onSnapshot, className, autoFocus = true }) {
	const engineRef = (0, import_react.useRef)(null);
	const [snap, setSnap] = (0, import_react.useState)(() => {
		const e = new TypingEngine({
			text,
			durationMs,
			backspace
		});
		engineRef.current = e;
		return e.snapshot();
	});
	const wrapRef = (0, import_react.useRef)(null);
	const caretRef = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	const [caretPos, setCaretPos] = (0, import_react.useState)({
		x: 0,
		y: 0,
		h: 0
	});
	const [focused, setFocused] = (0, import_react.useState)(false);
	const finishedRef = (0, import_react.useRef)(false);
	const { sound, caret, fontSize } = useSettings();
	const refresh = (0, import_react.useCallback)(() => {
		const e = engineRef.current;
		if (!e) return;
		const next = e.snapshot();
		setSnap(next);
		onSnapshot?.(next);
		if (next.status === "finished" && !finishedRef.current) {
			finishedRef.current = true;
			onFinish(e.result());
		}
	}, [onFinish, onSnapshot]);
	(0, import_react.useEffect)(() => {
		const e = new TypingEngine({
			text,
			durationMs,
			backspace
		});
		engineRef.current = e;
		finishedRef.current = false;
		setSnap(e.snapshot());
		onSnapshot?.(e.snapshot());
		if (autoFocus) inputRef.current?.focus();
	}, [
		text,
		durationMs,
		backspace,
		autoFocus,
		onSnapshot
	]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const e = engineRef.current;
			if (!e || e.status !== "running") return;
			e.tick();
			refresh();
		}, 100);
		return () => window.clearInterval(id);
	}, [refresh]);
	(0, import_react.useLayoutEffect)(() => {
		const wrap = wrapRef.current;
		const caretEl = caretRef.current;
		if (!wrap || !caretEl) return;
		const w = wrap.getBoundingClientRect();
		const c = caretEl.getBoundingClientRect();
		setCaretPos({
			x: c.left - w.left,
			y: c.top - w.top,
			h: c.height
		});
	}, [
		snap.caret,
		snap.text,
		fontSize
	]);
	const onKeyDown = (e) => {
		if (e.key === "Tab") {
			e.preventDefault();
			const engine = new TypingEngine({
				text,
				durationMs,
				backspace
			});
			engineRef.current = engine;
			finishedRef.current = false;
			setSnap(engine.snapshot());
			return;
		}
		primeAudio();
		if (engineRef.current?.handleKey(e.nativeEvent)) {
			e.preventDefault();
			const flag = engineRef.current?.flags[(engineRef.current.caret ?? 1) - 1];
			playKeySound(sound, flag === 2);
			refresh();
		}
	};
	const onInput = (e) => {
		const v = e.currentTarget.value;
		if (!v) return;
		e.currentTarget.value = "";
		primeAudio();
		for (const ch of v) engineRef.current?.handleKey({ key: ch });
		playKeySound(sound, false);
		refresh();
	};
	const nextChar = snap.text[snap.caret] ?? null;
	const running = snap.status === "running";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				ref: inputRef,
				"aria-label": "Typing input",
				autoCapitalize: "off",
				autoCorrect: "off",
				spellCheck: false,
				className: "sr-only",
				onKeyDown,
				onInput,
				onFocus: () => setFocused(true),
				onBlur: () => setFocused(false),
				value: "",
				onChange: () => void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: wrapRef,
				role: "group",
				tabIndex: 0,
				onClick: () => inputRef.current?.focus(),
				className: cn("relative mx-auto max-w-3xl cursor-text rounded-xl px-2 py-6 leading-relaxed break-words select-none sm:px-4", font === "devanagari" ? "font-[family-name:var(--font-devanagari)]" : "font-mono", !focused && snap.status === "idle" && "opacity-80"),
				style: { fontSize },
				children: [
					snap.text.split("").map((ch, i) => {
						const flag = snap.flags[i] ?? 0;
						const isCaret = i === snap.caret;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							ref: isCaret ? caretRef : void 0,
							className: cn("relative inline", flag === 0 && "text-pending", flag === 1 && "text-correct", flag === 2 && "text-incorrect", ch === " " && flag === 2 && "bg-incorrect/20"),
							children: ch === " " ? "\xA0" : ch
						}, i);
					}),
					snap.caret >= snap.text.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						ref: caretRef,
						className: "inline-block w-0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						className: cn("pointer-events-none absolute rounded-sm bg-caret", snap.status !== "running" && "caret-blink", caret === "bar" && "w-0.5", caret === "block" && "w-[0.6ch] opacity-40", caret === "underline" && "h-0.5"),
						style: {
							left: caretPos.x,
							top: caret === "underline" ? caretPos.y + caretPos.h - 2 : caretPos.y,
							height: caret === "underline" ? 2 : caretPos.h || fontSize,
							width: caret === "bar" ? 2 : caret === "block" ? void 0 : void 0
						}
					})
				]
			}),
			snap.status === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-center text-sm text-subtle",
				children: [
					focused ? "Start typing" : "Click the text and start typing",
					nextChar ? "" : "",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: " · Tab to restart"
					})
				]
			}),
			snap.capsLock && running && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-center text-sm text-incorrect",
				children: "Caps Lock is on"
			})
		]
	});
}
function StatsBar({ snap }) {
	const time = snap.remainingMs != null ? Math.ceil(snap.remainingMs / 1e3) : Math.floor(snap.elapsedMs / 1e3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-center gap-6 font-mono tabular-nums sm:gap-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "wpm",
				value: snap.status === "idle" ? "—" : String(snap.wpm)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "acc",
				value: snap.status === "idle" ? "—" : `${Math.round(snap.accuracy)}%`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: snap.remainingMs != null ? "time" : "elapsed",
				value: String(time)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				label: "cpm",
				value: snap.status === "idle" ? "—" : String(snap.cpm)
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-3xl font-medium tracking-tight text-primary sm:text-4xl",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] font-medium tracking-widest text-subtle uppercase",
			children: label
		})]
	});
}
//#endregion
export { TypingArena as n, StatsBar as t };

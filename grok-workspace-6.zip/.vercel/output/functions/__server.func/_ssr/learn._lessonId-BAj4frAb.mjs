import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as cn } from "./Logo-25CrJJly.mjs";
import { _ as ArrowRight, h as Check, u as Lock, v as ArrowLeft } from "../_libs/lucide-react.mjs";
import { _ as useProgress, a as pushProgress, r as Route$2 } from "./router-DjO1jKnB.mjs";
import { l as shiftHand, o as fingerFor, r as FINGER_LABEL, t as FINGER_COLOR_CLASS } from "./keymap-V0YgG9Z2.mjs";
import { n as xpForResult } from "./engine-DSQG53Y1.mjs";
import { n as TypingArena, t as StatsBar } from "./TypingArena-BUw0XL09.mjs";
import { n as Hands, r as HomeRowRest, t as FingerLegend } from "./Hands-BKEIh7A7.mjs";
import { t as Badge } from "./badge-RTERXHL8.mjs";
import { a as keyLabel, c as nextStageAfter, i as isLessonUnlocked, l as stageText, o as lessonById, r as STAGE_FLOW, t as LESSONS, u as stageUnlocked } from "./lessons-BjyAdrU4.mjs";
import { t as KeyboardGuide } from "./KeyboardGuide-DZ4kpug4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._lessonId-BAj4frAb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LessonPage() {
	const { lessonId } = Route$2.useParams();
	const lesson = lessonById(lessonId);
	const completed = useProgress((s) => s.completedLessons);
	const lessonStages = useProgress((s) => s.lessonStages);
	const applyResult = useProgress((s) => s.applyResult);
	const [stage, setStage] = (0, import_react.useState)("intro");
	const [seed, setSeed] = (0, import_react.useState)(0);
	const [snap, setSnap] = (0, import_react.useState)(null);
	const [last, setLast] = (0, import_react.useState)(null);
	const [demoIdx, setDemoIdx] = (0, import_react.useState)(0);
	const done = lesson ? lessonStages[lesson.id] ?? [] : [];
	const text = (0, import_react.useMemo)(() => lesson ? stageText(lesson, stage) : "", [lesson, stage]);
	(0, import_react.useEffect)(() => {
		setStage("intro");
		setLast(null);
		setSnap(null);
		setSeed(0);
		setDemoIdx(0);
	}, [lessonId]);
	(0, import_react.useEffect)(() => {
		if (stage !== "intro" || !lesson?.keys.length) return;
		const id = window.setInterval(() => {
			setDemoIdx((n) => (n + 1) % lesson.keys.length);
		}, 1400);
		return () => window.clearInterval(id);
	}, [stage, lesson]);
	if (!lesson) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/learn" });
	if (!isLessonUnlocked(lesson.id, completed)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/learn" });
	const idx = LESSONS.findIndex((l) => l.id === lesson.id);
	const nextLesson = LESSONS[idx + 1];
	const demoChar = lesson.keys[demoIdx] ?? lesson.keys[0] ?? null;
	const liveChar = snap?.text[snap.caret] ?? null;
	const nextChar = stage === "intro" || last ? demoChar : liveChar;
	const finger = nextChar ? fingerFor(nextChar) : null;
	const shift = nextChar ? shiftHand(nextChar) : null;
	const passedThis = last != null && last.accuracy >= 95;
	const drillStage = stage === "intro" ? null : stage;
	const missed = last ? Object.entries(last.letterErrors).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).slice(0, 6) : [];
	const goStage = (s) => {
		if (!stageUnlocked(s, done) && s !== "intro") return;
		setStage(s);
		setLast(null);
		setSnap(null);
		setSeed((n) => n + 1);
	};
	const onFinish = (res) => {
		setLast(res);
		const passed = res.accuracy >= 95;
		applyResult({
			result: res,
			mode: "lesson",
			category: lesson.id,
			xp: xpForResult(res, "lesson"),
			lessonId: lesson.id,
			passedLesson: stage === "sentences" && passed,
			lessonStage: drillStage ?? void 0,
			passedStage: passed
		});
		pushProgress();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/learn",
			className: "mb-5 inline-flex min-h-11 items-center gap-1 text-sm text-muted hover:text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Academy"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium tracking-widest text-subtle uppercase",
				children: [
					"Module ",
					lesson.module,
					" · ",
					lesson.moduleTitle
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight sm:text-3xl",
				children: lesson.title
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex w-full gap-1 lg:w-auto",
				children: STAGE_FLOW.map((s) => {
					const open = stageUnlocked(s.id, done);
					const complete = s.id === "intro" ? done.includes("keys") : done.includes(s.id);
					const active = stage === s.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "flex-1 lg:flex-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !open,
							onClick: () => goStage(s.id),
							className: cn("inline-flex h-11 w-full items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium sm:text-sm", active ? "bg-surface-2 text-fg" : open ? "text-muted hover:bg-surface-2 hover:text-fg" : "cursor-not-allowed text-subtle"),
							children: [complete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-correct" }) : !open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }) : null, s.label]
						})
					}, s.id);
				})
			})]
		}),
		stage === "intro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-base leading-relaxed text-fg",
						children: lesson.intro
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm text-muted",
						children: lesson.tip
					}),
					lesson.module === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeRowRest, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-widest text-subtle uppercase",
						children: lesson.keys.length > 4 ? "Keys in this lesson" : "New keys"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: lesson.keys.map((k, i) => {
							const f = fingerFor(k);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setDemoIdx(i),
								className: cn("inline-flex min-h-14 min-w-14 flex-col items-center justify-center gap-1 rounded-md border px-3 py-2 font-mono", i === demoIdx ? "key-pulse border-primary bg-primary/10 text-fg" : "border-border bg-surface text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg leading-none",
									children: keyLabel(k)
								}), f && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 font-sans text-xs tracking-normal",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", FINGER_COLOR_CLASS[f]) }), FINGER_LABEL[f].replace(" finger", "").replace("Left ", "L ").replace("Right ", "R ")]
								})]
							}, `${k}-${i}`);
						})
					})] }),
					finger && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Use your ",
							FINGER_LABEL[finger].toLowerCase(),
							shift ? ` and ${shift} Shift` : "",
							" for",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-fg",
								children: keyLabel(demoChar ?? "")
							}),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => goStage("keys"),
						children: ["Start key drills", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coach, {
				nextChar,
				highlightKeys: lesson.keys
			})]
		}) : last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md space-y-5 py-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: cn("font-mono text-6xl font-medium tracking-tight tabular-nums", passedThis ? "text-correct" : "text-incorrect"),
					children: [Math.round(last.accuracy), "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						last.wpm,
						" WPM · ",
						last.incorrectChars,
						" ",
						last.incorrectChars === 1 ? "error" : "errors"
					]
				}),
				passedThis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "success",
					children: stage === "sentences" ? "Lesson complete" : `Stage passed · 95%`
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-incorrect",
					children: [
						"Need ",
						95,
						"% accuracy to ",
						stage === "sentences" ? "unlock the next lesson" : "advance",
						"."
					]
				}),
				missed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap justify-center gap-1.5",
					children: missed.map(([ch, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-md border border-border bg-surface px-2 py-1 font-mono text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: ch === " " ? "space" : ch
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: n
						})]
					}, ch))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								setLast(null);
								setSeed((n) => n + 1);
							},
							children: "Repeat"
						}),
						passedThis && nextStageAfter(stage) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => goStage(nextStageAfter(stage)),
							children: ["Next stage", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}),
						stage === "sentences" && passedThis && nextLesson && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/learn/$lessonId",
								params: { lessonId: nextLesson.id },
								children: "Next lesson"
							})
						}),
						stage === "sentences" && passedThis && !nextLesson && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/learn",
								children: "Academy complete"
							})
						})
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [
				finger && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center justify-center gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", FINGER_COLOR_CLASS[finger]) }),
						FINGER_LABEL[finger],
						shift ? ` + ${shift === "left" ? "Left" : "Right"} Shift` : "",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-fg",
							children: ["· ", nextChar === " " ? "space" : nextChar ?? ""]
						})
					]
				}),
				snap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsBar, { snap }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingArena, {
					text,
					onSnapshot: setSnap,
					onFinish
				}, `${lesson.id}-${stage}-${seed}`),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coach, { nextChar })
			]
		})
	] });
}
function Coach({ nextChar, highlightKeys }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyboardGuide, {
				nextChar,
				highlightKeys
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hands, { nextChar }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerLegend, {})
		]
	});
}
//#endregion
export { LessonPage as component };

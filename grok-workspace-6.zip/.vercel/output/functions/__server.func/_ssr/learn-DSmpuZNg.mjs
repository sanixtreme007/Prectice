import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as cn } from "./Logo-25CrJJly.mjs";
import { _ as ArrowRight, h as Check, u as Lock } from "../_libs/lucide-react.mjs";
import { _ as useProgress, o as PageTitle } from "./router-DjO1jKnB.mjs";
import { n as CardDescription, r as CardTitle, t as Card } from "./card-Ci2beFk3.mjs";
import { t as FingerLegend } from "./Hands-BKEIh7A7.mjs";
import { t as Badge } from "./badge-RTERXHL8.mjs";
import { a as keyLabel, i as isLessonUnlocked, n as MODULES, s as nextOpenLesson, t as LESSONS } from "./lessons-BjyAdrU4.mjs";
import { t as Progress } from "./progress-DDEThDjb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-DSmpuZNg.js
var import_jsx_runtime = require_jsx_runtime();
function Learn() {
	const completed = useProgress((s) => s.completedLessons);
	const lessonBest = useProgress((s) => s.lessonBest);
	const lessonStages = useProgress((s) => s.lessonStages);
	const done = completed.length;
	const total = LESSONS.length;
	const next = nextOpenLesson(completed);
	const allDone = done >= total;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
			kicker: "Academy",
			title: "Learn to type",
			desc: `Home row first. Each stage unlocks at 95% accuracy.`
		}),
		next && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-8 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-subtle uppercase",
						children: "Continue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold tracking-tight",
						children: next.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Module ",
							next.module,
							" · ",
							next.moduleTitle
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-mono text-xs text-subtle",
						children: next.keys.slice(0, 8).map(keyLabel).join("  ")
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/learn/$lessonId",
					params: { lessonId: next.id },
					children: [completed.length === 0 ? "Start first lesson" : "Continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})
			})]
		}),
		allDone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-8 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-semibold tracking-tight",
				children: "Academy complete"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Every lesson passed at ",
					95,
					"%. Keep the feel in Practice, Exam, or a Race."
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
				value: done / total * 100,
				className: "max-w-xs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums text-muted",
				children: [
					done,
					"/",
					total
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerLegend, { className: "mb-10 justify-start" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-10",
			children: MODULES.map((mod) => {
				const items = LESSONS.filter((l) => l.module === mod.id);
				const modDone = items.filter((l) => completed.includes(l.id)).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-medium tracking-widest text-subtle uppercase",
							children: ["Module ", mod.id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-semibold tracking-tight",
							children: mod.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: mod.blurb
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: modDone === items.length ? "success" : "secondary",
						children: [
							modDone,
							"/",
							items.length
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: items.map((lesson) => {
						const open = isLessonUnlocked(lesson.id, completed);
						const best = lessonBest[lesson.id];
						const passed = completed.includes(lesson.id);
						const stages = lessonStages[lesson.id] ?? [];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: cn("p-0", !open && "opacity-70", open && "transition-colors hover:border-border-strong"),
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/learn/$lessonId",
								params: { lessonId: lesson.id },
								className: "block p-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonInner, {
									lesson,
									best,
									passed,
									locked: false,
									stages
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonInner, {
									lesson,
									best,
									passed: false,
									locked: true,
									stages: []
								})
							})
						}, lesson.id);
					})
				})] }, mod.id);
			})
		})
	] });
}
function LessonInner({ lesson, best, passed, locked, stages }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("mt-0.5 grid size-8 shrink-0 place-items-center rounded-full", passed ? "bg-correct/15 text-correct" : locked ? "bg-surface-2 text-subtle" : "bg-primary/10 text-primary"),
			children: passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs",
				children: keyLabel(lesson.keys[0] ?? "").slice(0, 2)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: lesson.title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
					className: "mt-1 line-clamp-2",
					children: lesson.intro
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-mono text-xs text-subtle",
					children: [lesson.keys.slice(0, 8).map(keyLabel).join("  "), best ? `  ·  ${Math.round(best.accuracy)}%  ·  ${best.wpm} wpm` : ""]
				}),
				!locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 flex gap-1 text-xs tracking-wide text-subtle uppercase",
					children: [
						"keys",
						"words",
						"sentences"
					].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("rounded-sm px-1.5 py-0.5", stages.includes(s) || passed ? "bg-correct/15 text-correct" : "bg-surface-2"),
						children: s
					}, s))
				})
			]
		})]
	});
}
//#endregion
export { Learn as component };

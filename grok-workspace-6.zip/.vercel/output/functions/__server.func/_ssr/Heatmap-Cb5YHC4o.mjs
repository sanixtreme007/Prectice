import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as cn } from "./Logo-25CrJJly.mjs";
import { r as FINGER_LABEL, t as FINGER_COLOR_CLASS } from "./keymap-V0YgG9Z2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Heatmap-Cb5YHC4o.js
var import_jsx_runtime = require_jsx_runtime();
var ORDER = [
	"LP",
	"LR",
	"LM",
	"LI",
	"TH",
	"RI",
	"RM",
	"RR",
	"RP"
];
function FingerHeatmap({ errors }) {
	const max = Math.max(1, ...ORDER.map((id) => errors[id] ?? 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mb-3 text-sm font-medium text-muted",
		children: "Finger errors"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-3 gap-2 sm:grid-cols-9",
		children: ORDER.map((id) => {
			const n = errors[id] ?? 0;
			const heat = n / max;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-1.5 rounded-lg border border-border bg-surface px-1 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("size-3 rounded-full", FINGER_COLOR_CLASS[id]),
						style: { opacity: .35 + heat * .65 }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-sm tabular-nums",
						children: n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-center text-[10px] leading-tight text-subtle",
						children: FINGER_LABEL[id].replace(" ", "\n")
					})
				]
			}, id);
		})
	})] });
}
//#endregion
export { FingerHeatmap as t };

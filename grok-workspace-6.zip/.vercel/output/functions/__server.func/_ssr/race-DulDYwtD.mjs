import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button } from "./Logo-25CrJJly.mjs";
import { o as PageTitle } from "./router-DjO1jKnB.mjs";
import { n as CardDescription, r as CardTitle, t as Card } from "./card-Ci2beFk3.mjs";
import { t as Label } from "./label-Cncy-_Dg.mjs";
import { t as Input } from "./input-DeI5ynzg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/race-DulDYwtD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function randomCode() {
	const chars = "abcdefghjkmnpqrstuvwxyz23456789";
	let s = "";
	for (let i = 0; i < 6; i += 1) s += chars[Math.floor(Math.random() * 31)];
	return s;
}
function RaceLobby() {
	const navigate = useNavigate();
	const [code, setCode] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("Typist");
	const go = (room) => {
		if (typeof sessionStorage !== "undefined") sessionStorage.setItem("ta-racer", name.trim() || "Typist");
		navigate({
			to: "/race/$roomId",
			params: { roomId: room.toLowerCase() }
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTitle, {
		kicker: "Casual race",
		title: "Type against friends",
		desc: "Create a private room and share the link. Up to eight people. This is a friendly race, not a ranked board."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Your name" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
					className: "mt-1 mb-3",
					children: "Shown next to your progress bar."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value.slice(0, 24)),
					maxLength: 24
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Create a room" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
					className: "mt-1 mb-3",
					children: "You become the host and start the countdown."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: () => go(randomCode()),
					children: "Create room"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "sm:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Join with a code" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
						className: "mt-1 mb-3",
						children: "Six letters from an invite."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "sr-only",
								htmlFor: "code",
								children: "Room code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "code",
								value: code,
								onChange: (e) => setCode(e.target.value.replace(/[^a-zA-Z0-9]/g, "").slice(0, 8)),
								placeholder: "abc123",
								className: "font-mono uppercase"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								disabled: code.length < 4,
								onClick: () => go(code),
								children: "Join"
							})
						]
					})
				]
			})
		]
	})] });
}
//#endregion
export { RaceLobby as component };

import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button } from "./Logo-25CrJJly.mjs";
import { s as RotateCcw } from "../_libs/lucide-react.mjs";
import { d as SignedOut, u as SignedIn } from "./router-DjO1jKnB.mjs";
import { t as FingerHeatmap } from "./Heatmap-Cb5YHC4o.mjs";
import { a as CartesianGrid, i as Line, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ResultsPanel-BInX1w13.js
var import_jsx_runtime = require_jsx_runtime();
function ResultsPanel({ result, onRestart, onPost, posting, posted, showWeakLink }) {
	const data = result.samples.map((s) => ({
		t: Math.round(s.t),
		wpm: s.wpm,
		raw: s.rawWpm
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-3xl space-y-8 px-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
						n: result.wpm,
						l: "WPM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
						n: `${Math.round(result.accuracy)}%`,
						l: "Accuracy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
						n: result.rawWpm,
						l: "Raw WPM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
						n: result.cpm,
						l: "CPM"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-48 rounded-xl border border-border bg-surface p-3 sm:h-56",
				children: data.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "currentColor",
								strokeOpacity: .08
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "t",
								tick: { fontSize: 11 },
								stroke: "currentColor",
								opacity: .4
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: { fontSize: 11 },
								stroke: "currentColor",
								opacity: .4
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--surface)",
								border: "1px solid var(--border)",
								borderRadius: 8
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "wpm",
								stroke: "var(--primary)",
								dot: false,
								strokeWidth: 2
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "raw",
								stroke: "var(--muted)",
								dot: false,
								strokeWidth: 1.5,
								strokeDasharray: "4 4"
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-full place-items-center text-sm text-muted",
					children: "Not enough samples"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerHeatmap, { errors: result.fingerErrors }),
			result.weakWords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-medium text-muted",
				children: "Words to retest"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: result.weakWords.slice(0, 16).map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-incorrect/10 px-2.5 py-1 font-mono text-xs text-incorrect",
					children: w
				}, w))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onRestart,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Try again"]
					}),
					showWeakLink && result.weakWords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							search: { weak: "1" },
							children: "Practice weak words"
						})
					}),
					onPost && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onPost,
						disabled: posting || posted,
						children: posted ? "Posted" : posting ? "Posting…" : "Post to leaderboard"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							children: "Sign in to post"
						})
					}) })] })
				]
			})
		]
	});
}
function Big({ n, l }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-surface px-3 py-4 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-3xl font-medium tabular-nums text-primary",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] font-medium tracking-widest text-subtle uppercase",
			children: l
		})]
	});
}
//#endregion
export { ResultsPanel as t };

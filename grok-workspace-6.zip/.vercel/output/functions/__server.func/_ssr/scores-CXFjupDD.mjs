import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { A as array, B as string, I as number, L as object, O as _enum, z as record } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-v8Sr7Eo2.mjs";
import { t as authMiddleware } from "./middleware-4wpbacDb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scores-CXFjupDD.js
var scoreInput = object({
	mode: string().min(1).max(32),
	category: string().min(1).max(32),
	wpm: number().int().min(0).max(400),
	rawWpm: number().int().min(0).max(400),
	accuracy: number().min(0).max(100),
	durationMs: number().int().min(0).max(36e5),
	displayName: string().min(1).max(64)
});
var saveScore_createServerFn_handler = createServerRpc({
	id: "c6d628ac7131f69283a166eb15965a8c91a13d780ff3934c16becff637081dfc",
	name: "saveScore",
	filename: "src/lib/server/scores.ts"
}, (opts) => saveScore.__executeServer(opts));
var saveScore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(scoreInput).handler(saveScore_createServerFn_handler, async ({ data, context }) => {
	return { id: (await (await getSql())`
      insert into typing_scores (user_id, display_name, mode, category, wpm, raw_wpm, accuracy, duration_ms)
      values (${context.userId}, ${data.displayName}, ${data.mode}, ${data.category}, ${data.wpm}, ${data.rawWpm}, ${data.accuracy}, ${data.durationMs})
      returning id
    `)[0]?.id ?? 0 };
});
var progressShape = object({
	xp: number().int().min(0),
	streak: number().int().min(0),
	lastPracticeDate: string().nullable(),
	completedLessons: array(string()),
	lessonBest: record(string(), object({
		accuracy: number(),
		wpm: number()
	})),
	weakWords: array(string()),
	letterErrors: record(string(), number()),
	fingerErrors: record(string(), number()),
	testsCompleted: number().int().min(0),
	bestWpm: number().int().min(0)
});
var saveMyProgress_createServerFn_handler = createServerRpc({
	id: "c428c63227d3489038af86ff910a460bcade144fffbb328f444886d9e6f8b755",
	name: "saveMyProgress",
	filename: "src/lib/server/scores.ts"
}, (opts) => saveMyProgress.__executeServer(opts));
var saveMyProgress = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(progressShape).handler(saveMyProgress_createServerFn_handler, async ({ data, context }) => {
	await (await getSql()).query(`insert into typing_progress
         (user_id, xp, streak, last_practice_date, completed_lessons, lesson_best, weak_words, letter_errors, finger_errors, tests_completed, best_wpm, updated_at)
       values ($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7::jsonb,$8::jsonb,$9::jsonb,$10,$11, now())
       on conflict (user_id) do update set
         xp = greatest(typing_progress.xp, excluded.xp),
         streak = greatest(typing_progress.streak, excluded.streak),
         last_practice_date = excluded.last_practice_date,
         completed_lessons = excluded.completed_lessons,
         lesson_best = excluded.lesson_best,
         weak_words = excluded.weak_words,
         letter_errors = excluded.letter_errors,
         finger_errors = excluded.finger_errors,
         tests_completed = greatest(typing_progress.tests_completed, excluded.tests_completed),
         best_wpm = greatest(typing_progress.best_wpm, excluded.best_wpm),
         updated_at = now()`, [
		context.userId,
		data.xp,
		data.streak,
		data.lastPracticeDate,
		JSON.stringify(data.completedLessons),
		JSON.stringify(data.lessonBest),
		JSON.stringify(data.weakWords),
		JSON.stringify(data.letterErrors),
		JSON.stringify(data.fingerErrors),
		data.testsCompleted,
		data.bestWpm
	]);
	return { ok: true };
});
var getMyProgress_createServerFn_handler = createServerRpc({
	id: "a0573d1b751b77045e3ee4339eec213d23ec83789b0c2577e4cf44c735077a18",
	name: "getMyProgress",
	filename: "src/lib/server/scores.ts"
}, (opts) => getMyProgress.__executeServer(opts));
var getMyProgress = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMyProgress_createServerFn_handler, async ({ context }) => {
	const row = (await (await getSql())`
      select xp, streak, last_practice_date, completed_lessons, lesson_best, weak_words, letter_errors, finger_errors, tests_completed, best_wpm
      from typing_progress where user_id = ${context.userId}
    `)[0];
	if (!row) return null;
	return {
		xp: row.xp,
		streak: row.streak,
		lastPracticeDate: row.last_practice_date,
		completedLessons: row.completed_lessons ?? [],
		lessonBest: row.lesson_best ?? {},
		weakWords: row.weak_words ?? [],
		letterErrors: row.letter_errors ?? {},
		fingerErrors: row.finger_errors ?? {},
		testsCompleted: row.tests_completed,
		bestWpm: row.best_wpm
	};
});
var boardInput = object({ scope: _enum([
	"daily",
	"all",
	"exam",
	"lesson"
]) });
var getLeaderboard_createServerFn_handler = createServerRpc({
	id: "30129300866a8a8b25c7fe2c04515620e2ec95b462407eff268dde1fb8bbf99d",
	name: "getLeaderboard",
	filename: "src/lib/server/scores.ts"
}, (opts) => getLeaderboard.__executeServer(opts));
var getLeaderboard = createServerFn({ method: "GET" }).validator(boardInput).handler(getLeaderboard_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const filter = data.scope === "exam" ? "mode = 'exam'" : data.scope === "lesson" ? "mode = 'lesson'" : data.scope === "daily" ? "created_at >= date_trunc('day', now())" : "true";
	return await sql.query(`select display_name, mode, category, wpm, accuracy, created_at
       from typing_scores
       where ${filter}
       order by wpm desc, accuracy desc, created_at asc
       limit 50`);
});
//#endregion
export { getLeaderboard_createServerFn_handler, getMyProgress_createServerFn_handler, saveMyProgress_createServerFn_handler, saveScore_createServerFn_handler };

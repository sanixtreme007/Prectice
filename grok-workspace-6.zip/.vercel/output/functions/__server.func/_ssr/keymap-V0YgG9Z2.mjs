//#region node_modules/.nitro/vite/services/ssr/assets/keymap-V0YgG9Z2.js
var FINGER_LABEL = {
	LP: "Left pinky",
	LR: "Left ring",
	LM: "Left middle",
	LI: "Left index",
	TH: "Thumb",
	RI: "Right index",
	RM: "Right middle",
	RR: "Right ring",
	RP: "Right pinky"
};
var FINGER_COLOR_CLASS = {
	LP: "bg-finger-lp",
	LR: "bg-finger-lr",
	LM: "bg-finger-lm",
	LI: "bg-finger-li",
	TH: "bg-finger-th",
	RI: "bg-finger-ri",
	RM: "bg-finger-rm",
	RR: "bg-finger-rr",
	RP: "bg-finger-rp"
};
var FINGER_FILL_CLASS = {
	LP: "fill-finger-lp",
	LR: "fill-finger-lr",
	LM: "fill-finger-lm",
	LI: "fill-finger-li",
	TH: "fill-finger-th",
	RI: "fill-finger-ri",
	RM: "fill-finger-rm",
	RR: "fill-finger-rr",
	RP: "fill-finger-rp"
};
var KEY_FINGER = {
	"`": "LP",
	"1": "LP",
	"2": "LR",
	"3": "LM",
	"4": "LI",
	"5": "LI",
	"6": "RI",
	"7": "RI",
	"8": "RM",
	"9": "RR",
	"0": "RP",
	"-": "RP",
	"=": "RP",
	q: "LP",
	w: "LR",
	e: "LM",
	r: "LI",
	t: "LI",
	y: "RI",
	u: "RI",
	i: "RM",
	o: "RR",
	p: "RP",
	"[": "RP",
	"]": "RP",
	"\\": "RP",
	a: "LP",
	s: "LR",
	d: "LM",
	f: "LI",
	g: "LI",
	h: "RI",
	j: "RI",
	k: "RM",
	l: "RR",
	";": "RP",
	"'": "RP",
	z: "LP",
	x: "LR",
	c: "LM",
	v: "LI",
	b: "LI",
	n: "RI",
	m: "RI",
	",": "RM",
	".": "RR",
	"/": "RP",
	" ": "TH",
	enter: "RP",
	backspace: "RP",
	tab: "LP",
	shiftleft: "LP",
	shiftright: "RP"
};
var SHIFT_PAIRS = {
	"~": "`",
	"!": "1",
	"@": "2",
	"#": "3",
	$: "4",
	"%": "5",
	"^": "6",
	"&": "7",
	"*": "8",
	"(": "9",
	")": "0",
	_: "-",
	"+": "=",
	"{": "[",
	"}": "]",
	"|": "\\",
	":": ";",
	"\"": "'",
	"<": ",",
	">": ".",
	"?": "/"
};
function baseKey(char) {
	if (char === " ") return " ";
	if (char.length !== 1) return char.toLowerCase();
	if (/[A-Z]/.test(char)) return char.toLowerCase();
	return SHIFT_PAIRS[char] ?? char.toLowerCase();
}
function needsShift(char) {
	if (char.length !== 1) return false;
	if (/[A-Z]/.test(char)) return true;
	return char in SHIFT_PAIRS;
}
function shiftHand(char) {
	if (!needsShift(char)) return null;
	const finger = fingerFor(char);
	if (!finger) return "left";
	return finger.startsWith("L") || finger === "TH" ? "right" : "left";
}
function fingerFor(char) {
	return KEY_FINGER[baseKey(char)] ?? null;
}
var KEYBOARD_ROWS = [
	[
		{
			id: "`",
			label: "`",
			width: 1
		},
		{
			id: "1",
			label: "1",
			width: 1
		},
		{
			id: "2",
			label: "2",
			width: 1
		},
		{
			id: "3",
			label: "3",
			width: 1
		},
		{
			id: "4",
			label: "4",
			width: 1
		},
		{
			id: "5",
			label: "5",
			width: 1
		},
		{
			id: "6",
			label: "6",
			width: 1
		},
		{
			id: "7",
			label: "7",
			width: 1
		},
		{
			id: "8",
			label: "8",
			width: 1
		},
		{
			id: "9",
			label: "9",
			width: 1
		},
		{
			id: "0",
			label: "0",
			width: 1
		},
		{
			id: "-",
			label: "-",
			width: 1
		},
		{
			id: "=",
			label: "=",
			width: 1
		},
		{
			id: "backspace",
			label: "⌫",
			width: 2
		}
	],
	[
		{
			id: "tab",
			label: "tab",
			width: 1.6
		},
		{
			id: "q",
			label: "Q",
			width: 1
		},
		{
			id: "w",
			label: "W",
			width: 1
		},
		{
			id: "e",
			label: "E",
			width: 1
		},
		{
			id: "r",
			label: "R",
			width: 1
		},
		{
			id: "t",
			label: "T",
			width: 1
		},
		{
			id: "y",
			label: "Y",
			width: 1
		},
		{
			id: "u",
			label: "U",
			width: 1
		},
		{
			id: "i",
			label: "I",
			width: 1
		},
		{
			id: "o",
			label: "O",
			width: 1
		},
		{
			id: "p",
			label: "P",
			width: 1
		},
		{
			id: "[",
			label: "[",
			width: 1
		},
		{
			id: "]",
			label: "]",
			width: 1
		},
		{
			id: "\\",
			label: "\\",
			width: 1.4
		}
	],
	[
		{
			id: "caps",
			label: "caps",
			width: 1.9
		},
		{
			id: "a",
			label: "A",
			width: 1
		},
		{
			id: "s",
			label: "S",
			width: 1
		},
		{
			id: "d",
			label: "D",
			width: 1
		},
		{
			id: "f",
			label: "F",
			width: 1,
			home: true
		},
		{
			id: "g",
			label: "G",
			width: 1
		},
		{
			id: "h",
			label: "H",
			width: 1
		},
		{
			id: "j",
			label: "J",
			width: 1,
			home: true
		},
		{
			id: "k",
			label: "K",
			width: 1
		},
		{
			id: "l",
			label: "L",
			width: 1
		},
		{
			id: ";",
			label: ";",
			width: 1
		},
		{
			id: "'",
			label: "'",
			width: 1
		},
		{
			id: "enter",
			label: "enter",
			width: 2.1
		}
	],
	[
		{
			id: "shiftleft",
			label: "shift",
			width: 2.4
		},
		{
			id: "z",
			label: "Z",
			width: 1
		},
		{
			id: "x",
			label: "X",
			width: 1
		},
		{
			id: "c",
			label: "C",
			width: 1
		},
		{
			id: "v",
			label: "V",
			width: 1
		},
		{
			id: "b",
			label: "B",
			width: 1
		},
		{
			id: "n",
			label: "N",
			width: 1
		},
		{
			id: "m",
			label: "M",
			width: 1
		},
		{
			id: ",",
			label: ",",
			width: 1
		},
		{
			id: ".",
			label: ".",
			width: 1
		},
		{
			id: "/",
			label: "/",
			width: 1
		},
		{
			id: "shiftright",
			label: "shift",
			width: 2.6
		}
	],
	[
		{
			id: "ctrlleft",
			label: "ctrl",
			width: 1.4
		},
		{
			id: "altleft",
			label: "alt",
			width: 1.4
		},
		{
			id: " ",
			label: "",
			width: 8.2
		},
		{
			id: "altright",
			label: "alt",
			width: 1.4
		},
		{
			id: "ctrlright",
			label: "ctrl",
			width: 1.6
		}
	]
];
function fingerForKeyId(id) {
	if (id === "caps") return "LP";
	if (id === "ctrlleft" || id === "altleft") return "LP";
	if (id === "ctrlright" || id === "altright") return "RP";
	return KEY_FINGER[id] ?? null;
}
//#endregion
export { baseKey as a, needsShift as c, KEYBOARD_ROWS as i, shiftHand as l, FINGER_FILL_CLASS as n, fingerFor as o, FINGER_LABEL as r, fingerForKeyId as s, FINGER_COLOR_CLASS as t };

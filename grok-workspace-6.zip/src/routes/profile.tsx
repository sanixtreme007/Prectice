import { createFileRoute, Link } from "@tanstack/react-router";
import { PageTitle } from "@/components/layout/AppShell";
import { FingerHeatmap } from "@/components/typing/Heatmap";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useProgress } from "@/lib/store/progress";
import { SWITCHES, THEMES, useSettings } from "@/lib/store/settings";
import { LESSONS } from "@/lib/typing/lessons";

export const Route = createFileRoute("/profile")({ component: Profile });

function Profile() {
  const { user, isPending } = useCurrentUserState();
  const xp = useProgress((s) => s.xp);
  const streak = useProgress((s) => s.streak);
  const tests = useProgress((s) => s.testsCompleted);
  const best = useProgress((s) => s.bestWpm);
  const completed = useProgress((s) => s.completedLessons);
  const recent = useProgress((s) => s.recent);
  const letterErrors = useProgress((s) => s.letterErrors);
  const fingerErrors = useProgress((s) => s.fingerErrors);
  const weakWords = useProgress((s) => s.weakWords);
  const settings = useSettings();

  const topLetters = Object.entries(letterErrors)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  return (
    <div>
      <PageTitle kicker="You" title="Profile & settings" desc="Local progress always. Cloud sync when you sign in." />

      <div className="mb-8 flex flex-wrap items-center gap-3">
        {isPending ? (
          <div className="h-8 w-40 animate-pulse rounded-full bg-surface-2" />
        ) : user ? (
          <div className="flex items-center gap-3">
            <UserButton />
            <span className="text-sm text-muted">Saved to this account</span>
          </div>
        ) : (
          <SignedOut>
            <Button asChild>
              <Link to="/login">Sign in to sync</Link>
            </Button>
          </SignedOut>
        )}
        <SignedIn>
          <span className="sr-only">signed in</span>
        </SignedIn>
      </div>

      <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat n={xp} l="XP" />
        <Stat n={`${streak}d`} l="Streak" />
        <Stat n={best} l="Best WPM" />
        <Stat n={`${completed.length}/${LESSONS.length}`} l="Lessons" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardTitle>Settings</CardTitle>
          <CardDescription className="mb-4">Applies on every test.</CardDescription>
          <div className="space-y-5">
            <div>
              <Label className="mb-2 block">Theme</Label>
              <div className="flex flex-wrap gap-2">
                {THEMES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => settings.setTheme(t.id)}
                    className={`rounded-full border px-3 py-1.5 text-xs ${
                      settings.theme === t.id
                        ? "border-primary text-primary"
                        : "border-border text-muted"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Key sound</Label>
              <div className="flex flex-wrap gap-2">
                {SWITCHES.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => settings.setSound(s.id)}
                    className={`rounded-full border px-3 py-1.5 text-xs ${
                      settings.sound === s.id
                        ? "border-primary text-primary"
                        : "border-border text-muted"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Text size · {settings.fontSize}px</Label>
              <Slider
                min={20}
                max={40}
                step={2}
                value={[settings.fontSize]}
                onValueChange={(v) => settings.setFontSize(v[0] ?? 28)}
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="kb">On-screen keyboard</Label>
              <Switch
                id="kb"
                checked={settings.showKeyboard}
                onCheckedChange={settings.setShowKeyboard}
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="hands">Finger guide</Label>
              <Switch id="hands" checked={settings.showHands} onCheckedChange={settings.setShowHands} />
            </div>
          </div>
        </Card>

        <Card>
          <CardTitle>Recent tests</CardTitle>
          <CardDescription className="mb-4">{tests} completed on this device.</CardDescription>
          <ul className="space-y-2">
            {recent.length === 0 && <li className="text-sm text-muted">No tests yet.</li>}
            {recent.slice(0, 8).map((r) => (
              <li key={r.at} className="flex justify-between gap-3 font-mono text-sm">
                <span className="text-muted">
                  {r.mode}/{r.category}
                </span>
                <span>
                  {r.wpm} wpm · {Math.round(r.accuracy)}%
                </span>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <FingerHeatmap errors={fingerErrors} />
          {topLetters.length > 0 && (
            <div className="mt-4">
              <p className="mb-2 text-sm text-muted">Problem letters</p>
              <div className="flex flex-wrap gap-1.5">
                {topLetters.map(([k, n]) => (
                  <span key={k} className="rounded-md bg-surface-2 px-2 py-1 font-mono text-xs">
                    {k} · {n}
                  </span>
                ))}
              </div>
            </div>
          )}
        </Card>

        <Card>
          <CardTitle>Weak words</CardTitle>
          <CardDescription className="mb-3">Missed in recent sessions.</CardDescription>
          {weakWords.length === 0 ? (
            <p className="text-sm text-muted">Clean so far.</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {weakWords.slice(0, 24).map((w) => (
                <span key={w} className="rounded-full bg-incorrect/10 px-2 py-1 font-mono text-xs text-incorrect">
                  {w}
                </span>
              ))}
            </div>
          )}
          {weakWords.length > 0 && (
            <Button className="mt-4" variant="outline" size="sm" asChild>
              <Link to="/" search={{ weak: "1" }}>
                Practice them
              </Link>
            </Button>
          )}
        </Card>
      </div>
    </div>
  );
}

function Stat({ n, l }: { n: string | number; l: string }) {
  return (
    <Card className="text-center">
      <div className="font-mono text-2xl font-medium tabular-nums text-primary">{n}</div>
      <div className="mt-1 text-[11px] tracking-widest text-subtle uppercase">{l}</div>
    </Card>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-4">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6 shadow-soft">
        <Logo className="mb-6 justify-center" />
        <h1 className="text-center text-xl font-semibold tracking-tight">Save your progress</h1>
        <p className="mt-1 mb-6 text-center text-sm text-muted">
          Sign in to sync lessons, streaks, and the leaderboard. Practice still works as a guest.
        </p>
        {authEnabled ? (
          <div className="space-y-2">
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant={p.label === "Google" ? "default" : "outline"}
                className="w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        ) : (
          <p className="text-center text-sm text-muted">Sign-in is disabled.</p>
        )}
        <p className="mt-6 text-center">
          <Link to="/" className="text-sm text-primary hover:underline">
            Continue as guest
          </Link>
        </p>
      </div>
    </main>
  );
}

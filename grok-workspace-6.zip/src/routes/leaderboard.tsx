import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageTitle } from "@/components/layout/AppShell";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getLeaderboard } from "@/lib/server/scores";

export const Route = createFileRoute("/leaderboard")({ component: Board });

type Scope = "daily" | "all" | "exam" | "lesson";

type Row = {
  display_name: string;
  mode: string;
  category: string;
  wpm: number;
  accuracy: number;
  created_at: string;
};

function Board() {
  const [scope, setScope] = useState<Scope>("daily");
  const [rows, setRows] = useState<Row[] | null>(null);

  useEffect(() => {
    let live = true;
    setRows(null);
    void getLeaderboard({ data: { scope } }).then((r) => {
      if (live) setRows(r);
    });
    return () => {
      live = false;
    };
  }, [scope]);

  return (
    <div>
      <PageTitle
        kicker="Global"
        title="Leaderboard"
        desc="Daily, all-time, exam, and academy scores. Sign in after a test to post yours."
      />
      <Tabs value={scope} onValueChange={(v) => setScope(v as Scope)}>
        <TabsList>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="all">All-time</TabsTrigger>
          <TabsTrigger value="exam">Exam</TabsTrigger>
          <TabsTrigger value="lesson">Academy</TabsTrigger>
        </TabsList>
        <TabsContent value={scope}>
          <Card className="overflow-x-auto p-0">
            <table className="w-full min-w-[32rem] text-left text-sm">
              <thead className="border-b border-border text-xs tracking-wide text-subtle uppercase">
                <tr>
                  <th className="px-4 py-3 font-medium">#</th>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Mode</th>
                  <th className="px-4 py-3 font-medium">WPM</th>
                  <th className="px-4 py-3 font-medium">Acc</th>
                </tr>
              </thead>
              <tbody>
                {rows == null && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-muted">
                      Loading…
                    </td>
                  </tr>
                )}
                {rows && rows.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-muted">
                      No scores yet. Finish a test and post it.
                    </td>
                  </tr>
                )}
                {rows?.map((r, i) => (
                  <tr key={`${r.display_name}-${r.created_at}-${i}`} className="border-b border-border last:border-0">
                    <td className="px-4 py-3 font-mono tabular-nums text-subtle">{i + 1}</td>
                    <td className="px-4 py-3 font-medium">{r.display_name}</td>
                    <td className="px-4 py-3 text-muted">
                      {r.mode} · {r.category}
                    </td>
                    <td className="px-4 py-3 font-mono tabular-nums text-primary">{r.wpm}</td>
                    <td className="px-4 py-3 font-mono tabular-nums">{Math.round(r.accuracy)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

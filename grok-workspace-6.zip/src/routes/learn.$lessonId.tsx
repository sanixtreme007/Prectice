import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Check, Lock } from "lucide-react";
import { FingerLegend, Hands, HomeRowRest } from "@/components/typing/Hands";
import { KeyboardGuide } from "@/components/typing/KeyboardGuide";
import { StatsBar, TypingArena } from "@/components/typing/TypingArena";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { pushProgress } from "@/components/layout/CloudSync";
import { useProgress } from "@/lib/store/progress";
import { xpForResult, type EngineSnapshot, type TestResult } from "@/lib/typing/engine";
import { FINGER_COLOR_CLASS, FINGER_LABEL, fingerFor, shiftHand } from "@/lib/typing/keymap";
import {
  LESSONS,
  STAGE_FLOW,
  UNLOCK_ACCURACY,
  isLessonUnlocked,
  keyLabel,
  lessonById,
  nextStageAfter,
  stageText,
  stageUnlocked,
  type DrillStage,
  type LessonStage,
} from "@/lib/typing/lessons";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/learn/$lessonId")({ component: LessonPage });

function LessonPage() {
  const { lessonId } = Route.useParams();
  const lesson = lessonById(lessonId);
  const completed = useProgress((s) => s.completedLessons);
  const lessonStages = useProgress((s) => s.lessonStages);
  const applyResult = useProgress((s) => s.applyResult);
  const [stage, setStage] = useState<LessonStage>("intro");
  const [seed, setSeed] = useState(0);
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [last, setLast] = useState<TestResult | null>(null);
  const [demoIdx, setDemoIdx] = useState(0);

  const done = lesson ? (lessonStages[lesson.id] ?? []) : [];
  const text = useMemo(() => (lesson ? stageText(lesson, stage) : ""), [lesson, stage]);

  useEffect(() => {
    setStage("intro");
    setLast(null);
    setSnap(null);
    setSeed(0);
    setDemoIdx(0);
  }, [lessonId]);

  useEffect(() => {
    if (stage !== "intro" || !lesson?.keys.length) return;
    const id = window.setInterval(() => {
      setDemoIdx((n) => (n + 1) % lesson.keys.length);
    }, 1400);
    return () => window.clearInterval(id);
  }, [stage, lesson]);

  if (!lesson) return <Navigate to="/learn" />;
  if (!isLessonUnlocked(lesson.id, completed)) return <Navigate to="/learn" />;

  const idx = LESSONS.findIndex((l) => l.id === lesson.id);
  const nextLesson = LESSONS[idx + 1];
  const demoChar = lesson.keys[demoIdx] ?? lesson.keys[0] ?? null;
  const liveChar = snap?.text[snap.caret] ?? null;
  const nextChar = stage === "intro" || last ? demoChar : liveChar;
  const finger = nextChar ? fingerFor(nextChar) : null;
  const shift = nextChar ? shiftHand(nextChar) : null;
  const passedThis = last != null && last.accuracy >= UNLOCK_ACCURACY;
  const drillStage = stage === "intro" ? null : (stage as DrillStage);
  const missed = last
    ? Object.entries(last.letterErrors)
        .filter(([, n]) => n > 0)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
    : [];

  const goStage = (s: LessonStage) => {
    if (!stageUnlocked(s, done) && s !== "intro") return;
    setStage(s);
    setLast(null);
    setSnap(null);
    setSeed((n) => n + 1);
  };

  const onFinish = (res: TestResult) => {
    setLast(res);
    const passed = res.accuracy >= UNLOCK_ACCURACY;
    applyResult({
      result: res,
      mode: "lesson",
      category: lesson.id,
      xp: xpForResult(res, "lesson"),
      lessonId: lesson.id,
      passedLesson: stage === "sentences" && passed,
      lessonStage: drillStage ?? undefined,
      passedStage: passed,
    });
    void pushProgress();
  };

  return (
    <div>
      <Link
        to="/learn"
        className="mb-5 inline-flex min-h-11 items-center gap-1 text-sm text-muted hover:text-fg"
      >
        <ArrowLeft className="size-4" />
        Academy
      </Link>

      <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-medium tracking-widest text-subtle uppercase">
            Module {lesson.module} · {lesson.moduleTitle}
          </p>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{lesson.title}</h1>
        </div>
        <ol className="flex w-full gap-1 lg:w-auto">
          {STAGE_FLOW.map((s) => {
            const open = stageUnlocked(s.id, done);
            const complete = s.id === "intro" ? done.includes("keys") : done.includes(s.id as DrillStage);
            const active = stage === s.id;
            return (
              <li key={s.id} className="flex-1 lg:flex-none">
                <button
                  type="button"
                  disabled={!open}
                  onClick={() => goStage(s.id)}
                  className={cn(
                    "inline-flex h-11 w-full items-center justify-center gap-1.5 rounded-md px-3 text-xs font-medium sm:text-sm",
                    active
                      ? "bg-surface-2 text-fg"
                      : open
                        ? "text-muted hover:bg-surface-2 hover:text-fg"
                        : "cursor-not-allowed text-subtle",
                  )}
                >
                  {complete ? (
                    <Check className="size-3.5 text-correct" />
                  ) : !open ? (
                    <Lock className="size-3.5" />
                  ) : null}
                  {s.label}
                </button>
              </li>
            );
          })}
        </ol>
      </div>

      {stage === "intro" ? (
        <div className="grid items-start gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,22rem)]">
          <div className="space-y-6">
            <p className="max-w-xl text-base leading-relaxed text-fg">{lesson.intro}</p>
            <p className="max-w-xl text-sm text-muted">{lesson.tip}</p>
            {lesson.module === 1 && <HomeRowRest />}
            <div>
              <p className="mb-2 text-xs font-medium tracking-widest text-subtle uppercase">
                {lesson.keys.length > 4 ? "Keys in this lesson" : "New keys"}
              </p>
              <div className="flex flex-wrap gap-2">
                {lesson.keys.map((k, i) => {
                  const f = fingerFor(k);
                  const on = i === demoIdx;
                  return (
                    <button
                      key={`${k}-${i}`}
                      type="button"
                      onClick={() => setDemoIdx(i)}
                      className={cn(
                        "inline-flex min-h-14 min-w-14 flex-col items-center justify-center gap-1 rounded-md border px-3 py-2 font-mono",
                        on ? "key-pulse border-primary bg-primary/10 text-fg" : "border-border bg-surface text-muted",
                      )}
                    >
                      <span className="text-lg leading-none">{keyLabel(k)}</span>
                      {f && (
                        <span className="flex items-center gap-1 font-sans text-xs tracking-normal">
                          <span className={cn("size-1.5 rounded-full", FINGER_COLOR_CLASS[f])} />
                          {FINGER_LABEL[f].replace(" finger", "").replace("Left ", "L ").replace("Right ", "R ")}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
            {finger && (
              <p className="text-sm text-muted">
                Use your {FINGER_LABEL[finger].toLowerCase()}
                {shift ? ` and ${shift} Shift` : ""} for{" "}
                <span className="font-mono text-fg">{keyLabel(demoChar ?? "")}</span>.
              </p>
            )}
            <Button onClick={() => goStage("keys")}>
              Start key drills
              <ArrowRight className="size-4" />
            </Button>
          </div>
          <Coach nextChar={nextChar} highlightKeys={lesson.keys} />
        </div>
      ) : last ? (
        <div className="mx-auto max-w-md space-y-5 py-6 text-center">
          <p
            className={cn(
              "font-mono text-6xl font-medium tracking-tight tabular-nums",
              passedThis ? "text-correct" : "text-incorrect",
            )}
          >
            {Math.round(last.accuracy)}%
          </p>
          <p className="text-sm text-muted">
            {last.wpm} WPM · {last.incorrectChars} {last.incorrectChars === 1 ? "error" : "errors"}
          </p>
          {passedThis ? (
            <Badge variant="success">
              {stage === "sentences" ? "Lesson complete" : `Stage passed · ${UNLOCK_ACCURACY}%`}
            </Badge>
          ) : (
            <p className="text-sm text-incorrect">
              Need {UNLOCK_ACCURACY}% accuracy to {stage === "sentences" ? "unlock the next lesson" : "advance"}.
            </p>
          )}
          {missed.length > 0 && (
            <div className="flex flex-wrap justify-center gap-1.5">
              {missed.map(([ch, n]) => (
                <span
                  key={ch}
                  className="inline-flex items-center gap-1 rounded-md border border-border bg-surface px-2 py-1 font-mono text-xs"
                >
                  <span className="text-fg">{ch === " " ? "space" : ch}</span>
                  <span className="text-subtle">{n}</span>
                </span>
              ))}
            </div>
          )}
          <div className="flex flex-wrap justify-center gap-2 pt-2">
            <Button
              variant="outline"
              onClick={() => {
                setLast(null);
                setSeed((n) => n + 1);
              }}
            >
              Repeat
            </Button>
            {passedThis && nextStageAfter(stage) && (
              <Button onClick={() => goStage(nextStageAfter(stage)!)}>
                Next stage
                <ArrowRight className="size-4" />
              </Button>
            )}
            {stage === "sentences" && passedThis && nextLesson && (
              <Button asChild>
                <Link to="/learn/$lessonId" params={{ lessonId: nextLesson.id }}>
                  Next lesson
                </Link>
              </Button>
            )}
            {stage === "sentences" && passedThis && !nextLesson && (
              <Button asChild>
                <Link to="/learn">Academy complete</Link>
              </Button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {finger && (
            <p className="flex items-center justify-center gap-2 text-sm text-muted">
              <span className={cn("size-2.5 rounded-full", FINGER_COLOR_CLASS[finger])} />
              {FINGER_LABEL[finger]}
              {shift ? ` + ${shift === "left" ? "Left" : "Right"} Shift` : ""}
              <span className="font-mono text-fg">
                · {nextChar === " " ? "space" : (nextChar ?? "")}
              </span>
            </p>
          )}
          {snap && <StatsBar snap={snap} />}
          <TypingArena
            key={`${lesson.id}-${stage}-${seed}`}
            text={text}
            onSnapshot={setSnap}
            onFinish={onFinish}
          />
          <Coach nextChar={nextChar} />
        </div>
      )}
    </div>
  );
}

function Coach({
  nextChar,
  highlightKeys,
}: {
  nextChar: string | null;
  highlightKeys?: string[];
}) {
  return (
    <div className="space-y-5">
      <KeyboardGuide nextChar={nextChar} highlightKeys={highlightKeys} />
      <Hands nextChar={nextChar} />
      <FingerLegend />
    </div>
  );
}

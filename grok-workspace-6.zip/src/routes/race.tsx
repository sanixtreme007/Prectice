import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PageTitle } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/race")({ component: RaceLobby });

function randomCode() {
  const chars = "abcdefghjkmnpqrstuvwxyz23456789";
  let s = "";
  for (let i = 0; i < 6; i += 1) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function RaceLobby() {
  const navigate = useNavigate();
  const [code, setCode] = useState("");
  const [name, setName] = useState("Typist");

  const go = (room: string) => {
    if (typeof sessionStorage !== "undefined") {
      sessionStorage.setItem("ta-racer", name.trim() || "Typist");
    }
    void navigate({ to: "/race/$roomId", params: { roomId: room.toLowerCase() } });
  };

  return (
    <div>
      <PageTitle
        kicker="Casual race"
        title="Type against friends"
        desc="Create a private room and share the link. Up to eight people. This is a friendly race, not a ranked board."
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardTitle>Your name</CardTitle>
          <CardDescription className="mt-1 mb-3">Shown next to your progress bar.</CardDescription>
          <Input value={name} onChange={(e) => setName(e.target.value.slice(0, 24))} maxLength={24} />
        </Card>
        <Card>
          <CardTitle>Create a room</CardTitle>
          <CardDescription className="mt-1 mb-3">You become the host and start the countdown.</CardDescription>
          <Button className="w-full" onClick={() => go(randomCode())}>
            Create room
          </Button>
        </Card>
        <Card className="sm:col-span-2">
          <CardTitle>Join with a code</CardTitle>
          <CardDescription className="mt-1 mb-3">Six letters from an invite.</CardDescription>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Label className="sr-only" htmlFor="code">
              Room code
            </Label>
            <Input
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/[^a-zA-Z0-9]/g, "").slice(0, 8))}
              placeholder="abc123"
              className="font-mono uppercase"
            />
            <Button
              variant="secondary"
              disabled={code.length < 4}
              onClick={() => go(code)}
            >
              Join
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

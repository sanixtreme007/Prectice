import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { Hands } from "@/components/typing/Hands";
import { KeyboardGuide } from "@/components/typing/KeyboardGuide";
import { ResultsPanel } from "@/components/typing/ResultsPanel";
import { StatsBar, TypingArena } from "@/components/typing/TypingArena";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { saveScore } from "@/lib/server/scores";
import { pushProgress } from "@/components/layout/CloudSync";
import { useProgress } from "@/lib/store/progress";
import { useSettings } from "@/lib/store/settings";
import { xpForResult, type EngineSnapshot, type TestResult } from "@/lib/typing/engine";
import { generateWords } from "@/lib/typing/words";
import { cn } from "@/lib/utils";

const DURATIONS = [15, 30, 60, 120] as const;

const searchSchema = z.object({
  weak: z.enum(["1"]).optional(),
});

export const Route = createFileRoute("/")({
  validateSearch: searchSchema,
  component: Home,
});

function Home() {
  const { weak } = Route.useSearch();
  const navigate = useNavigate();
  const punctuation = useSettings((s) => s.punctuation);
  const numbers = useSettings((s) => s.numbers);
  const setPunctuation = useSettings((s) => s.setPunctuation);
  const setNumbers = useSettings((s) => s.setNumbers);
  const showKeyboard = useSettings((s) => s.showKeyboard);
  const showHands = useSettings((s) => s.showHands);
  const weakWords = useProgress((s) => s.weakWords);
  const applyResult = useProgress((s) => s.applyResult);
  const user = useCurrentUser();

  const [duration, setDuration] = useState(30);
  const [customOpen, setCustomOpen] = useState(false);
  const [customVal, setCustomVal] = useState("90");
  const [seed, setSeed] = useState(1);
  const [result, setResult] = useState<TestResult | null>(null);
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [posted, setPosted] = useState(false);
  const [posting, setPosting] = useState(false);

  const text = useMemo(() => {
    if (weak === "1" && weakWords.length) {
      const pool = weakWords.length ? weakWords : ["the", "and", "that"];
      const words: string[] = [];
      for (let i = 0; i < 80; i += 1) words.push(pool[i % pool.length]!);
      return words.join(" ");
    }
    return generateWords(Math.max(80, duration * 4), { punctuation, numbers, seed });
  }, [duration, punctuation, numbers, seed, weak, weakWords]);

  const nextChar = snap?.text[snap.caret] ?? text[0] ?? null;
  const running = snap?.status === "running";

  const restart = () => {
    setResult(null);
    setPosted(false);
    setSeed((s) => s + 1);
  };

  return (
    <div className={cn("transition-opacity duration-300", running && "[&_.chrome]:opacity-0")}>
      <div className="chrome mb-8 flex flex-col items-center gap-4 transition-opacity duration-300">
        <div className="flex flex-wrap items-center justify-center gap-1 rounded-lg bg-surface-2 p-1">
          {DURATIONS.map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => {
                setDuration(d);
                restart();
              }}
              className={cn(
                "h-9 min-w-12 rounded-md px-3 text-sm font-medium tabular-nums",
                duration === d ? "bg-surface text-fg shadow-soft" : "text-muted hover:text-fg",
              )}
            >
              {d}s
            </button>
          ))}
          <button
            type="button"
            onClick={() => setCustomOpen(true)}
            className={cn(
              "h-9 rounded-md px-3 text-sm font-medium",
              !DURATIONS.includes(duration as (typeof DURATIONS)[number])
                ? "bg-surface text-fg shadow-soft"
                : "text-muted hover:text-fg",
            )}
          >
            Custom
          </button>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <ToggleChip on={punctuation} onClick={() => setPunctuation(!punctuation)} label="Punctuation" />
          <ToggleChip on={numbers} onClick={() => setNumbers(!numbers)} label="Numbers" />
          {weakWords.length > 0 && (
            <ToggleChip
              on={weak === "1"}
              onClick={() =>
                navigate({ to: "/", search: weak === "1" ? {} : { weak: "1" } })
              }
              label="Weak words"
            />
          )}
        </div>
      </div>

      {result ? (
        <ResultsPanel
          result={result}
          onRestart={restart}
          posted={posted}
          posting={posting}
          showWeakLink
          onPost={async () => {
            if (!user) return;
            setPosting(true);
            try {
              await saveScore({
                data: {
                  mode: "timed",
                  category: `${duration}s`,
                  wpm: result.wpm,
                  rawWpm: result.rawWpm,
                  accuracy: result.accuracy,
                  durationMs: result.durationMs,
                  displayName: user.displayName ?? user.primaryEmail ?? "Typist",
                },
              });
              setPosted(true);
            } catch {
              setPosted(false);
            } finally {
              setPosting(false);
            }
          }}
        />
      ) : (
        <>
          <div className={cn("mb-6 transition-opacity duration-300", !running && "opacity-60")}>
            {snap && <StatsBar snap={snap} />}
          </div>
          <TypingArena
            key={`${seed}-${duration}-${punctuation}-${numbers}-${weak ?? ""}`}
            text={text}
            durationMs={duration * 1000}
            onSnapshot={setSnap}
            onFinish={(res) => {
              setResult(res);
              const xp = xpForResult(res, "test");
              applyResult({ result: res, mode: "timed", category: `${duration}s`, xp });
              void pushProgress();
            }}
          />
          <div className="chrome mt-10 space-y-6 transition-opacity duration-300">
            {showHands && <Hands nextChar={nextChar} />}
            {showKeyboard && <KeyboardGuide nextChar={nextChar} />}
          </div>
        </>
      )}

      <Dialog open={customOpen} onOpenChange={setCustomOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Custom duration</DialogTitle>
            <DialogDescription>Seconds. Short tests stay snappy; long tests feel like an exam.</DialogDescription>
          </DialogHeader>
          <Input
            type="number"
            min={10}
            max={600}
            value={customVal}
            onChange={(e) => setCustomVal(e.target.value)}
          />
          <Button
            className="mt-3 w-full"
            onClick={() => {
              const n = Math.min(600, Math.max(10, Number(customVal) || 30));
              setDuration(n);
              setCustomOpen(false);
              restart();
            }}
          >
            Start
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ToggleChip({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 py-1.5 text-xs font-medium",
        on ? "border-primary bg-primary/10 text-primary" : "border-border text-muted hover:text-fg",
      )}
    >
      {label}
    </button>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageTitle } from "@/components/layout/AppShell";
import { ResultsPanel } from "@/components/typing/ResultsPanel";
import { StatsBar, TypingArena } from "@/components/typing/TypingArena";
import { pushProgress } from "@/components/layout/CloudSync";
import { useProgress } from "@/lib/store/progress";
import { xpForResult, type EngineSnapshot, type TestResult } from "@/lib/typing/engine";
import { CODE_LANGS, pickSnippet, type CodeLang } from "@/lib/typing/code-snippets";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/code")({ component: CodePage });

function CodePage() {
  const [lang, setLang] = useState<CodeLang>("javascript");
  const [seed, setSeed] = useState(0);
  const [result, setResult] = useState<TestResult | null>(null);
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const applyResult = useProgress((s) => s.applyResult);
  const snippet = useMemo(() => pickSnippet(lang), [lang, seed]);

  return (
    <div>
      <PageTitle
        kicker="For developers"
        title="Code typing"
        desc="Build muscle memory for braces, arrows, and semicolons. Indentation counts."
      />
      <div className="mb-6 flex flex-wrap gap-2">
        {CODE_LANGS.map((l) => (
          <button
            key={l.id}
            type="button"
            onClick={() => {
              setLang(l.id);
              setResult(null);
              setSeed((n) => n + 1);
            }}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-medium",
              lang === l.id
                ? "border-primary bg-primary/10 text-primary"
                : "border-border text-muted hover:text-fg",
            )}
          >
            {l.label}
          </button>
        ))}
      </div>
      {result ? (
        <ResultsPanel
          result={result}
          onRestart={() => {
            setResult(null);
            setSeed((n) => n + 1);
          }}
        />
      ) : (
        <>
          {snap && (
            <div className="mb-4">
              <StatsBar snap={snap} />
            </div>
          )}
          <TypingArena
            key={`${lang}-${seed}`}
            text={snippet}
            onSnapshot={setSnap}
            onFinish={(res) => {
              setResult(res);
              applyResult({
                result: res,
                mode: "code",
                category: lang,
                xp: xpForResult(res, "code"),
              });
              void pushProgress();
            }}
          />
        </>
      )}
    </div>
  );
}

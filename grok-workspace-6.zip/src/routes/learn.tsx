import { Outlet, createFileRoute, Link, useChildMatches } from "@tanstack/react-router";
import { ArrowRight, Check, Lock } from "lucide-react";
import { FingerLegend } from "@/components/typing/Hands";
import { PageTitle } from "@/components/layout/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useProgress } from "@/lib/store/progress";
import {
  LESSONS,
  MODULES,
  UNLOCK_ACCURACY,
  isLessonUnlocked,
  keyLabel,
  nextOpenLesson,
} from "@/lib/typing/lessons";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/learn")({ component: Learn });

function Learn() {
  const childMatches = useChildMatches();
  if (childMatches.length > 0) return <Outlet />;

  return <Academy />;
}

function Academy() {
  const completed = useProgress((s) => s.completedLessons);
  const lessonBest = useProgress((s) => s.lessonBest);
  const lessonStages = useProgress((s) => s.lessonStages);
  const done = completed.length;
  const total = LESSONS.length;
  const next = nextOpenLesson(completed);
  const allDone = done >= total;

  return (
    <div>
      <PageTitle
        kicker="Academy"
        title="Learn to type"
        desc={`Home row first. Each stage unlocks at ${UNLOCK_ACCURACY}% accuracy.`}
      />

      {next && (
        <Card className="mb-8 flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-widest text-subtle uppercase">Continue</p>
            <p className="text-lg font-semibold tracking-tight">{next.title}</p>
            <p className="text-sm text-muted">
              Module {next.module} · {next.moduleTitle}
            </p>
            <p className="mt-2 font-mono text-xs text-subtle">
              {next.keys.slice(0, 8).map(keyLabel).join("  ")}
            </p>
          </div>
          <Button asChild className="shrink-0">
            <Link to="/learn/$lessonId" params={{ lessonId: next.id }}>
              {completed.length === 0 ? "Start first lesson" : "Continue"}
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </Card>
      )}
      {allDone && (
        <Card className="mb-8 p-5">
          <p className="text-lg font-semibold tracking-tight">Academy complete</p>
          <p className="text-sm text-muted">
            Every lesson passed at {UNLOCK_ACCURACY}%. Keep the feel in Practice, Exam, or a Race.
          </p>
        </Card>
      )}

      <div className="mb-6 flex items-center gap-3">
        <Progress value={(done / total) * 100} className="max-w-xs" />
        <span className="text-sm tabular-nums text-muted">
          {done}/{total}
        </span>
      </div>
      <FingerLegend className="mb-10 justify-start" />

      <div className="space-y-10">
        {MODULES.map((mod) => {
          const items = LESSONS.filter((l) => l.module === mod.id);
          const modDone = items.filter((l) => completed.includes(l.id)).length;
          return (
            <section key={mod.id}>
              <div className="mb-4 flex items-end justify-between gap-3">
                <div>
                  <p className="text-xs font-medium tracking-widest text-subtle uppercase">
                    Module {mod.id}
                  </p>
                  <h2 className="text-xl font-semibold tracking-tight">{mod.title}</h2>
                  <p className="text-sm text-muted">{mod.blurb}</p>
                </div>
                <Badge variant={modDone === items.length ? "success" : "secondary"}>
                  {modDone}/{items.length}
                </Badge>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {items.map((lesson) => {
                  const open = isLessonUnlocked(lesson.id, completed);
                  const best = lessonBest[lesson.id];
                  const passed = completed.includes(lesson.id);
                  const stages = lessonStages[lesson.id] ?? [];
                  return (
                    <Card
                      key={lesson.id}
                      className={cn(
                        "p-0",
                        !open && "opacity-70",
                        open && "transition-colors hover:border-border-strong",
                      )}
                    >
                      {open ? (
                        <Link to="/learn/$lessonId" params={{ lessonId: lesson.id }} className="block p-5">
                          <LessonInner
                            lesson={lesson}
                            best={best}
                            passed={passed}
                            locked={false}
                            stages={stages}
                          />
                        </Link>
                      ) : (
                        <div className="p-5">
                          <LessonInner lesson={lesson} best={best} passed={false} locked stages={[]} />
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function LessonInner({
  lesson,
  best,
  passed,
  locked,
  stages,
}: {
  lesson: (typeof LESSONS)[number];
  best?: { accuracy: number; wpm: number };
  passed: boolean;
  locked: boolean;
  stages: string[];
}) {
  return (
    <div className="flex items-start gap-3">
      <span
        className={cn(
          "mt-0.5 grid size-8 shrink-0 place-items-center rounded-full",
          passed ? "bg-correct/15 text-correct" : locked ? "bg-surface-2 text-subtle" : "bg-primary/10 text-primary",
        )}
      >
        {passed ? (
          <Check className="size-4" />
        ) : locked ? (
          <Lock className="size-3.5" />
        ) : (
          <span className="font-mono text-xs">{keyLabel(lesson.keys[0] ?? "").slice(0, 2)}</span>
        )}
      </span>
      <div className="min-w-0 flex-1">
        <CardTitle>{lesson.title}</CardTitle>
        <CardDescription className="mt-1 line-clamp-2">{lesson.intro}</CardDescription>
        <p className="mt-2 font-mono text-xs text-subtle">
          {lesson.keys.slice(0, 8).map(keyLabel).join("  ")}
          {best ? `  ·  ${Math.round(best.accuracy)}%  ·  ${best.wpm} wpm` : ""}
        </p>
        {!locked && (
          <p className="mt-2 flex gap-1 text-xs tracking-wide text-subtle uppercase">
            {(["keys", "words", "sentences"] as const).map((s) => (
              <span
                key={s}
                className={cn(
                  "rounded-sm px-1.5 py-0.5",
                  stages.includes(s) || passed ? "bg-correct/15 text-correct" : "bg-surface-2",
                )}
              >
                {s}
              </span>
            ))}
          </p>
        )}
      </div>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { PageTitle } from "@/components/layout/AppShell";
import { ResultsPanel } from "@/components/typing/ResultsPanel";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { pushProgress } from "@/components/layout/CloudSync";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { saveScore } from "@/lib/server/scores";
import { useProgress } from "@/lib/store/progress";
import {
  TypingEngine,
  xpForResult,
  type BackspaceMode,
  type TestResult,
} from "@/lib/typing/engine";
import { HINDI_LAYOUT_META, mapHindiKey, type HindiLayout } from "@/lib/typing/hindi";
import { ENGLISH_PASSAGES, EXAM_PRESETS, HINDI_PASSAGES, pickPassage } from "@/lib/typing/passages";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/exam")({ component: ExamPage });

function ExamPage() {
  const [presetId, setPresetId] = useState(EXAM_PRESETS[0]!.id);
  const preset = EXAM_PRESETS.find((p) => p.id === presetId)!;
  const [layout, setLayout] = useState<HindiLayout>("inscript");
  const [backspace, setBackspace] = useState<BackspaceMode>(preset.backspace);
  const [seed, setSeed] = useState(0);
  const passage = useMemo(
    () => pickPassage(preset.lang === "hi" ? HINDI_PASSAGES : ENGLISH_PASSAGES, seed),
    [preset.lang, seed],
  );

  useEffect(() => {
    setBackspace(preset.backspace);
  }, [preset.backspace]);

  return (
    <div>
      <PageTitle
        kicker="Skill test"
        title="Exam simulation"
        desc="Reference on top, your paper below — the layout used in SSC, High Court, Railway, and Police tests."
      />
      <div className="mb-6 flex flex-wrap gap-2">
        {EXAM_PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => {
              setPresetId(p.id);
              setSeed((n) => n + 1);
            }}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-medium",
              p.id === presetId
                ? "border-primary bg-primary/10 text-primary"
                : "border-border text-muted hover:text-fg",
            )}
          >
            {p.label}
          </button>
        ))}
      </div>
      <p className="mb-4 text-sm text-muted">{preset.blurb}</p>
      {preset.lang === "hi" && (
        <div className="mb-4 flex flex-wrap gap-2">
          {HINDI_LAYOUT_META.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLayout(l.id)}
              className={cn(
                "rounded-md border px-3 py-1.5 text-xs",
                layout === l.id
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border text-muted",
              )}
              title={l.hint}
            >
              {l.label}
            </button>
          ))}
        </div>
      )}
      <div className="mb-4 flex flex-wrap gap-2 text-xs">
        {(["full", "word", "none"] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setBackspace(m)}
            className={cn(
              "rounded-md border px-3 py-1.5 font-medium",
              backspace === m ? "border-primary text-primary" : "border-border text-muted",
            )}
          >
            Backspace: {m}
          </button>
        ))}
      </div>
      <ExamArena
        key={`${presetId}-${seed}-${backspace}-${layout}`}
        passage={passage}
        durationMs={preset.durationSec * 1000}
        backspace={backspace}
        hindi={preset.lang === "hi" ? layout : null}
        category={preset.id}
        onRetest={() => setSeed((n) => n + 1)}
      />
    </div>
  );
}

function ExamArena({
  passage,
  durationMs,
  backspace,
  hindi,
  category,
  onRetest,
}: {
  passage: string;
  durationMs: number;
  backspace: BackspaceMode;
  hindi: HindiLayout | null;
  category: string;
  onRetest: () => void;
}) {
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const engineRef = useRef(new TypingEngine({ text: passage, durationMs, backspace }));
  const [typed, setTyped] = useState("");
  const [left, setLeft] = useState(durationMs);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);
  const [posted, setPosted] = useState(false);
  const [posting, setPosting] = useState(false);
  const applyResult = useProgress((s) => s.applyResult);
  const user = useCurrentUser();

  useEffect(() => {
    const id = window.setInterval(() => {
      const e = engineRef.current;
      if (e.status !== "running") return;
      e.tick();
      const shot = e.snapshot();
      setLeft(shot.remainingMs ?? 0);
      if (shot.status === "finished" && !result) {
        finish();
      }
    }, 100);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [result]);

  const finish = () => {
    const e = engineRef.current;
    e.finish();
    const res = e.result();
    setResult(res);
    const xp = xpForResult(res, "exam");
    applyResult({ result: res, mode: "exam", category, xp });
    void pushProgress();
  };

  const onKeyDown = (ev: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (result) return;
    if (ev.key === "Tab") {
      ev.preventDefault();
      return;
    }
    if (hindi && ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey) {
      const mapped = mapHindiKey(hindi, ev.key);
      if (mapped) {
        ev.preventDefault();
        engineRef.current.startIfNeeded();
        setRunning(true);
        const fake = { key: mapped, getModifierState: () => false };
        engineRef.current.handleKey(fake);
        setTyped((t) => {
          if (backspace === "none" && false) return t;
          return t + mapped;
        });
        return;
      }
    }
    if (ev.key === "Backspace") {
      if (backspace === "none") {
        ev.preventDefault();
        return;
      }
      if (backspace === "word") {
        ev.preventDefault();
        engineRef.current.handleKey(ev.nativeEvent);
        setTyped((t) => t.replace(/\s*\S+$/, ""));
        return;
      }
    }
    if (ev.key.length === 1 && !ev.ctrlKey && !ev.metaKey) {
      engineRef.current.startIfNeeded();
      setRunning(true);
      engineRef.current.handleKey(ev.nativeEvent);
    } else if (ev.key === "Backspace" && backspace === "full") {
      engineRef.current.handleKey(ev.nativeEvent);
    }
  };

  const onChange = (ev: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (hindi) return;
    if (result) return;
    const v = ev.target.value;
    setTyped(v);
    engineRef.current.startIfNeeded();
    setRunning(true);
  };

  const snap = engineRef.current.snapshot();
  const secs = Math.ceil(left / 1000);

  if (result) {
    return (
      <ResultsPanel
        result={result}
        onRestart={onRetest}
        posted={posted}
        posting={posting}
        onPost={async () => {
          if (!user) return;
          setPosting(true);
          try {
            await saveScore({
              data: {
                mode: "exam",
                category,
                wpm: result.wpm,
                rawWpm: result.rawWpm,
                accuracy: result.accuracy,
                durationMs: result.durationMs,
                displayName: user.displayName ?? user.primaryEmail ?? "Typist",
              },
            });
            setPosted(true);
          } catch {
            /* ignore */
          } finally {
            setPosting(false);
          }
        }}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 font-mono text-sm tabular-nums">
        <span className="text-primary">{running ? snap.wpm : 0} wpm</span>
        <span>{running ? Math.round(snap.accuracy) : 100}%</span>
        <span className="text-muted">{secs}s left</span>
        <Button size="sm" variant="outline" onClick={finish}>
          Submit
        </Button>
      </div>
      <Card className="p-4">
        <p className="mb-2 text-[11px] font-medium tracking-widest text-subtle uppercase">
          Passage
        </p>
        <p
          className={cn(
            "max-h-40 overflow-auto text-[15px] leading-relaxed text-fg",
            hindi && "font-[family-name:var(--font-devanagari)]",
          )}
        >
          {passage}
        </p>
      </Card>
      <Card className="p-0">
        <textarea
          ref={areaRef}
          value={typed}
          onChange={onChange}
          onKeyDown={onKeyDown}
          placeholder="Type the passage here…"
          className={cn(
            "min-h-48 w-full resize-y rounded-xl bg-transparent p-4 font-mono text-[15px] leading-relaxed text-fg outline-none placeholder:text-subtle",
            hindi && "font-[family-name:var(--font-devanagari)]",
          )}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
        />
      </Card>
    </div>
  );
}

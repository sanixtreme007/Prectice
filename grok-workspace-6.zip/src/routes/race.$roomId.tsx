import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Copy, Flag } from "lucide-react";
import { StatsBar, TypingArena } from "@/components/typing/TypingArena";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { generateWords } from "@/lib/typing/words";
import type { EngineSnapshot, TestResult } from "@/lib/typing/engine";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/race/$roomId")({ component: RaceRoomPage });

type Phase = "lobby" | "countdown" | "running" | "done";

type RacerState = { caret: number; total: number; wpm: number; done: boolean; name: string };

type Wire =
  | { t: "hello"; name: string }
  | { t: "start"; at: number; text: string }
  | { t: "progress"; caret: number; total: number; wpm: number; done: boolean };

function RaceRoomPage() {
  const { roomId } = Route.useParams();
  const [name] = useState(() => {
    if (typeof sessionStorage === "undefined") return "Typist";
    return sessionStorage.getItem("ta-racer") || "Typist";
  });
  return <RaceRoom key={roomId} roomId={roomId} name={name} />;
}

function RaceRoom({ roomId, name }: { roomId: string; name: string }) {
  const p2p = useP2PRoom({ room: `race-${roomId}`.slice(0, 64), name });
  const [phase, setPhase] = useState<Phase>("lobby");
  const [text, setText] = useState("");
  const [count, setCount] = useState(3);
  const [racers, setRacers] = useState<Record<string, RacerState>>({});
  const [snap, setSnap] = useState<EngineSnapshot | null>(null);
  const [copied, setCopied] = useState(false);
  const hostRef = useRef(false);
  const startAtRef = useRef(0);

  const isHost = useMemo(() => {
    const ids = [p2p.selfId, ...p2p.peers.map((p) => p.id)].sort();
    return ids[0] === p2p.selfId;
  }, [p2p.selfId, p2p.peers]);

  useEffect(() => {
    hostRef.current = isHost;
  }, [isHost]);

  useEffect(() => {
    setRacers((r) => ({
      ...r,
      [p2p.selfId]: r[p2p.selfId] ?? { caret: 0, total: 1, wpm: 0, done: false, name },
    }));
  }, [p2p.selfId, name]);

  useEffect(() => {
    return p2p.onMessage((from, data) => {
      const msg = data as Wire;
      if (!msg || typeof msg !== "object" || !("t" in msg)) return;
      if (msg.t === "hello") {
        setRacers((r) => ({
          ...r,
          [from]: r[from] ?? { caret: 0, total: 1, wpm: 0, done: false, name: msg.name },
        }));
        if (hostRef.current && text) {
          p2p.send({ t: "start", at: startAtRef.current, text } satisfies Wire, from);
        }
      }
      if (msg.t === "start") {
        startAtRef.current = msg.at;
        setText(msg.text);
        const delay = Math.max(0, msg.at - Date.now());
        setPhase("countdown");
        setCount(Math.ceil(delay / 1000) || 3);
      }
      if (msg.t === "progress") {
        setRacers((r) => ({
          ...r,
          [from]: {
            caret: msg.caret,
            total: msg.total,
            wpm: msg.wpm,
            done: msg.done,
            name: r[from]?.name ?? "Racer",
          },
        }));
      }
    });
  }, [p2p, text]);

  useEffect(() => {
    if (!p2p.joined) return;
    p2p.send({ t: "hello", name } satisfies Wire);
  }, [p2p, p2p.joined, name]);

  useEffect(() => {
    if (phase !== "countdown") return;
    const id = window.setInterval(() => {
      const left = startAtRef.current - Date.now();
      if (left <= 0) {
        setPhase("running");
        setCount(0);
      } else setCount(Math.ceil(left / 1000));
    }, 100);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase !== "running" || !snap) return;
    const payload: Wire = {
      t: "progress",
      caret: snap.caret,
      total: snap.text.length,
      wpm: snap.wpm,
      done: snap.status === "finished",
    };
    p2p.broadcast(payload);
    setRacers((r) => ({
      ...r,
      [p2p.selfId]: {
        caret: snap.caret,
        total: snap.text.length,
        wpm: snap.wpm,
        done: snap.status === "finished",
        name,
      },
    }));
  }, [snap, phase, p2p, name]);

  const startRace = () => {
    const t = generateWords(90, { seed: Date.now() % 100000 });
    const at = Date.now() + 3000;
    startAtRef.current = at;
    setText(t);
    p2p.send({ t: "start", at, text: t } satisfies Wire);
    setPhase("countdown");
    setCount(3);
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  const everyone = [
    {
      id: p2p.selfId,
      name,
      caret: racers[p2p.selfId]?.caret ?? 0,
      total: racers[p2p.selfId]?.total ?? 1,
      wpm: racers[p2p.selfId]?.wpm ?? 0,
      done: racers[p2p.selfId]?.done ?? false,
    },
    ...p2p.peers.map((p) => ({
      id: p.id,
      name: p.name || racers[p.id]?.name || "Racer",
      caret: racers[p.id]?.caret ?? 0,
      total: racers[p.id]?.total ?? 1,
      wpm: racers[p.id]?.wpm ?? 0,
      done: racers[p.id]?.done ?? false,
      connectionState: p.connectionState,
    })),
  ];

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-widest text-subtle uppercase">Room {roomId}</p>
          <h1 className="text-2xl font-semibold tracking-tight">Live race</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => void copyLink()}>
            <Copy className="size-3.5" />
            {copied ? "Copied" : "Invite link"}
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/race">Leave</Link>
          </Button>
        </div>
      </div>

      <div className="mb-6 space-y-2">
        {everyone.map((r) => {
          const pct = Math.min(100, Math.round((r.caret / Math.max(1, r.total)) * 100));
          return (
            <div key={r.id} className="grid grid-cols-[7rem_1fr_3.5rem] items-center gap-3">
              <span className="truncate text-sm font-medium">
                {r.name}
                {r.id === p2p.selfId ? " (you)" : ""}
              </span>
              <Progress value={pct} />
              <span className="text-right font-mono text-xs tabular-nums text-muted">
                {r.done ? "done" : `${r.wpm} wpm`}
              </span>
            </div>
          );
        })}
        {p2p.peers.some((p) => p.connectionState === "failed") && (
          <p className="text-xs text-incorrect">A racer could not connect (strict network).</p>
        )}
      </div>

      {phase === "lobby" && (
        <div className="rounded-xl border border-border bg-surface p-6 text-center">
          <p className="text-sm text-muted">
            {p2p.joined ? "Waiting in the lobby." : "Connecting…"} Share the invite when you are ready.
          </p>
          {isHost ? (
            <Button className="mt-4" onClick={startRace} disabled={p2p.peers.length === 0 && false}>
              <Flag className="size-4" />
              Start race
            </Button>
          ) : (
            <p className="mt-3 text-sm text-subtle">The host starts the race.</p>
          )}
        </div>
      )}

      {phase === "countdown" && (
        <p className="py-12 text-center font-mono text-6xl font-medium text-primary tabular-nums">
          {count}
        </p>
      )}

      {phase === "running" && text && (
        <>
          {snap && (
            <div className="mb-4">
              <StatsBar snap={snap} />
            </div>
          )}
          <TypingArena
            text={text}
            onSnapshot={setSnap}
            onFinish={(_res: TestResult) => {
              setPhase("done");
            }}
          />
        </>
      )}

      {phase === "done" && (
        <p className={cn("py-8 text-center text-lg font-medium")}>Finished. Watch the bars for the rest of the field.</p>
      )}
    </div>
  );
}

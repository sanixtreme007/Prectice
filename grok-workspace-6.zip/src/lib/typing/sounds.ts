export type SwitchType = "off" | "red" | "brown" | "blue";

let ctx: AudioContext | null = null;
let lastAt = 0;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  ctx ??= new AudioContext();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function noise(acx: AudioContext, duration: number): AudioBufferSourceNode {
  const buffer = acx.createBuffer(1, Math.floor(acx.sampleRate * duration), acx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1;
  const src = acx.createBufferSource();
  src.buffer = buffer;
  return src;
}

export function playKeySound(kind: SwitchType, isError = false) {
  if (kind === "off") return;
  const acx = ac();
  if (!acx) return;
  const now = acx.currentTime;
  if (now - lastAt < 0.012) return;
  lastAt = now;

  const master = acx.createGain();
  master.gain.value = isError ? 0.08 : 0.12;
  master.connect(acx.destination);

  const thud = acx.createOscillator();
  const thudGain = acx.createGain();
  thud.type = "sine";
  thud.frequency.value = isError ? 140 : kind === "red" ? 110 : kind === "brown" ? 150 : 190;
  thudGain.gain.setValueAtTime(0.7, now);
  thudGain.gain.exponentialRampToValueAtTime(0.001, now + (kind === "red" ? 0.05 : 0.07));
  thud.connect(thudGain);
  thudGain.connect(master);
  thud.start(now);
  thud.stop(now + 0.08);

  if (kind === "brown" || kind === "blue") {
    const bump = acx.createOscillator();
    const bumpGain = acx.createGain();
    bump.type = "triangle";
    bump.frequency.value = kind === "blue" ? 920 : 420;
    bumpGain.gain.setValueAtTime(kind === "blue" ? 0.28 : 0.18, now);
    bumpGain.gain.exponentialRampToValueAtTime(0.001, now + (kind === "blue" ? 0.035 : 0.03));
    bump.connect(bumpGain);
    bumpGain.connect(master);
    bump.start(now);
    bump.stop(now + 0.04);
  }

  if (kind === "blue") {
    const click = noise(acx, 0.025);
    const clickGain = acx.createGain();
    const filter = acx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 1800;
    clickGain.gain.setValueAtTime(0.35, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
    click.connect(filter);
    filter.connect(clickGain);
    clickGain.connect(master);
    click.start(now);
  }
}

export function primeAudio() {
  ac();
}

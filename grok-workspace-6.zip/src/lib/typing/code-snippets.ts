export type CodeLang = "python" | "javascript" | "html" | "cpp";

export const CODE_LANGS: { id: CodeLang; label: string }[] = [
  { id: "python", label: "Python" },
  { id: "javascript", label: "JavaScript" },
  { id: "html", label: "HTML / CSS" },
  { id: "cpp", label: "C++" },
];

export const CODE_SNIPPETS: Record<CodeLang, string[]> = {
  python: [
    `def two_sum(nums: list[int], target: int) -> list[int]:
    seen: dict[int, int] = {}
    for i, n in enumerate(nums):
        need = target - n
        if need in seen:
            return [seen[need], i]
        seen[n] = i
    return []`,
    `from pathlib import Path

def read_lines(path: str) -> list[str]:
    text = Path(path).read_text(encoding="utf-8")
    return [line.rstrip() for line in text.splitlines() if line.strip()]`,
    `class Stack[T]:
    def __init__(self) -> None:
        self._items: list[T] = []

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        return self._items.pop()`,
  ],
  javascript: [
    `export function debounce(fn, wait = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}`,
    `const sum = (nums) => nums.reduce((a, b) => a + b, 0);

export async function loadUser(id) {
  const res = await fetch(\`/api/users/\${id}\`);
  if (!res.ok) throw new Error("not found");
  return res.json();
}`,
    `const btn = document.querySelector("#go");
btn?.addEventListener("click", () => {
  const value = Number(input.value) || 0;
  output.textContent = String(value * 2);
});`,
  ],
  html: [
    `<section class="hero">
  <h1>Type with both hands</h1>
  <p class="lede">Accuracy first. Speed follows.</p>
  <a class="btn" href="/learn">Start lesson</a>
</section>`,
    `.card {
  display: flex;
  gap: 12px;
  padding: 16px 20px;
  border: 1px solid var(--border);
  border-radius: 12px;
}
.card:hover { transform: translateY(-1px); }`,
    `<form action="/apply" method="post">
  <label for="name">Full name</label>
  <input id="name" name="name" required />
  <button type="submit">Submit</button>
</form>`,
  ],
  cpp: [
    `#include <vector>
using namespace std;

int maxSubarray(const vector<int>& a) {
  int best = a[0], cur = a[0];
  for (size_t i = 1; i < a.size(); i++) {
    cur = max(a[i], cur + a[i]);
    best = max(best, cur);
  }
  return best;
}`,
    `struct Node {
  int val;
  Node* next;
  Node(int v) : val(v), next(nullptr) {}
};

void reverse(Node*& head) {
  Node* prev = nullptr;
  while (head) {
    Node* nxt = head->next;
    head->next = prev;
    prev = head;
    head = nxt;
  }
  head = prev;
}`,
  ],
};

export function pickSnippet(lang: CodeLang): string {
  const pool = CODE_SNIPPETS[lang];
  return pool[Math.floor(Math.random() * pool.length)]!;
}

export const COMMON_WORDS = [
  "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on",
  "with", "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we",
  "say", "her", "she", "or", "an", "will", "my", "one", "all", "would", "there", "their",
  "what", "so", "up", "out", "if", "about", "who", "get", "which", "go", "me", "when",
  "make", "can", "like", "time", "no", "just", "him", "know", "take", "people", "into",
  "year", "your", "good", "some", "could", "them", "see", "other", "than", "then", "now",
  "look", "only", "come", "its", "over", "think", "also", "back", "after", "use", "two",
  "how", "our", "work", "first", "well", "way", "even", "new", "want", "because", "any",
  "these", "give", "day", "most", "us", "is", "are", "was", "were", "been", "being",
  "has", "had", "did", "doing", "may", "might", "must", "shall", "should", "own", "same",
  "such", "too", "very", "through", "during", "before", "between", "under", "again",
  "further", "once", "here", "where", "why", "how", "all", "both", "each", "few", "more",
  "other", "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than",
  "too", "very", "can", "will", "just", "should", "now", "life", "world", "still",
  "public", "human", "high", "every", "state", "small", "large", "great", "place",
  "right", "old", "long", "little", "great", "never", "those", "come", "made", "find",
  "part", "hand", "keep", "last", "ask", "need", "feel", "seem", "leave", "put", "mean",
  "let", "set", "end", "why", "try", "kind", "turn", "move", "play", "live", "hold",
  "next", "case", "point", "group", "fact", "week", "month", "home", "room", "area",
  "water", "school", "system", "number", "night", "thing", "child", "eye", "woman",
  "man", "city", "family", "story", "student", "country", "problem", "hand", "part",
  "place", "case", "week", "company", "system", "program", "question", "work",
  "government", "number", "night", "point", "home", "water", "room", "mother",
  "area", "money", "story", "fact", "month", "lot", "right", "study", "book", "eye",
  "job", "word", "business", "issue", "side", "kind", "head", "house", "service",
  "friend", "father", "power", "hour", "game", "line", "end", "member", "law", "car",
  "city", "community", "name", "president", "team", "minute", "idea", "kid", "body",
  "information", "back", "parent", "face", "others", "level", "office", "door",
  "health", "person", "art", "war", "history", "party", "result", "change", "morning",
  "reason", "research", "girl", "guy", "moment", "air", "teacher", "force",
  "education", "foot", "boy", "age", "policy", "process", "music", "including",
  "consider", "appear", "actually", "buy", "probably", "human", "wait", "serve",
  "market", "die", "send", "expect", "home", "sense", "build", "stay", "fall",
  "cut", "kill", "remain", "suggest", "raise", "pass", "sell", "require", "report",
  "decide", "pull", "return", "explain", "hope", "develop", "carry", "lead", "understand",
  "watch", "follow", "stop", "create", "speak", "read", "allow", "add", "spend",
  "grow", "open", "walk", "win", "offer", "remember", "love", "consider", "appear",
  "include", "continue", "set", "learn", "change", "lead", "understand", "watch",
  "follow", "stop", "create", "speak", "read", "allow", "add", "spend", "grow",
  "open", "walk", "win", "offer", "remember", "love", "consider", "appear",
  "computer", "keyboard", "practice", "accuracy", "speed", "focus", "rhythm",
  "language", "sentence", "letter", "finger", "muscle", "memory", "habit",
  "control", "simple", "clear", "quiet", "steady", "smooth", "light", "dark",
  "table", "chair", "window", "paper", "pencil", "screen", "phone", "clock",
  "today", "tomorrow", "yesterday", "always", "often", "sometimes", "never",
  "please", "thank", "sorry", "hello", "welcome", "friend", "family", "people",
  "india", "delhi", "mumbai", "railway", "station", "office", "court", "police",
  "exam", "test", "result", "mark", "score", "rank", "form", "admit", "card",
  "government", "public", "service", "commission", "notice", "circular", "order",
  "application", "candidate", "selection", "interview", "document", "signature",
];

const PUNCT = [".", ",", ";", ":", "?", "!"];

function pick<T>(arr: T[], rng: () => number): T {
  return arr[Math.floor(rng() * arr.length)]!;
}

export function generateWords(
  count: number,
  opts: { punctuation?: boolean; numbers?: boolean; seed?: number } = {},
): string {
  let rng = Math.random;
  if (typeof opts.seed === "number") {
    let s = opts.seed;
    rng = () => {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };
  }
  const out: string[] = [];
  for (let i = 0; i < count; i += 1) {
    let w = pick(COMMON_WORDS, rng);
    if (opts.numbers && rng() < 0.12) w = String(Math.floor(rng() * 1000));
    if (opts.punctuation && rng() < 0.18) {
      if (rng() < 0.3) w = `"${w}"`;
      else w = w + pick(PUNCT, rng);
    }
    if (opts.punctuation && rng() < 0.08) w = w[0]!.toUpperCase() + w.slice(1);
    out.push(w);
  }
  return out.join(" ");
}

export const ENGLISH_PASSAGES = [
  "The Union Public Service Commission conducts examinations for appointment to the services of the Union. A candidate must be a citizen of India or a subject of Nepal or Bhutan. The Commission may, at its discretion, fix qualifying marks in any or all the subjects of the examination.",
  "Good administration depends upon the integrity of public servants and the trust of the people they serve. Orders must be clear, records must be complete, and every citizen must be treated with fairness. Delay without cause is a denial of justice in its own right.",
  "A railway is a system of transport that moves people and goods on tracks. Punctuality, safety, and courtesy are the three duties of every railway employee. Passengers are requested to stand in queue, keep the station clean, and not travel without a proper ticket.",
  "The court directs that the petitioner shall file a reply within two weeks. No adjournment shall be granted except for reasons recorded in writing. The registry shall list the matter for hearing on the next available date after the pleadings are complete.",
  "Science is the careful study of the world through observation and experiment. A hypothesis is tested, not believed. When evidence changes, the conclusion must change with it. This habit of mind is as useful in public work as it is in a laboratory.",
  "India is a union of states. The Constitution is the supreme law of the land. Fundamental rights protect the citizen; directive principles guide the state. Every officer who takes an oath of office is bound to uphold this Constitution without fear or favour.",
  "Time management is the quiet skill behind every high score. Read the passage once, type at a steady pace, and do not chase speed at the cost of accuracy. A clean script with fewer mistakes always outranks a fast script full of errors.",
  "The police station is a public office. A first information report must be registered when a cognizable offence is made out. The informant shall be given a copy free of cost. Investigation shall be fair, prompt, and confined to the facts.",
];

export const HINDI_PASSAGES = [
  "भारत एक संप्रभु समाजवादी पंथनिरपेक्ष लोकतंत्रात्मक गणराज्य है। संविधान देश का सर्वोच्च कानून है। प्रत्येक नागरिक को समानता, स्वतंत्रता और न्याय का अधिकार है। लोकसेवक अपना कार्य ईमानदारी और निष्पक्षता से करें।",
  "रेलवे यात्रियों से निवेदन है कि वे कतार में रहें, स्टेशन को स्वच्छ रखें तथा बिना टिकट यात्रा न करें। समय की पाबंदी, सुरक्षा और शिष्टाचार रेल कर्मचारी के तीन मुख्य कर्तव्य हैं।",
  "उच्च न्यायालय यह आदेश देता है कि याचिकाकर्ता दो सप्ताह के भीतर उत्तर दाखिल करे। लिखित कारण के बिना स्थगन नहीं दिया जाएगा। पत्रावली पूर्ण होने के पश्चात मामला शीघ्र सुनवाई के लिए सूचीबद्ध किया जाए।",
  "शिक्षा का उद्देश्य केवल परीक्षा उत्तीर्ण करना नहीं है। ज्ञान, अनुशासन और चरित्र मिलकर एक अच्छा नागरिक बनाते हैं। नियमित अभ्यास से टाइपिंग में गति और शुद्धता दोनों बढ़ती हैं।",
];

export function pickPassage(pool: string[], seed?: number): string {
  if (!pool.length) return "";
  const i =
    typeof seed === "number"
      ? Math.abs(seed) % pool.length
      : Math.floor(Math.random() * pool.length);
  return pool[i]!;
}

export type ExamPreset = {
  id: string;
  label: string;
  durationSec: number;
  backspace: "full" | "word" | "none";
  lang: "en" | "hi";
  blurb: string;
};

export const EXAM_PRESETS: ExamPreset[] = [
  {
    id: "ssc-chsl",
    label: "SSC CHSL",
    durationSec: 600,
    backspace: "full",
    lang: "en",
    blurb: "10-minute English passage. Accuracy first, then speed.",
  },
  {
    id: "ssc-cgl",
    label: "SSC CGL",
    durationSec: 600,
    backspace: "full",
    lang: "en",
    blurb: "Skill-test style passage used in Combined Graduate Level.",
  },
  {
    id: "high-court",
    label: "High Court",
    durationSec: 600,
    backspace: "none",
    lang: "en",
    blurb: "Legal English. Backspace off, as in many court tests.",
  },
  {
    id: "railway",
    label: "Railway",
    durationSec: 600,
    backspace: "word",
    lang: "en",
    blurb: "Station-and-service English with word-level backspace.",
  },
  {
    id: "police",
    label: "Police",
    durationSec: 600,
    backspace: "full",
    lang: "en",
    blurb: "Police-office English. Full backspace allowed.",
  },
  {
    id: "ssc-hindi",
    label: "SSC Hindi",
    durationSec: 600,
    backspace: "full",
    lang: "hi",
    blurb: "Hindi passage. Pick Inscript, Remington, or Kruti Dev.",
  },
];

export type LessonStage = "intro" | "keys" | "words" | "sentences";
export type DrillStage = "keys" | "words" | "sentences";

export type Lesson = {
  id: string;
  module: 1 | 2 | 3 | 4 | 5;
  moduleTitle: string;
  title: string;
  keys: string[];
  intro: string;
  tip: string;
  keyDrills: string;
  wordDrills: string;
  sentences: string;
};

function repeatKeys(keys: string[], groups = 18, len = 4): string {
  const out: string[] = [];
  for (let i = 0; i < groups; i += 1) {
    let g = "";
    for (let j = 0; j < len; j += 1) g += keys[(i + j) % keys.length];
    if (i % 2 === 1) g = keys.map((_, idx) => keys[(idx + i) % keys.length]).slice(0, len).join("");
    out.push(g);
  }
  return out.join(" ");
}

function keyDrill(focus: string[], mix: string[] = []): string {
  const out: string[] = [];
  for (const k of focus) {
    out.push(k.repeat(4), k.repeat(4), k.repeat(4));
  }
  if (focus.length >= 2) {
    for (let i = 0; i < focus.length; i += 1) {
      const a = focus[i]!;
      const b = focus[(i + 1) % focus.length]!;
      out.push(`${a}${b}${a}${b}`, `${b}${a}${b}${a}`, `${a}${a}${b}${b}`);
    }
  }
  const pool = [...focus, ...mix];
  out.push(repeatKeys(pool, 14, 4));
  return out.join(" ");
}

function fromPool(words: string[], n: number): string {
  const out: string[] = [];
  for (let i = 0; i < n; i += 1) out.push(words[i % words.length]!);
  return out.join(" ");
}

const HOME = ["a", "s", "d", "f", "g", "h", "j", "k", "l", ";"];

export const MODULES: { id: 1 | 2 | 3 | 4 | 5; title: string; blurb: string }[] = [
  { id: 1, title: "Home Row Foundation", blurb: "Anchors, reach, and words built only from the home row." },
  { id: 2, title: "Top Row Mastery", blurb: "Upward reaches and the return to home position." },
  { id: 3, title: "Bottom Row Mastery", blurb: "Downward reaches without looking at the keys." },
  { id: 4, title: "Shift & Capitals", blurb: "Opposite-hand Shift for every capital letter." },
  { id: 5, title: "Numbers, Symbols & Punctuation", blurb: "The row above and the marks that show up in exams." },
];

export const LESSONS: Lesson[] = [
  {
    id: "m1-fj",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "F and J anchors",
    keys: ["f", "j"],
    intro: "Place your left index on F and your right index on J. Feel the raised bumps. Those two keys are home — every other finger finds its place from here.",
    tip: "Rest, don't press. Light touch, then return to the bump.",
    keyDrills: keyDrill(["f", "j"]),
    wordDrills: fromPool(["fj", "jf", "ff", "jj", "fjf", "jfj"], 24),
    sentences: "fff jjj fjf jfj fff jjj jff fjj f j f j ff jj f j f j",
  },
  {
    id: "m1-dk",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "D and K",
    keys: ["d", "k"],
    intro: "Left middle finger on D, right middle on K. Keep F and J planted. Reach, press, return.",
    tip: "Only the middle fingers move. Index fingers stay on F and J.",
    keyDrills: keyDrill(["d", "k"], ["f", "j"]),
    wordDrills: fromPool(["dad", "fad", "kaka", "jak", "add", "fad", "jak"], 28),
    sentences: "dad fad jak add a dad a fad a jak dad fad jak add",
  },
  {
    id: "m1-sl",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "S and L",
    keys: ["s", "l"],
    intro: "Left ring on S, right ring on L. Keep the rest of the home row still while these two move.",
    tip: "Ring fingers are lazy. Make a short, definite tap and come home.",
    keyDrills: keyDrill(["s", "l"], ["d", "k", "f", "j"]),
    wordDrills: fromPool(["sad", "lad", "fall", "all", "ask", "lass", "flask"], 28),
    sentences: "a sad lad asks all lads fall as a flask falls",
  },
  {
    id: "m1-a-semi",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "A and semicolon",
    keys: ["a", ";"],
    intro: "Left pinky on A, right pinky on the semicolon. Pinkies are weaker — press lightly and return home.",
    tip: "Do not roll the wrist. The pinky curls down; the hand stays still.",
    keyDrills: keyDrill(["a", ";"], ["s", "l", "d", "k"]),
    wordDrills: fromPool(["as", "all", "ask", "salad", "alaska", "falls", "lass"], 28),
    sentences: "a lad asks; a lass falls; as all lads ask a dad;",
  },
  {
    id: "m1-gh",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "G and H",
    keys: ["g", "h"],
    intro: "Index fingers reach inward for G and H, then snap back to F and J. Do not let the other fingers lift.",
    tip: "G is a left-index reach. H is a right-index reach. Always return to the bump.",
    keyDrills: keyDrill(["g", "h"], ["f", "j"]),
    wordDrills: fromPool(["had", "flag", "glad", "half", "gall", "flash", "shall", "glass"], 28),
    sentences: "a glad lad had a flag; a half glass shall fall",
  },
  {
    id: "m1-space",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "Space bar",
    keys: [" "],
    intro: "Thumbs rest on the space bar. Use the thumb of the hand that just typed, or pick one thumb and stay with it.",
    tip: "A light tap. Do not hunt for space with your eyes.",
    keyDrills: "f j f j ff jj a a as as all all a lad a dad",
    wordDrills: fromPool(["a dad", "a lad", "as all", "a flag", "a glass", "a hall"], 20),
    sentences: "a dad had a flag as a lad had a glass",
  },
  {
    id: "m1-words",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "Home row words",
    keys: HOME,
    intro: "Only home-row letters. Aim for accuracy over speed. If a key feels lost, pause and find the bump on F or J.",
    tip: "Accuracy first. Slow is smooth; smooth is fast.",
    keyDrills: keyDrill(HOME),
    wordDrills: fromPool(
      ["as", "add", "all", "ask", "dad", "sad", "lad", "fall", "hall", "glad", "flag", "flask", "glass", "shall", "salad", "flash", "alaska", "gala", "dash", "lass"],
      36,
    ),
    sentences: "a glad dad had a salad; a lad asks a lass; flags fall as glass flasks flash",
  },
  {
    id: "m1-sentences",
    module: 1,
    moduleTitle: "Home Row Foundation",
    title: "Home row review",
    keys: HOME,
    intro: "Full home-row sentences. Unlock the next module at 95% accuracy. Keep your eyes on the text.",
    tip: "If you peek at the keyboard, start the sentence over.",
    keyDrills: keyDrill(HOME),
    wordDrills: fromPool(["shall", "flash", "flask", "salad", "alaska", "glass", "flags", "halls", "falls", "asks"], 30),
    sentences: "a sad lad had a glass flask; dad asks a lass; flags shall fall as a glad hall has a gala",
  },
  {
    id: "m2-ru",
    module: 2,
    moduleTitle: "Top Row Mastery",
    title: "R and U",
    keys: ["r", "u"],
    intro: "Left index reaches up to R; right index to U. Return to F and J after every press.",
    tip: "Reach up, tap, snap home. Do not leave the index parked on R or U.",
    keyDrills: keyDrill(["r", "u"], ["f", "j"]),
    wordDrills: fromPool(["far", "jar", "fur", "rug", "full", "dark", "lark", "rush"], 28),
    sentences: "a far jar; a full rug; rush a dark lark as far as a jar",
  },
  {
    id: "m2-ei",
    module: 2,
    moduleTitle: "Top Row Mastery",
    title: "E and I",
    keys: ["e", "i"],
    intro: "Middle fingers reach up to E and I. Keep wrists still; the motion is in the fingers.",
    tip: "From D up to E. From K up to I. Same finger, one key higher.",
    keyDrills: keyDrill(["e", "i"], ["d", "k"]),
    wordDrills: fromPool(["see", "did", "like", "field", "idea", "real", "said", "life", "feel", "idle"], 30),
    sentences: "i like a real field; she said a life feels idle; i see a deer",
  },
  {
    id: "m2-wo",
    module: 2,
    moduleTitle: "Top Row Mastery",
    title: "W and O",
    keys: ["w", "o"],
    intro: "Ring fingers to W and O. These reaches feel long at first — keep the pinkies resting on A and semicolon.",
    tip: "From S up to W. From L up to O. Pinkies stay home.",
    keyDrills: keyDrill(["w", "o"], ["s", "l"]),
    wordDrills: fromPool(["word", "work", "look", "wood", "slow", "low", "wow", "owl", "world", "follow"], 30),
    sentences: "we look for wood; a slow owl; follow a word as we work",
  },
  {
    id: "m2-qpty",
    module: 2,
    moduleTitle: "Top Row Mastery",
    title: "Q P T Y",
    keys: ["q", "p", "t", "y"],
    intro: "Pinkies take Q and P. Index fingers take T and Y. Four new reaches, same home-row return.",
    tip: "T is left index (beside R). Y is right index (beside U). Q and P are pinky reaches.",
    keyDrills: keyDrill(["q", "p", "t", "y"], ["f", "j"]),
    wordDrills: fromPool(["type", "quit", "pretty", "your", "they", "quiet", "power", "query", "party", "quality"], 30),
    sentences: "they type quietly; your query is pretty; quit a party; quality power",
  },
  {
    id: "m2-review",
    module: 2,
    moduleTitle: "Top Row Mastery",
    title: "Top row review",
    keys: ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
    intro: "Home + top row sentences. Keep eyes on the text, not the keys.",
    tip: "Every top-row key is a visit. Home is where you live.",
    keyDrills: keyDrill(["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"], HOME),
    wordDrills: fromPool(["their", "there", "where", "people", "world", "should", "would", "other", "after", "great"], 32),
    sentences: "people should type their letters well; we work after you; the world is quiet yet great",
  },
  {
    id: "m3-vm",
    module: 3,
    moduleTitle: "Bottom Row Mastery",
    title: "V and M",
    keys: ["v", "m"],
    intro: "Index fingers drop to V and M, then return home. Do not hook the wrists.",
    tip: "From F down to V. From J down to M. Fingers fold; wrists stay quiet.",
    keyDrills: keyDrill(["v", "m"], ["f", "j"]),
    wordDrills: fromPool(["vim", "jam", "move", "farm", "have", "them", "film", "vast"], 28),
    sentences: "move a farm film; have them jam; a vast vim",
  },
  {
    id: "m3-cn",
    module: 3,
    moduleTitle: "Bottom Row Mastery",
    title: "C and N",
    keys: ["c", "n"],
    intro: "Middle finger drops to C; index drops to N. Light presses, quick return.",
    tip: "C lives under D. N lives under J, one key in.",
    keyDrills: keyDrill(["c", "n"], ["v", "m", "d", "k"]),
    wordDrills: fromPool(["can", "nice", "cave", "name", "once", "voice", "dance", "chance"], 28),
    sentences: "once a nice cave; we can dance; a voice names a chance",
  },
  {
    id: "m3-xb",
    module: 3,
    moduleTitle: "Bottom Row Mastery",
    title: "X B comma",
    keys: ["x", "b", ","],
    intro: "Ring finger to X, index to B, middle to comma. Comma is a reach, not a glance.",
    tip: "B is a left-index stretch past V. Comma is right middle, below K.",
    keyDrills: keyDrill(["x", "b", ","], ["c", "v"]),
    wordDrills: fromPool(["box", "back", "able", "next", "mix", "cab", "beam", "calm"], 28),
    sentences: "next, mix a box; a calm cab; back, able, beam",
  },
  {
    id: "m3-zslash",
    module: 3,
    moduleTitle: "Bottom Row Mastery",
    title: "Z period slash",
    keys: ["z", ".", "/"],
    intro: "Left pinky drops to Z. Right ring to period, right pinky to slash. Weak fingers — press lightly.",
    tip: "Z is under A. Period is under L. Slash is under semicolon.",
    keyDrills: keyDrill(["z", ".", "/"], ["x", ","]),
    wordDrills: fromPool(["size", "zoom", "jazz", "lazy", "mix.", "next.", "a/b", "ok."], 28),
    sentences: "zoom a lazy jazz. mix a size. next. a/b.",
  },
  {
    id: "m3-review",
    module: 3,
    moduleTitle: "Bottom Row Mastery",
    title: "Bottom row review",
    keys: ["z", "x", "c", "v", "b", "n", "m", ",", ".", "/"],
    intro: "Full bottom row with home-row words mixed in. No looking down.",
    tip: "Down, tap, home. Same rule as the top row, opposite direction.",
    keyDrills: keyDrill(["z", "x", "c", "v", "b", "n", "m", ",", ".", "/"], HOME),
    wordDrills: fromPool(["size", "next", "back", "move", "zoom", "complex", "number", "simple", "example", "bronze"], 30),
    sentences: "next, mix a simple example. zoom back. a complex number. size the bronze box.",
  },
  {
    id: "m4-rshift",
    module: 4,
    moduleTitle: "Shift & Capitals",
    title: "Right Shift for left-hand letters",
    keys: ["A", "S", "D", "F", "G", "Q", "W", "E", "R", "T"],
    intro: "Hold Right Shift with the right pinky while the left hand types the capital. Never shift with the same hand that types the letter.",
    tip: "Right pinky on Right Shift, then left finger types. Release Shift as you release the letter.",
    keyDrills: "Aa Ss Dd Ff Gg Qq Ww Ee Rr Tt Zz Xx Cc Vv Bb Aa Ss Dd Ff",
    wordDrills: fromPool(["Adam", "Sara", "Dave", "Fred", "Greg", "Quinn", "Wes", "Eden", "Rita", "Tess"], 24),
    sentences: "Adam and Sara asked Dave. Fred gave Greg a Quest. Rita, Tess, and Wes can type.",
  },
  {
    id: "m4-lshift",
    module: 4,
    moduleTitle: "Shift & Capitals",
    title: "Left Shift for right-hand letters",
    keys: ["H", "J", "K", "L", "Y", "U", "I", "O", "P", "N", "M"],
    intro: "Left pinky holds Shift. Right hand types H J K L Y U I O P N M. Opposite hand, every time.",
    tip: "If a capital is late, you shifted with the wrong pinky.",
    keyDrills: "Hh Jj Kk Ll Yy Uu Ii Oo Pp Nn Mm Hh Jj Kk Ll Yy Uu",
    wordDrills: fromPool(["Hall", "June", "Kyle", "Liam", "Yves", "Uma", "Iris", "Omar", "Paul", "Nina", "Maya"], 24),
    sentences: "June and Kyle met Liam. Uma, Iris, Omar, Paul, Nina, and Maya type in Hall Y.",
  },
  {
    id: "m4-mixed",
    module: 4,
    moduleTitle: "Shift & Capitals",
    title: "Mixed capitalization",
    keys: ["A", "I", "T"],
    intro: "Sentences with real capitals. Opposite-hand Shift on every capital, including the first letter of a sentence.",
    tip: "Sentence start uses Left Shift + the right-hand letter, or Right Shift + the left-hand letter.",
    keyDrills: "The Quick Brown Fox The Quick Brown Fox Aa Ss Dd Ff Gg Hh Jj",
    wordDrills: fromPool(["India", "Delhi", "Mumbai", "Campus", "Monday", "Friday", "January", "August", "Please", "Thank"], 24),
    sentences: "Please type this. Thank you, India. Delhi and Mumbai on Monday. January to August.",
  },
  {
    id: "m5-nums",
    module: 5,
    moduleTitle: "Numbers, Symbols & Punctuation",
    title: "Number row",
    keys: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
    intro: "Each number belongs to the same finger as the key below it. Reach up, press, return home.",
    tip: "1 is left pinky, 2 ring, 3 middle, 4 and 5 index. Mirror on the right for 6–0.",
    keyDrills: keyDrill(["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]),
    wordDrills: fromPool(["10", "25", "40", "55", "60", "75", "80", "99", "100", "2024", "35", "45"], 28),
    sentences: "call 10 25 40. train 55 arrives at 18 40. code 2024 99 75.",
  },
  {
    id: "m5-punct",
    module: 5,
    moduleTitle: "Numbers, Symbols & Punctuation",
    title: "Punctuation",
    keys: [".", ",", ";", ":", "'", "?", "!"],
    intro: "Period and comma are right-hand reaches. Colon is Left Shift + semicolon. Question mark is Left Shift + slash.",
    tip: "Question mark and slash share a key. Slash is right pinky, so Shift is the left pinky.",
    keyDrills: "a, b. c; d: e' f? g! a, b. c; d: hello, world.",
    wordDrills: "yes, no. wait; go: it's fine? stop! well, maybe.",
    sentences: "Wait, is this ready? Yes, it is. Stop; look: it's done! Well, maybe not.",
  },
  {
    id: "m5-symbols",
    module: 5,
    moduleTitle: "Numbers, Symbols & Punctuation",
    title: "Common symbols",
    keys: ["@", "#", "$", "%", "&", "*", "(", ")", "-", "_"],
    intro: "Shift + number row. Opposite-hand Shift still applies. These show up in emails, code, and exam passages.",
    tip: "@ is Left Shift + 2 (right-ring number). $ is Right Shift + 4 (left-index number).",
    keyDrills: "@ # $ % & * ( ) - _ @email #tag $100 50% a&b (ok) file_1",
    wordDrills: "user@mail.com #ref $40 10% a & b (note) file_name two-way",
    sentences: "email user@mail.com, quote #12, pay $40 (10% off) and save file_name-2.",
  },
  {
    id: "m5-review",
    module: 5,
    moduleTitle: "Numbers, Symbols & Punctuation",
    title: "Mixed review",
    keys: ["1", "@", ".", "?"],
    intro: "Everything together. Pass this at 95% accuracy to complete the academy.",
    tip: "Read a few words ahead. Let the fingers follow the text, not the other way around.",
    keyDrills: "A1 b2 C3 @mail, 10%. Yes? No! (ok) file_2",
    wordDrills: "On 12 May, 40% of staff (n=120) said yes. Email hr@office.in.",
    sentences:
      "On 12 May 2024, 40% of the staff (n = 120) said yes. Please email hr@office.in with form #88.",
  },
];

export const UNLOCK_ACCURACY = 95;

export const STAGE_FLOW: { id: LessonStage; label: string }[] = [
  { id: "intro", label: "Intro" },
  { id: "keys", label: "Keys" },
  { id: "words", label: "Words" },
  { id: "sentences", label: "Sentences" },
];

export function lessonById(id: string): Lesson | undefined {
  return LESSONS.find((l) => l.id === id);
}

export function isLessonUnlocked(id: string, completed: string[]): boolean {
  const idx = LESSONS.findIndex((l) => l.id === id);
  if (idx <= 0) return true;
  const prev = LESSONS[idx - 1];
  return prev ? completed.includes(prev.id) : true;
}

export function nextOpenLesson(completed: string[]): Lesson | undefined {
  return LESSONS.find((l) => isLessonUnlocked(l.id, completed) && !completed.includes(l.id));
}

export function stageUnlocked(
  stage: LessonStage,
  done: ("keys" | "words" | "sentences")[] | undefined,
): boolean {
  if (stage === "intro" || stage === "keys") return true;
  if (stage === "words") return !!done?.includes("keys");
  if (stage === "sentences") return !!done?.includes("words");
  return false;
}

export function nextStageAfter(stage: LessonStage): LessonStage | null {
  if (stage === "intro") return "keys";
  if (stage === "keys") return "words";
  if (stage === "words") return "sentences";
  return null;
}

export function stageText(lesson: Lesson, stage: LessonStage): string {
  if (stage === "keys") return lesson.keyDrills;
  if (stage === "words") return lesson.wordDrills;
  if (stage === "sentences") return lesson.sentences;
  return lesson.keyDrills;
}

export function keyLabel(k: string): string {
  if (k === " ") return "Space";
  return k;
}

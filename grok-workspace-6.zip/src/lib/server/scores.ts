import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";

const scoreInput = z.object({
  mode: z.string().min(1).max(32),
  category: z.string().min(1).max(32),
  wpm: z.number().int().min(0).max(400),
  rawWpm: z.number().int().min(0).max(400),
  accuracy: z.number().min(0).max(100),
  durationMs: z.number().int().min(0).max(3_600_000),
  displayName: z.string().min(1).max(64),
});

export const saveScore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(scoreInput)
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      insert into typing_scores (user_id, display_name, mode, category, wpm, raw_wpm, accuracy, duration_ms)
      values (${context.userId}, ${data.displayName}, ${data.mode}, ${data.category}, ${data.wpm}, ${data.rawWpm}, ${data.accuracy}, ${data.durationMs})
      returning id
    `;
    return { id: rows[0]?.id ?? 0 };
  });

const progressShape = z.object({
  xp: z.number().int().min(0),
  streak: z.number().int().min(0),
  lastPracticeDate: z.string().nullable(),
  completedLessons: z.array(z.string()),
  lessonBest: z.record(z.string(), z.object({ accuracy: z.number(), wpm: z.number() })),
  weakWords: z.array(z.string()),
  letterErrors: z.record(z.string(), z.number()),
  fingerErrors: z.record(z.string(), z.number()),
  testsCompleted: z.number().int().min(0),
  bestWpm: z.number().int().min(0),
});

export const saveMyProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(progressShape)
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    await sql.query(
      `insert into typing_progress
         (user_id, xp, streak, last_practice_date, completed_lessons, lesson_best, weak_words, letter_errors, finger_errors, tests_completed, best_wpm, updated_at)
       values ($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7::jsonb,$8::jsonb,$9::jsonb,$10,$11, now())
       on conflict (user_id) do update set
         xp = greatest(typing_progress.xp, excluded.xp),
         streak = greatest(typing_progress.streak, excluded.streak),
         last_practice_date = excluded.last_practice_date,
         completed_lessons = excluded.completed_lessons,
         lesson_best = excluded.lesson_best,
         weak_words = excluded.weak_words,
         letter_errors = excluded.letter_errors,
         finger_errors = excluded.finger_errors,
         tests_completed = greatest(typing_progress.tests_completed, excluded.tests_completed),
         best_wpm = greatest(typing_progress.best_wpm, excluded.best_wpm),
         updated_at = now()`,
      [
        context.userId,
        data.xp,
        data.streak,
        data.lastPracticeDate,
        JSON.stringify(data.completedLessons),
        JSON.stringify(data.lessonBest),
        JSON.stringify(data.weakWords),
        JSON.stringify(data.letterErrors),
        JSON.stringify(data.fingerErrors),
        data.testsCompleted,
        data.bestWpm,
      ],
    );
    return { ok: true as const };
  });

export const getMyProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{
      xp: number;
      streak: number;
      last_practice_date: string | null;
      completed_lessons: unknown;
      lesson_best: unknown;
      weak_words: unknown;
      letter_errors: unknown;
      finger_errors: unknown;
      tests_completed: number;
      best_wpm: number;
    }>`
      select xp, streak, last_practice_date, completed_lessons, lesson_best, weak_words, letter_errors, finger_errors, tests_completed, best_wpm
      from typing_progress where user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return null;
    return {
      xp: row.xp,
      streak: row.streak,
      lastPracticeDate: row.last_practice_date,
      completedLessons: (row.completed_lessons as string[]) ?? [],
      lessonBest: (row.lesson_best as Record<string, { accuracy: number; wpm: number }>) ?? {},
      weakWords: (row.weak_words as string[]) ?? [],
      letterErrors: (row.letter_errors as Record<string, number>) ?? {},
      fingerErrors: (row.finger_errors as Record<string, number>) ?? {},
      testsCompleted: row.tests_completed,
      bestWpm: row.best_wpm,
    };
  });

const boardInput = z.object({
  scope: z.enum(["daily", "all", "exam", "lesson"]),
});

export const getLeaderboard = createServerFn({ method: "GET" })
  .validator(boardInput)
  .handler(async ({ data }) => {
    const sql = await getSql();
    const filter =
      data.scope === "exam"
        ? "mode = 'exam'"
        : data.scope === "lesson"
          ? "mode = 'lesson'"
          : data.scope === "daily"
            ? "created_at >= date_trunc('day', now())"
            : "true";
    const rows = await sql.query<{
      display_name: string;
      mode: string;
      category: string;
      wpm: number;
      accuracy: number;
      created_at: string;
    }>(
      `select display_name, mode, category, wpm, accuracy, created_at
       from typing_scores
       where ${filter}
       order by wpm desc, accuracy desc, created_at asc
       limit 50`,
    );
    return rows;
  });

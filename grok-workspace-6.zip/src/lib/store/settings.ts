import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ThemeId = "paper" | "dark" | "oled" | "terminal";
export type SwitchType = "off" | "red" | "brown" | "blue";
export type CaretStyle = "bar" | "block" | "underline";

export const THEMES: { id: ThemeId; label: string }[] = [
  { id: "paper", label: "Clean Light" },
  { id: "dark", label: "Dark Minimal" },
  { id: "oled", label: "OLED Black" },
  { id: "terminal", label: "Retro Terminal" },
];

export const SWITCHES: { id: SwitchType; label: string }[] = [
  { id: "off", label: "Silent" },
  { id: "red", label: "Cherry MX Red" },
  { id: "brown", label: "Cherry MX Brown" },
  { id: "blue", label: "Cherry MX Blue" },
];

type SettingsState = {
  theme: ThemeId;
  sound: SwitchType;
  caret: CaretStyle;
  fontSize: number;
  showKeyboard: boolean;
  showHands: boolean;
  punctuation: boolean;
  numbers: boolean;
  setTheme: (t: ThemeId) => void;
  setSound: (s: SwitchType) => void;
  setCaret: (c: CaretStyle) => void;
  setFontSize: (n: number) => void;
  setShowKeyboard: (v: boolean) => void;
  setShowHands: (v: boolean) => void;
  setPunctuation: (v: boolean) => void;
  setNumbers: (v: boolean) => void;
};

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      theme: "paper",
      sound: "off",
      caret: "bar",
      fontSize: 28,
      showKeyboard: true,
      showHands: true,
      punctuation: false,
      numbers: false,
      setTheme: (theme) => set({ theme }),
      setSound: (sound) => set({ sound }),
      setCaret: (caret) => set({ caret }),
      setFontSize: (fontSize) => set({ fontSize }),
      setShowKeyboard: (showKeyboard) => set({ showKeyboard }),
      setShowHands: (showHands) => set({ showHands }),
      setPunctuation: (punctuation) => set({ punctuation }),
      setNumbers: (numbers) => set({ numbers }),
    }),
    { name: "ta-settings" },
  ),
);

export function applyTheme(theme: ThemeId | "google") {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = theme === "google" ? "paper" : theme;
}

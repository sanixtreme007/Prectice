import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { TestResult } from "@/lib/typing/engine";

export type RecentTest = {
  at: number;
  mode: string;
  category: string;
  wpm: number;
  accuracy: number;
  xp: number;
};

type ProgressState = {
  xp: number;
  streak: number;
  lastPracticeDate: string | null;
  completedLessons: string[];
  lessonBest: Record<string, { accuracy: number; wpm: number }>;
  lessonStages: Record<string, ("keys" | "words" | "sentences")[]>;
  weakWords: string[];
  letterErrors: Record<string, number>;
  fingerErrors: Record<string, number>;
  testsCompleted: number;
  bestWpm: number;
  recent: RecentTest[];
  applyResult: (opts: {
    result: TestResult;
    mode: string;
    category: string;
    xp: number;
    lessonId?: string;
    passedLesson?: boolean;
    lessonStage?: "keys" | "words" | "sentences";
    passedStage?: boolean;
  }) => void;
  hydrateCloud: (data: {
    xp: number;
    streak: number;
    lastPracticeDate: string | null;
    completedLessons: string[];
    lessonBest: Record<string, { accuracy: number; wpm: number }>;
    weakWords: string[];
    letterErrors: Record<string, number>;
    fingerErrors: Record<string, number>;
    testsCompleted: number;
    bestWpm: number;
  }) => void;
  snapshot: () => Omit<
    ProgressState,
    "applyResult" | "hydrateCloud" | "snapshot" | "recent" | "lessonStages"
  >;
};

function todayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function yesterdayISO() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function bumpStreak(last: string | null): { streakAdd: "reset" | "keep" | "inc"; date: string } {
  const today = todayISO();
  if (last === today) return { streakAdd: "keep", date: today };
  if (last === yesterdayISO()) return { streakAdd: "inc", date: today };
  return { streakAdd: "reset", date: today };
}

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      xp: 0,
      streak: 0,
      lastPracticeDate: null,
      completedLessons: [],
      lessonBest: {},
      lessonStages: {},
      weakWords: [],
      letterErrors: {},
      fingerErrors: {},
      testsCompleted: 0,
      bestWpm: 0,
      recent: [],
      applyResult: ({ result, mode, category, xp, lessonId, passedLesson, lessonStage, passedStage }) => {
        const { streakAdd, date } = bumpStreak(get().lastPracticeDate);
        set((s) => {
          const letterErrors = { ...s.letterErrors };
          for (const [k, v] of Object.entries(result.letterErrors)) {
            letterErrors[k] = (letterErrors[k] ?? 0) + v;
          }
          const fingerErrors = { ...s.fingerErrors };
          for (const [k, v] of Object.entries(result.fingerErrors)) {
            fingerErrors[k] = (fingerErrors[k] ?? 0) + v;
          }
          const weak = [...result.weakWords, ...s.weakWords]
            .filter((w, i, arr) => w.length > 1 && arr.indexOf(w) === i)
            .slice(0, 80);
          const completed = passedLesson && lessonId && !s.completedLessons.includes(lessonId)
            ? [...s.completedLessons, lessonId]
            : s.completedLessons;
          const lessonBest = { ...s.lessonBest };
          if (lessonId) {
            const prev = lessonBest[lessonId];
            if (!prev || result.accuracy > prev.accuracy || (result.accuracy === prev.accuracy && result.wpm > prev.wpm)) {
              lessonBest[lessonId] = { accuracy: result.accuracy, wpm: result.wpm };
            }
          }
          const lessonStages = { ...(s.lessonStages ?? {}) };
          if (lessonId && passedStage && lessonStage) {
            const prev = lessonStages[lessonId] ?? [];
            if (!prev.includes(lessonStage)) lessonStages[lessonId] = [...prev, lessonStage];
          }
          let streak = s.streak;
          if (streakAdd === "reset") streak = 1;
          else if (streakAdd === "inc") streak = s.streak + 1;
          return {
            xp: s.xp + xp,
            streak,
            lastPracticeDate: date,
            completedLessons: completed,
            lessonBest,
            lessonStages,
            weakWords: weak,
            letterErrors,
            fingerErrors,
            testsCompleted: s.testsCompleted + 1,
            bestWpm: Math.max(s.bestWpm, result.wpm),
            recent: [
              { at: Date.now(), mode, category, wpm: result.wpm, accuracy: result.accuracy, xp },
              ...s.recent,
            ].slice(0, 20),
          };
        });
      },
      hydrateCloud: (data) => {
        set({
          xp: Math.max(get().xp, data.xp),
          streak: Math.max(get().streak, data.streak),
          lastPracticeDate: data.lastPracticeDate ?? get().lastPracticeDate,
          completedLessons: Array.from(
            new Set([...get().completedLessons, ...data.completedLessons]),
          ),
          lessonBest: { ...data.lessonBest, ...get().lessonBest },
          weakWords: Array.from(new Set([...data.weakWords, ...get().weakWords])).slice(0, 80),
          letterErrors: { ...data.letterErrors, ...get().letterErrors },
          fingerErrors: { ...data.fingerErrors, ...get().fingerErrors },
          testsCompleted: Math.max(get().testsCompleted, data.testsCompleted),
          bestWpm: Math.max(get().bestWpm, data.bestWpm),
        });
      },
      snapshot: () => {
        const s = get();
        return {
          xp: s.xp,
          streak: s.streak,
          lastPracticeDate: s.lastPracticeDate,
          completedLessons: s.completedLessons,
          lessonBest: s.lessonBest,
          weakWords: s.weakWords,
          letterErrors: s.letterErrors,
          fingerErrors: s.fingerErrors,
          testsCompleted: s.testsCompleted,
          bestWpm: s.bestWpm,
        };
      },
    }),
    { name: "ta-progress" },
  ),
);

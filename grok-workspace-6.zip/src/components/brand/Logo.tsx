import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <Link
      to="/"
      className={cn("flex items-center gap-2 font-display tracking-tight", className)}
    >
      <span className="grid size-7 shrink-0 place-items-center rounded-md bg-primary font-[family-name:var(--font-devanagari)] text-sm font-semibold text-primary-fg">
        अ
      </span>
      {compact ? (
        <span className="text-lg font-semibold leading-none">Abhyas</span>
      ) : (
        <span className="text-lg font-semibold leading-none sm:text-xl">
          <span className="font-medium text-muted">Typing</span> Abhyas
        </span>
      )}
    </Link>
  );
}

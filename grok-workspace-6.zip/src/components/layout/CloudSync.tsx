import { useEffect, useRef } from "react";
import { getMyProgress, saveMyProgress } from "@/lib/server/scores";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { useProgress } from "@/lib/store/progress";

export function CloudSync() {
  const user = useCurrentUser();
  const loadedFor = useRef<string | null>(null);

  useEffect(() => {
    if (!user || user.isDevFallback) return;
    if (loadedFor.current === user.id) return;
    loadedFor.current = user.id;
    void (async () => {
      try {
        const cloud = await getMyProgress();
        if (cloud) useProgress.getState().hydrateCloud(cloud);
        const snap = useProgress.getState().snapshot();
        await saveMyProgress({ data: snap });
      } catch {
        loadedFor.current = null;
      }
    })();
  }, [user]);

  return null;
}

export async function pushProgress() {
  try {
    const snap = useProgress.getState().snapshot();
    await saveMyProgress({ data: snap });
  } catch {
    /* guest or offline */
  }
}

import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  Code2,
  Flag,
  Keyboard,
  Medal,
  Palette,
  Settings2,
  Swords,
  UserRound,
  Volume2,
} from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { applyTheme, SWITCHES, THEMES, useSettings } from "@/lib/store/settings";
import { useProgress } from "@/lib/store/progress";
import { cn } from "@/lib/utils";

const NAV: { to: string; label: string; icon: typeof Keyboard; exact?: boolean }[] = [
  { to: "/", label: "Practice", icon: Keyboard, exact: true },
  { to: "/learn", label: "Learn", icon: BookOpen },
  { to: "/exam", label: "Exam", icon: Flag },
  { to: "/code", label: "Code", icon: Code2 },
  { to: "/race", label: "Race", icon: Swords },
  { to: "/leaderboard", label: "Board", icon: Medal },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hide = pathname === "/login";
  const theme = useSettings((s) => s.theme);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  if (hide) return <>{children}</>;

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-3 sm:h-16 sm:px-6">
          <Logo compact className="shrink-0 sm:hidden" />
          <Logo className="hidden shrink-0 sm:flex" />
          <nav className="ml-2 hidden items-center gap-0.5 lg:flex">
            {NAV.map((item) => {
              const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-md px-2.5 py-1.5 text-sm font-medium transition-colors",
                    active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            <XpChip />
            <SoundMenu />
            <ThemeMenu />
            <AuthSlot />
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-3 py-6 pb-24 sm:px-6 sm:py-10 lg:pb-10">
        {children}
      </main>

      <nav className="fixed right-0 bottom-0 left-0 z-30 border-t border-border bg-bg/95 px-1 py-1 lg:hidden">
        <div className="grid grid-cols-6 gap-0.5">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-md text-[10px] font-medium",
                  active ? "text-primary" : "text-muted",
                )}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function XpChip() {
  const xp = useProgress((s) => s.xp);
  const streak = useProgress((s) => s.streak);
  return (
    <Link
      to="/profile"
      className="hidden items-center gap-2 rounded-full border border-border bg-surface px-2.5 py-1 text-xs font-medium text-muted sm:flex"
    >
      <span className="tabular-nums text-fg">{xp} XP</span>
      <span className="text-subtle">·</span>
      <span className="tabular-nums">{streak}d</span>
    </Link>
  );
}

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Skeleton className="h-8 w-8 rounded-full" />;
  if (user) return <UserButton />;
  return (
    <div className="flex items-center gap-1">
      <Button variant="ghost" size="icon-sm" asChild className="sm:hidden">
        <Link to="/profile" aria-label="Profile">
          <UserRound className="size-4" />
        </Link>
      </Button>
      <SignedOut>
        <Button size="sm" asChild>
          <Link to="/login">Sign in</Link>
        </Button>
      </SignedOut>
    </div>
  );
}

function ThemeMenu() {
  const theme = useSettings((s) => s.theme);
  const setTheme = useSettings((s) => s.setTheme);
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon-sm" aria-label="Theme">
          <Palette className="size-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>Theme</DropdownMenuLabel>
        {THEMES.map((t) => (
          <DropdownMenuItem key={t.id} onSelect={() => setTheme(t.id)}>
            {t.id === theme ? "● " : "○ "}
            {t.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function SoundMenu() {
  const sound = useSettings((s) => s.sound);
  const setSound = useSettings((s) => s.setSound);
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon-sm" aria-label="Sound">
          <Volume2 className="size-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>Key sound</DropdownMenuLabel>
        {SWITCHES.map((s) => (
          <DropdownMenuItem key={s.id} onSelect={() => setSound(s.id)}>
            {s.id === sound ? "● " : "○ "}
            {s.label}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/profile">
            <Settings2 className="size-3.5" />
            More settings
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function PageTitle({
  kicker,
  title,
  desc,
}: {
  kicker?: string;
  title: string;
  desc?: string;
}) {
  return (
    <div className="mb-8 max-w-2xl">
      {kicker && (
        <p className="mb-1 text-xs font-medium tracking-widest text-primary uppercase">{kicker}</p>
      )}
      <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">{title}</h1>
      {desc && <p className="mt-2 text-sm text-muted sm:text-base">{desc}</p>}
    </div>
  );
}

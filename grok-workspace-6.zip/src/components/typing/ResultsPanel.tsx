import { Link } from "@tanstack/react-router";
import { RotateCcw } from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { FingerHeatmap } from "@/components/typing/Heatmap";
import type { TestResult } from "@/lib/typing/engine";
import { SignedIn, SignedOut } from "@/lib/auth/gates";

export function ResultsPanel({
  result,
  onRestart,
  onPost,
  posting,
  posted,
  showWeakLink,
}: {
  result: TestResult;
  onRestart: () => void;
  onPost?: () => void;
  posting?: boolean;
  posted?: boolean;
  showWeakLink?: boolean;
}) {
  const data = result.samples.map((s) => ({
    t: Math.round(s.t),
    wpm: s.wpm,
    raw: s.rawWpm,
  }));

  return (
    <div className="mx-auto w-full max-w-3xl space-y-8 px-2">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Big n={result.wpm} l="WPM" />
        <Big n={`${Math.round(result.accuracy)}%`} l="Accuracy" />
        <Big n={result.rawWpm} l="Raw WPM" />
        <Big n={result.cpm} l="CPM" />
      </div>

      <div className="h-48 rounded-xl border border-border bg-surface p-3 sm:h-56">
        {data.length > 1 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid stroke="currentColor" strokeOpacity={0.08} />
              <XAxis dataKey="t" tick={{ fontSize: 11 }} stroke="currentColor" opacity={0.4} />
              <YAxis tick={{ fontSize: 11 }} stroke="currentColor" opacity={0.4} />
              <Tooltip
                contentStyle={{
                  background: "var(--surface)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                }}
              />
              <Line type="monotone" dataKey="wpm" stroke="var(--primary)" dot={false} strokeWidth={2} />
              <Line
                type="monotone"
                dataKey="raw"
                stroke="var(--muted)"
                dot={false}
                strokeWidth={1.5}
                strokeDasharray="4 4"
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="grid h-full place-items-center text-sm text-muted">Not enough samples</div>
        )}
      </div>

      <FingerHeatmap errors={result.fingerErrors} />

      {result.weakWords.length > 0 && (
        <div>
          <h3 className="mb-2 text-sm font-medium text-muted">Words to retest</h3>
          <div className="flex flex-wrap gap-1.5">
            {result.weakWords.slice(0, 16).map((w) => (
              <span
                key={w}
                className="rounded-full bg-incorrect/10 px-2.5 py-1 font-mono text-xs text-incorrect"
              >
                {w}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-center gap-2">
        <Button onClick={onRestart}>
          <RotateCcw className="size-4" />
          Try again
        </Button>
        {showWeakLink && result.weakWords.length > 0 && (
          <Button variant="outline" asChild>
            <Link to="/" search={{ weak: "1" }}>
              Practice weak words
            </Link>
          </Button>
        )}
        {onPost && (
          <>
            <SignedIn>
              <Button variant="secondary" onClick={onPost} disabled={posting || posted}>
                {posted ? "Posted" : posting ? "Posting…" : "Post to leaderboard"}
              </Button>
            </SignedIn>
            <SignedOut>
              <Button variant="secondary" asChild>
                <Link to="/login">Sign in to post</Link>
              </Button>
            </SignedOut>
          </>
        )}
      </div>
    </div>
  );
}

function Big({ n, l }: { n: string | number; l: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-3 py-4 text-center">
      <div className="font-mono text-3xl font-medium tabular-nums text-primary">{n}</div>
      <div className="mt-1 text-[11px] font-medium tracking-widest text-subtle uppercase">{l}</div>
    </div>
  );
}

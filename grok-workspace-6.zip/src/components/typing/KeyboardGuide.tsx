import {
  FINGER_COLOR_CLASS,
  KEYBOARD_ROWS,
  baseKey,
  fingerForKeyId,
  needsShift,
  shiftHand,
} from "@/lib/typing/keymap";
import { cn } from "@/lib/utils";

export function KeyboardGuide({
  nextChar,
  highlightKeys,
  className,
}: {
  nextChar: string | null;
  highlightKeys?: string[];
  className?: string;
}) {
  const target = nextChar ? baseKey(nextChar) : null;
  const shift = nextChar ? shiftHand(nextChar) : null;
  const showShift = nextChar ? needsShift(nextChar) : false;
  const marked = new Set((highlightKeys ?? []).map((k) => baseKey(k)));

  return (
    <div className={cn("mx-auto w-full max-w-3xl select-none", className)}>
      <div className="flex flex-col gap-1 rounded-xl border border-border bg-surface p-2 sm:p-3">
        {KEYBOARD_ROWS.map((row, ri) => (
          <div key={ri} className="flex justify-center gap-1">
            {row.map((key) => {
              const finger = fingerForKeyId(key.id);
              const isTarget = target === key.id;
              const isShift =
                showShift &&
                ((shift === "left" && key.id === "shiftleft") ||
                  (shift === "right" && key.id === "shiftright"));
              const active = isTarget || isShift;
              const isNew = marked.has(key.id);
              return (
                <div
                  key={key.id}
                  style={{ flex: key.width }}
                  className={cn(
                    "relative flex h-8 items-center justify-center overflow-hidden rounded-sm border text-[10px] font-medium sm:h-10 sm:rounded-md sm:text-xs",
                    active
                      ? "key-pulse border-primary bg-primary text-primary-fg"
                      : isNew
                        ? "border-primary/50 bg-primary/10 text-fg"
                        : "border-border bg-surface-2 text-muted",
                  )}
                >
                  {finger && !active && (
                    <>
                      <span
                        className={cn(
                          "pointer-events-none absolute inset-x-0 bottom-0 h-1 rounded-b-sm sm:rounded-b-md",
                          FINGER_COLOR_CLASS[finger],
                        )}
                      />
                      <span
                        className={cn(
                          "pointer-events-none absolute inset-0 opacity-[0.18]",
                          FINGER_COLOR_CLASS[finger],
                        )}
                      />
                    </>
                  )}
                  {key.home && !active && (
                    <span className="absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-subtle" />
                  )}
                  <span className="relative">{key.label}</span>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

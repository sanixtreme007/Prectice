import { FINGER_COLOR_CLASS, FINGER_LABEL, type FingerId } from "@/lib/typing/keymap";
import { cn } from "@/lib/utils";

const ORDER: FingerId[] = ["LP", "LR", "LM", "LI", "TH", "RI", "RM", "RR", "RP"];

export function FingerHeatmap({ errors }: { errors: Record<string, number> }) {
  const max = Math.max(1, ...ORDER.map((id) => errors[id] ?? 0));
  return (
    <div>
      <h3 className="mb-3 text-sm font-medium text-muted">Finger errors</h3>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-9">
        {ORDER.map((id) => {
          const n = errors[id] ?? 0;
          const heat = n / max;
          return (
            <div
              key={id}
              className="flex flex-col items-center gap-1.5 rounded-lg border border-border bg-surface px-1 py-2"
            >
              <span
                className={cn("size-3 rounded-full", FINGER_COLOR_CLASS[id])}
                style={{ opacity: 0.35 + heat * 0.65 }}
              />
              <span className="font-mono text-sm tabular-nums">{n}</span>
              <span className="text-center text-[10px] leading-tight text-subtle">
                {FINGER_LABEL[id].replace(" ", "\n")}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

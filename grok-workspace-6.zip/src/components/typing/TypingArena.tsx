import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  TypingEngine,
  type BackspaceMode,
  type EngineSnapshot,
  type TestResult,
} from "@/lib/typing/engine";
import { playKeySound, primeAudio } from "@/lib/typing/sounds";
import { useSettings } from "@/lib/store/settings";
import { cn } from "@/lib/utils";

type Props = {
  text: string;
  durationMs?: number | null;
  backspace?: BackspaceMode;
  font?: "mono" | "devanagari";
  onFinish: (result: TestResult) => void;
  onSnapshot?: (snap: EngineSnapshot) => void;
  className?: string;
  autoFocus?: boolean;
};

export function TypingArena({
  text,
  durationMs = null,
  backspace = "full",
  font = "mono",
  onFinish,
  onSnapshot,
  className,
  autoFocus = true,
}: Props) {
  const engineRef = useRef<TypingEngine | null>(null);
  const [snap, setSnap] = useState<EngineSnapshot>(() => {
    const e = new TypingEngine({ text, durationMs, backspace });
    engineRef.current = e;
    return e.snapshot();
  });
  const wrapRef = useRef<HTMLDivElement>(null);
  const caretRef = useRef<HTMLSpanElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [caretPos, setCaretPos] = useState({ x: 0, y: 0, h: 0 });
  const [focused, setFocused] = useState(false);
  const finishedRef = useRef(false);
  const { sound, caret, fontSize } = useSettings();

  const refresh = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    const next = e.snapshot();
    setSnap(next);
    onSnapshot?.(next);
    if (next.status === "finished" && !finishedRef.current) {
      finishedRef.current = true;
      onFinish(e.result());
    }
  }, [onFinish, onSnapshot]);

  useEffect(() => {
    const e = new TypingEngine({ text, durationMs, backspace });
    engineRef.current = e;
    finishedRef.current = false;
    setSnap(e.snapshot());
    onSnapshot?.(e.snapshot());
    if (autoFocus) inputRef.current?.focus();
  }, [text, durationMs, backspace, autoFocus, onSnapshot]);

  useEffect(() => {
    const id = window.setInterval(() => {
      const e = engineRef.current;
      if (!e || e.status !== "running") return;
      e.tick();
      refresh();
    }, 100);
    return () => window.clearInterval(id);
  }, [refresh]);

  useLayoutEffect(() => {
    const wrap = wrapRef.current;
    const caretEl = caretRef.current;
    if (!wrap || !caretEl) return;
    const w = wrap.getBoundingClientRect();
    const c = caretEl.getBoundingClientRect();
    setCaretPos({ x: c.left - w.left, y: c.top - w.top, h: c.height });
  }, [snap.caret, snap.text, fontSize]);

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Tab") {
      e.preventDefault();
      const engine = new TypingEngine({ text, durationMs, backspace });
      engineRef.current = engine;
      finishedRef.current = false;
      setSnap(engine.snapshot());
      return;
    }
    primeAudio();
    const handled = engineRef.current?.handleKey(e.nativeEvent);
    if (handled) {
      e.preventDefault();
      const flag = engineRef.current?.flags[(engineRef.current.caret ?? 1) - 1];
      playKeySound(sound, flag === 2);
      refresh();
    }
  };

  const onInput = (e: React.FormEvent<HTMLTextAreaElement>) => {
    const v = e.currentTarget.value;
    if (!v) return;
    e.currentTarget.value = "";
    primeAudio();
    for (const ch of v) {
      engineRef.current?.handleKey({ key: ch });
    }
    playKeySound(sound, false);
    refresh();
  };

  const nextChar = snap.text[snap.caret] ?? null;
  const running = snap.status === "running";

  return (
    <div className={cn("relative", className)}>
      <textarea
        ref={inputRef}
        aria-label="Typing input"
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
        className="sr-only"
        onKeyDown={onKeyDown}
        onInput={onInput}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        value=""
        onChange={() => undefined}
      />
      <div
        ref={wrapRef}
        role="group"
        tabIndex={0}
        onClick={() => inputRef.current?.focus()}
        className={cn(
          "relative mx-auto max-w-3xl cursor-text rounded-xl px-2 py-6 leading-relaxed break-words select-none sm:px-4",
          font === "devanagari" ? "font-[family-name:var(--font-devanagari)]" : "font-mono",
          !focused && snap.status === "idle" && "opacity-80",
        )}
        style={{ fontSize }}
      >
        {snap.text.split("").map((ch, i) => {
          const flag = snap.flags[i] ?? 0;
          const isCaret = i === snap.caret;
          return (
            <span
              key={i}
              ref={isCaret ? caretRef : undefined}
              className={cn(
                "relative inline",
                flag === 0 && "text-pending",
                flag === 1 && "text-correct",
                flag === 2 && "text-incorrect",
                ch === " " && flag === 2 && "bg-incorrect/20",
              )}
            >
              {ch === " " ? "\u00a0" : ch}
            </span>
          );
        })}
        {snap.caret >= snap.text.length && <span ref={caretRef} className="inline-block w-0" />}
        <span
          aria-hidden
          className={cn(
            "pointer-events-none absolute rounded-sm bg-caret",
            snap.status !== "running" && "caret-blink",
            caret === "bar" && "w-0.5",
            caret === "block" && "w-[0.6ch] opacity-40",
            caret === "underline" && "h-0.5",
          )}
          style={{
            left: caretPos.x,
            top: caret === "underline" ? caretPos.y + caretPos.h - 2 : caretPos.y,
            height: caret === "underline" ? 2 : caretPos.h || fontSize,
            width: caret === "bar" ? 2 : caret === "block" ? undefined : undefined,
          }}
        />
      </div>
      {snap.status === "idle" && (
        <p className="mt-2 text-center text-sm text-subtle">
          {focused ? "Start typing" : "Click the text and start typing"}
          {nextChar ? "" : ""}
          <span className="hidden sm:inline"> · Tab to restart</span>
        </p>
      )}
      {snap.capsLock && running && (
        <p className="mt-2 text-center text-sm text-incorrect">Caps Lock is on</p>
      )}
    </div>
  );
}

export function StatsBar({ snap }: { snap: EngineSnapshot }) {
  const time =
    snap.remainingMs != null
      ? Math.ceil(snap.remainingMs / 1000)
      : Math.floor(snap.elapsedMs / 1000);
  return (
    <div className="flex flex-wrap items-end justify-center gap-6 font-mono tabular-nums sm:gap-10">
      <Stat label="wpm" value={snap.status === "idle" ? "—" : String(snap.wpm)} />
      <Stat label="acc" value={snap.status === "idle" ? "—" : `${Math.round(snap.accuracy)}%`} />
      <Stat label={snap.remainingMs != null ? "time" : "elapsed"} value={String(time)} />
      <Stat label="cpm" value={snap.status === "idle" ? "—" : String(snap.cpm)} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <div className="text-3xl font-medium tracking-tight text-primary sm:text-4xl">{value}</div>
      <div className="mt-1 text-[11px] font-medium tracking-widest text-subtle uppercase">
        {label}
      </div>
    </div>
  );
}

import { FINGER_COLOR_CLASS, FINGER_FILL_CLASS, FINGER_LABEL, type FingerId, fingerFor, shiftHand } from "@/lib/typing/keymap";
import { cn } from "@/lib/utils";

const LEFT_FINGERS: { id: FingerId; x: number; h: number; w: number }[] = [
  { id: "LP", x: 10, h: 56, w: 17 },
  { id: "LR", x: 31, h: 70, w: 18 },
  { id: "LM", x: 53, h: 80, w: 19 },
  { id: "LI", x: 76, h: 68, w: 18 },
];

const RIGHT_FINGERS: { id: FingerId; x: number; h: number; w: number }[] = [
  { id: "RI", x: 16, h: 68, w: 18 },
  { id: "RM", x: 38, h: 80, w: 19 },
  { id: "RR", x: 61, h: 70, w: 18 },
  { id: "RP", x: 83, h: 56, w: 17 },
];

function FingerPath({
  id,
  x,
  h,
  w,
  active,
}: {
  id: FingerId;
  x: number;
  h: number;
  w: number;
  active: boolean;
}) {
  const y = 96 - h;
  return (
    <g
      className={cn(active && "finger-pulse")}
      style={{ transformOrigin: `${x + w / 2}px 96px` }}
    >
      <rect
        x={x}
        y={y}
        width={w}
        height={h + 18}
        rx={w / 2}
        className={FINGER_FILL_CLASS[id]}
        opacity={active ? 1 : 0.38}
      />
      <ellipse
        cx={x + w / 2}
        cy={y + 7}
        rx={w * 0.26}
        ry={4.5}
        fill="color-mix(in oklab, white 55%, transparent)"
        opacity={active ? 0.7 : 0.25}
      />
    </g>
  );
}

function Thumb({
  side,
  active,
}: {
  side: "left" | "right";
  active: boolean;
}) {
  const rotate = side === "left" ? 42 : -42;
  const ox = side === "left" ? 104 : 16;
  const x = side === "left" ? 94 : 6;
  return (
    <g
      className={cn(active && "finger-pulse")}
      style={{ transformOrigin: `${ox}px 122px` }}
      transform={`rotate(${rotate} ${ox} 122)`}
    >
      <rect
        x={x}
        y={102}
        width={20}
        height={42}
        rx={10}
        className={FINGER_FILL_CLASS.TH}
        opacity={active ? 1 : 0.38}
      />
    </g>
  );
}

function OneHand({
  side,
  activeIds,
}: {
  side: "left" | "right";
  activeIds: Set<FingerId>;
}) {
  const fingers = side === "left" ? LEFT_FINGERS : RIGHT_FINGERS;
  return (
    <svg viewBox="0 0 120 158" className="h-36 w-36 sm:h-40 sm:w-40" aria-hidden>
      <ellipse
        cx="60"
        cy="146"
        rx="16"
        ry="5"
        fill="color-mix(in oklab, var(--fg) 10%, var(--surface))"
      />
      <ellipse
        cx="60"
        cy="118"
        rx="38"
        ry="24"
        fill="color-mix(in oklab, var(--fg) 13%, var(--surface))"
      />
      <Thumb side={side} active={activeIds.has("TH")} />
      {fingers.map((f) => (
        <FingerPath key={f.id} {...f} active={activeIds.has(f.id)} />
      ))}
    </svg>
  );
}

export function Hands({
  nextChar,
  caption = false,
}: {
  nextChar: string | null;
  caption?: boolean;
}) {
  const finger = nextChar ? fingerFor(nextChar) : null;
  const shift = nextChar ? shiftHand(nextChar) : null;

  const left = new Set<FingerId>();
  const right = new Set<FingerId>();
  if (finger === "TH") {
    left.add("TH");
    right.add("TH");
  } else if (finger?.startsWith("L")) left.add(finger);
  else if (finger?.startsWith("R")) right.add(finger);
  if (shift === "left") left.add("LP");
  if (shift === "right") right.add("RP");

  return (
    <div className="mx-auto w-full max-w-xl">
      <div className="flex items-end justify-center gap-6 sm:gap-12">
        <div className="flex flex-col items-center">
          <OneHand side="left" activeIds={left} />
          <span className="text-xs font-medium tracking-wide text-subtle uppercase">Left</span>
        </div>
        <div className="flex flex-col items-center">
          <OneHand side="right" activeIds={right} />
          <span className="text-xs font-medium tracking-wide text-subtle uppercase">Right</span>
        </div>
      </div>
      {caption && finger && (
        <p className="mt-3 flex items-center justify-center gap-2 text-sm text-muted">
          <span className={cn("inline-block size-2.5 rounded-full", FINGER_COLOR_CLASS[finger])} />
          {FINGER_LABEL[finger]}
          {shift ? ` + ${shift === "left" ? "Left" : "Right"} Shift` : ""}
        </p>
      )}
    </div>
  );
}

export function FingerLegend({ className }: { className?: string }) {
  const items: FingerId[] = ["LP", "LR", "LM", "LI", "TH", "RI", "RM", "RR", "RP"];
  return (
    <ul className={cn("flex flex-wrap justify-center gap-x-3 gap-y-1.5 text-xs text-muted", className)}>
      {items.map((id) => (
        <li key={id} className="inline-flex items-center gap-1.5">
          <span className={cn("size-2 rounded-full", FINGER_COLOR_CLASS[id])} />
          {FINGER_LABEL[id]}
        </li>
      ))}
    </ul>
  );
}

const HOME_KEYS = ["a", "s", "d", "f", "j", "k", "l", ";"] as const;

export function HomeRowRest() {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="mr-1 text-xs font-medium tracking-widest text-subtle uppercase">Rest on</span>
      {HOME_KEYS.map((k, i) => (
        <span key={k} className="contents">
          {i === 4 && <span className="mx-1 text-subtle">·</span>}
          <span
            className={cn(
              "relative grid size-8 place-items-center rounded-sm border font-mono text-sm",
              k === "f" || k === "j"
                ? "border-primary/40 bg-primary/10 text-fg"
                : "border-border bg-surface text-muted",
            )}
          >
            {k.toUpperCase()}
            {(k === "f" || k === "j") && (
              <span className="absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-primary" />
            )}
          </span>
        </span>
      ))}
    </div>
  );
}

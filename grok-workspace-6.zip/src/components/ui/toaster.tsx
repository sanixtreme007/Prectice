import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      theme="system"
      className="toaster"
      toastOptions={{
        classNames: {
          toast: "bg-surface text-fg border-border shadow-soft",
        },
      }}
    />
  );
}

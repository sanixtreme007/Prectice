-- Typing scores (leaderboard) and per-user progress.

create table if not exists typing_scores (
  id           serial primary key,
  user_id      text not null,
  display_name text not null,
  mode         text not null,
  category     text not null,
  wpm          integer not null,
  raw_wpm      integer not null,
  accuracy     real not null,
  duration_ms  integer not null,
  created_at   timestamptz not null default now()
);

create index if not exists typing_scores_board_idx
  on typing_scores (mode, category, wpm desc, created_at desc);

create index if not exists typing_scores_user_idx
  on typing_scores (user_id, created_at desc);

create index if not exists typing_scores_daily_idx
  on typing_scores (created_at desc, wpm desc);

create table if not exists typing_progress (
  user_id            text primary key,
  xp                 integer not null default 0,
  streak             integer not null default 0,
  last_practice_date date,
  completed_lessons  jsonb not null default '[]'::jsonb,
  lesson_best        jsonb not null default '{}'::jsonb,
  weak_words         jsonb not null default '[]'::jsonb,
  letter_errors      jsonb not null default '{}'::jsonb,
  finger_errors      jsonb not null default '{}'::jsonb,
  tests_completed    integer not null default 0,
  best_wpm           integer not null default 0,
  updated_at         timestamptz not null default now()
);
